﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ECampus;
using ECampus.Common;
using ECampus.Models;
//using ECampus.Models.DataAnnotations;
using E4Quiz.Models;
using E4Quiz.Models.Interface;
using E4Quiz.Models.DataAnnotations;
using E4Quiz.Extensions;    // for 語言檔Toi18n();


namespace E4Quiz.Controllers
{
    public class Quiz
    {
        #region 宣告
        e4ExamEntities E4db = new e4ExamEntities();
        e3PDB3Entities E35db = new e3PDB3Entities();

        #region 用Repository的方式存取資料庫
        /// 試卷
        IRepository<crsQuiz> crsQuizRepository;
        IRepository<crsQuizDraft> crsQuizDraftRepository;
        IRepository<crsQuizQuestion> crsQuizQuestionRepository;

        /// 題庫
        IRepository<crsQuestionPool> crsQuestionPoolRepository;
        IRepository<crsQuestionPoolDraft> crsQuestionPoolDraftRepository;
        IRepository<crsQuestionPoolOption> crsQuestionPoolOptionRepository;

        /// 答案卷
        IRepository<crsQuizSubmit> crsQuizSubmitRepository;
        IRepository<crsQuizSubmitAnswer> crsQuizSubmitAnswerRepository;

        // 成績單
        IRepository<crsQuizScore> crsQuizScoreRepository;

        /// 附加檔案
        IRepository<crsAttachment> crsAttachmentRepository;
        /// 權限
        IRepository<crsPublicUnitPermit> crsPublicUnitPermitRepository;
        #endregion

        List<crsMaterialDTO> _mResult = new List<crsMaterialDTO>();

        // 試卷
        crsQuiz _quiz = new crsQuiz();
        crsQuizDraft _quizDraft = new crsQuizDraft();
        crsQuizQuestion _question = new crsQuizQuestion();

        // 題庫
        crsQuestionPool _pool = new crsQuestionPool();
        crsQuestionPoolDraft _poolDraft = new crsQuestionPoolDraft();
        crsQuestionPoolOption _option = new crsQuestionPoolOption();

        // 答案卷
        crsQuizSubmit _sheet = new crsQuizSubmit();
        crsQuizSubmitAnswer _answer = new crsQuizSubmitAnswer();

        // 成績單
        crsQuizScore _score = new crsQuizScore();

        // 附加檔案
        crsAttachment _attachment = new crsAttachment();
        // 權限
        crsPublicUnitPermit _publicPermit = new crsPublicUnitPermit();

        crsQuizDTO _rLog = new crsQuizDTO();
        crsQuizDTO _rInfo = new crsQuizDTO();
        crsQuizDTO _record = new crsQuizDTO();
        crsMaterialDTO _material = new crsMaterialDTO();

        DateTime _updateTime = DateTime.Now;
        LogManager _log = new LogManager();             // 紀錄
        CustomBasicUnit _msg = new CustomBasicUnit();   // 訊息語言檔

        #endregion 宣告

        public Quiz()
        {
            crsQuizRepository = new E4Quiz.Models.GenericRepository<crsQuiz>(E4db);
            crsQuizDraftRepository = new E4Quiz.Models.GenericRepository<crsQuizDraft>(E4db);
            crsQuizQuestionRepository = new E4Quiz.Models.GenericRepository<crsQuizQuestion>(E4db);

            crsQuestionPoolRepository = new E4Quiz.Models.GenericRepository<crsQuestionPool>(E4db);
            crsQuestionPoolDraftRepository = new E4Quiz.Models.GenericRepository<crsQuestionPoolDraft>(E4db);
            crsQuestionPoolOptionRepository = new E4Quiz.Models.GenericRepository<crsQuestionPoolOption>(E4db);

            crsQuizSubmitRepository = new E4Quiz.Models.GenericRepository<crsQuizSubmit>(E4db);
            crsQuizSubmitAnswerRepository = new E4Quiz.Models.GenericRepository<crsQuizSubmitAnswer>(E4db);

            crsQuizScoreRepository = new E4Quiz.Models.GenericRepository<crsQuizScore>(E4db);

            crsAttachmentRepository = new E4Quiz.Models.GenericRepository<crsAttachment>(E4db);
            crsPublicUnitPermitRepository = new E4Quiz.Models.GenericRepository<crsPublicUnitPermit>(E4db);
            
        }


        //#region 取得使用者登入資訊
        //public ObjResult GetCurrentState(Guid UserId)
        //{
        //    ObjResult _result = new ObjResult();
        //    try
        //    {
        //        if (HttpContext.Current.Session[UserId.ToString()] == null)
        //            _result = _msg.TransformResult(false, String.Format(_msg.Get("msgReLogin"), ""));
        //        else
        //        {
        //            DateTime _updateTime = DateTime.Now;
        //            crsQuizDTO _info = new crsQuizDTO();
        //            string[] _data = HttpContext.Current.Session[UserId.ToString()].ToString().Split('|'); ;
        //            _info.IP = _data[0];
        //            _info.UpdateTime = Convert.ToDateTime(_data[1]);
        //            _info.CourseId = new Guid(_data[2]);
        //            _info.AccountId = UserId;

        //            TimeSpan _gap = _updateTime.Subtract((DateTime)_info.UpdateTime);
        //            if (_gap.Hours > 24)
        //                _result = _msg.TransformResult(false, String.Format(_msg.Get("msgReLogin"), ""));
        //            else
        //                _result = _msg.TransformResult(true, _info);

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
        //            _result = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "AccountId")); // xxxxx is null or unsuitable !
        //        else
        //            _result = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
        //    }


        //    return _result;
        //}

        //#endregion


        //#region 設定使用者登入資訊
        //public ObjResult SetCurrentState(Guid UserId, String IP, Guid? CourseId)
        //{
        //    ObjResult _result = new ObjResult();
        //    try
        //    {
        //        DateTime _updateTime = DateTime.Now;

        //        string _info = IP + "|" + _updateTime.ToString() + "|";
        //        if (CourseId != null) _info = _info + CourseId.ToString();

        //        HttpContext.Current.Session[UserId.ToString()] = _info;

        //        _result = _msg.TransformResult(true, _info);
        //    }
        //    catch (Exception ex)
        //    {
        //        if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
        //            _result = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "AccountId")); // xxxxx is null or unsuitable !
        //        else
        //            _result = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
        //    }


        //    return _result;
        //}

        //#endregion




        #region 鎖定資料
        public ObjResult Lock(crsQuizDTO infoData)
        {
            ObjResult _result = new ObjResult();
            _result.Success = false;
            try
            {
                Guid _materialId = new Guid();
                if ((infoData.UserId == null) || (infoData.UserId.ToString().Substring(0, 8) == "00000000"))
                    infoData.UserId = (Guid)infoData.LockedUser;

                switch (infoData.TheTable)
                {
                    case "cq":
                    case "Quiz":
                        #region 試卷 Lock _quiz
                        _materialId = infoData.QuizId;
                        _quiz = crsQuizRepository.GetFirst(a => a.cq_QuizId == infoData.QuizId);

                        if (_quiz != null)
                        {
                            _rLog.QuizId = infoData.QuizId;
                            _rInfo.QuizId = infoData.QuizId;

                            _quiz.cq_LockedTime = _updateTime;
                            _quiz.cq_Locked = (bool)infoData.Locked;
                            if (infoData.Locked == false) _quiz.cq_LockedUser = null;
                            else _quiz.cq_LockedUser = infoData.UserId;
                            _quiz.cq_LockedRemark = (infoData.Locked == false) ? null : infoData.LockedRemark;

                            // Update data
                            crsQuizRepository.Update(_quiz, false);
                            _result.Success = true;
                        }

                        #endregion Lock _quizDraft
                        break;

                    case "cqd":
                    case "QuizDraft":
                        #region 試卷草稿 Lock _quizDraft
                        _materialId = infoData.QuizId;
                        _quizDraft = crsQuizDraftRepository.GetFirst(a => a.cqd_QuizId == infoData.QuizId);

                        if (_quizDraft != null)
                        {
                            _rLog.QuizId = infoData.QuizId;
                            _rInfo.QuizId = infoData.QuizId;

                            _quizDraft.cqd_LockedTime = _updateTime;
                            _quizDraft.cqd_Locked = (bool)infoData.Locked;
                            if (infoData.Locked == false) _quizDraft.cqd_LockedUser = null;
                            else _quizDraft.cqd_LockedUser = infoData.UserId;
                            _quizDraft.cqd_LockedRemark = (infoData.Locked == false) ? null : infoData.LockedRemark;

                            // Update data
                            crsQuizDraftRepository.Update(_quizDraft, false);
                            _result.Success = true;
                        }

                        #endregion Lock _quizDraft
                        break;

                    case "cqpd":
                    case "PoolDraft":
                        #region 試題草稿 Lock _poolDraft
                        _materialId = infoData.PoolId;
                        _poolDraft = crsQuestionPoolDraftRepository.GetFirst(a => a.cqpd_PoolId == infoData.PoolId);

                        if (_poolDraft != null)
                        {
                            _rLog.PoolId = infoData.PoolId;
                            _rInfo.PoolId = infoData.PoolId;

                            _poolDraft.cqpd_LockedTime = _updateTime;
                            _poolDraft.cqpd_Locked = (bool)infoData.Locked;
                            if (infoData.Locked == false) _poolDraft.cqpd_LockedUser = null;
                            else _poolDraft.cqpd_LockedUser = infoData.UserId;
                            _poolDraft.cqpd_LockedRemark = (infoData.Locked == false) ? null : infoData.LockedRemark;

                            // Update data
                            crsQuestionPoolDraftRepository.Update(_poolDraft, false);
                            _result.Success = true;
                        }

                        #endregion Lock _poolDraft
                        break;

                    default:
                        // TheTable not one of option
                        _result.ErrorMessage = String.Format(_msg.Get("msgNotFound"), "TheTable");
                        break;
                }
                if (_result.Success != false)
                {
                    // 批次異動效能較好
                    if (_quiz != null) crsQuizRepository.SaveChanges();
                    if (_quizDraft != null) crsQuizDraftRepository.SaveChanges();
                    if (_poolDraft != null) crsQuestionPoolDraftRepository.SaveChanges();

                    _rInfo.Locked = infoData.Locked;	    // 資料鎖定
                    _rInfo.LockedTime = _updateTime;	    // 資料鎖定時間
                    _rInfo.LockedUser = null;
                    if(infoData.Locked == true) _rInfo.LockedUser = infoData.UserId;		// 資料鎖定者
                    _rInfo.LockedRemark = (infoData.Locked == true) ? infoData.LockedRemark : null;	// 資料鎖定備註

                    _result.DataCollection = _rInfo;
                }

            }
            catch (Exception ex)
            {
                _result.ErrorMessage = (String.Format(_msg.Get("msgError"), ex)); // Error !\r\n xxxxxx
            }
            if ((infoData.UserId == null) || (infoData.UserId.ToString().Substring(0, 8) == "00000000"))
                infoData.UserId = (Guid)infoData.LockedUser;

            #region  insert Log
            _rLog.IP = infoData.IP;
            _rLog.UserId = (Guid)infoData.UserId;
            _rLog.TheTable = infoData.TheTable;         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 5;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _result.Success;        // 執行成功
            _rLog.ErrorMessage = _result.ErrorMessage;       // 錯誤訊息

            _rLog.Comment = (infoData.Locked == true) ? infoData.LockedRemark : "UnLocked";     // 內容
            _log.ExamLog(_rLog);
            #endregion 


            return _result;
        }
        #endregion 鎖定資料

        #region 附加檔案紀錄
        // ==== 附加檔案紀錄 =========================================================================================================================

        #region 取得附加檔案清單
        public ObjResult AttachmentList(Guid BelongId, bool? IsDeleted)
        {
            ObjResult _oResult = new ObjResult();
            if (IsDeleted == null) // 撈出全部, 不分是否已刪除
                _oResult.DataCollection = (from p in E4db.crsAttachment
                                            where p.ca_BelongId == BelongId
                                           select new crsQuizDTO
                                            {
                                                FileId = p.ca_FileId,       //  附件ID
                                                BelongId = p.ca_BelongId,   //  來源ID(題目ID/答案ID)
                                                Name = p.ca_Name,           //  附加檔案名稱
                                                CreateTime = p.ca_CreateTime,  //  建立時間
                                                EditorId = (Guid)p.ca_EditorId,   //  建立者/更新者
                                                UpdateTime = p.ca_UpdateTime,  //  更新時間
                                                IsDeleted = p.ca_IsDeleted,   //  是否已刪除,false:可使用, true:不可使用(已刪除)
                                                Location = p.ca_Location   //  檔案位置
                                            }).ToList();

            else // 撈出已刪除/未刪除的資料
                _oResult.DataCollection = (from p in E4db.crsAttachment
                                            where p.ca_BelongId == BelongId && p.ca_IsDeleted == IsDeleted
                                           select new crsQuizDTO
                                             {
                                                 FileId = p.ca_FileId,       //  附件ID
                                                 BelongId = p.ca_BelongId,   //  來源ID(題目ID/答案ID)
                                                 Name = p.ca_Name,           //  附加檔案名稱
                                                 CreateTime = p.ca_CreateTime,  //  建立時間
                                                 EditorId = (Guid)p.ca_EditorId,   //  建立者/更新者
                                                 UpdateTime = p.ca_UpdateTime,  //  更新時間
                                                 IsDeleted = p.ca_IsDeleted,   //  是否已刪除,false:可使用, true:不可使用(已刪除)
                                                 Location = p.ca_Location   //  檔案位置
                                             }).ToList();


            if (_oResult.DataCollection != null) return _msg.TransformResult(true, _oResult.DataCollection);
            else return _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), BelongId.ToString()));
        }
        #endregion  取得附加檔案清單


        #region 取得附加檔案資訊
        public ObjResult AttachmentInfo(Guid FileId, Guid BelongId)
        {
            ObjResult _oResult = new ObjResult();
            var _info = (from p in E4db.crsAttachment
                        where p.ca_FileId == FileId && p.ca_BelongId == BelongId
                         select new crsQuizDTO
                        {
                            PackId = (Guid)p.ca_PackId,       //  同捆ID
                            FileId = p.ca_FileId,       //  附件ID
                            BelongId = p.ca_BelongId,   //  來源ID(題目ID/答案ID)
                            Name = p.ca_Name,           //  附加檔案名稱
                            CreateTime = p.ca_CreateTime,  //  建立時間
                            EditorId = (Guid)p.ca_EditorId,   //  建立者/更新者
                            UpdateTime = p.ca_UpdateTime,  //  更新時間
                            IsDeleted = p.ca_IsDeleted,   //  是否已刪除,false:可使用, true:不可使用(已刪除)
                            Location = p.ca_Location,   //  檔案位置
                        }).FirstOrDefault();

            if (_info != null) return _msg.TransformResult(true, _info);
            else return _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), BelongId.ToString()));

        }
        #endregion  取得附加檔案資訊


        #region 新增附加檔案資訊
        public ObjResult AttachmentCreate(crsQuizDTO newData)
        {
            ObjResult _oResult = new ObjResult(); 
            System.Guid _fileId = Guid.NewGuid();

            #region 屬性對應 
            _attachment.ca_FileId = _fileId;                //  附件ID
            _attachment.ca_PackId = newData.PackId;         //  同捆ID,上傳檔案後得到的ID
            _attachment.ca_BelongId = newData.BelongId;     //  來源ID(題目ID/答案ID)
            _attachment.ca_Name = newData.Name.Trim();      //  附加檔案名稱
            _attachment.ca_CreateTime = _updateTime;        //  建立時間
            _attachment.ca_EditorId = newData.UserId;       //  建立者/更新者
            _attachment.ca_UpdateTime = _updateTime;        //  更新時間
            _attachment.ca_IsDeleted = false; //  是否已刪除;false:可使用; true:不可使用(已刪除)
            _attachment.ca_Location = newData.Location.Trim();     //  檔案位置
            #endregion 屬性對應

            try
            {
                // insert data
                crsAttachmentRepository.Create(_attachment, true);

                _rInfo.FileId = _fileId;     //  附件ID
                _rInfo.BelongId = newData.BelongId;   //  來源ID(題目ID/答案ID)
                _rInfo.Name = newData.Name.Trim();            //  附加檔案名稱
                _rInfo.Location = newData.Location.Trim();        //  檔案位置
                _rInfo.UpdateTime = _updateTime;        //  更新時間

                return _msg.TransformResult(true, _rInfo);
            }
            catch (Exception ex)
            {
                return _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }
        }
        #endregion 新增附加檔案資訊


        #region 更新附加檔案資訊 (刪除:IsDeleted=true)
        public ObjResult AttachmentUpdate(crsQuizDTO updateData)
        {
            ObjResult _oResult = new ObjResult(); 
            try
            {
                // get record, 未判斷原建立者和修改者是否同人,建議由前端進行權限限制
                var _attachment = crsAttachmentRepository.GetFirst(a => a.ca_FileId == updateData.FileId && a.ca_BelongId == updateData.BelongId);
                if (_attachment != null)
                {

                    #region 屬性對應
                    _attachment.ca_UpdateTime = _updateTime;        //  建立時間
                    _attachment.ca_EditorId = updateData.UserId;    //  建立者
                    if (updateData.Name != null) _attachment.ca_Name = updateData.Name.Trim();             //  附加檔案名稱
                    if (updateData.IsDeleted != null) _attachment.ca_IsDeleted = updateData.IsDeleted; //  是否已刪除;false:可使用; true:不可使用(已刪除)
                    if (updateData.Location != null) _attachment.ca_Location = updateData.Location.Trim();     //  檔案位置

                    #endregion 屬性對應

                    // Update data
                    crsAttachmentRepository.Update(_attachment, true);

                    _rInfo.FileId = updateData.FileId;     //  附件ID
                    _rInfo.BelongId = updateData.BelongId;   //  來源ID(題目ID/答案ID)
                    _rInfo.Name = updateData.Name.Trim();            //  附加檔案名稱
                    _rInfo.Location = updateData.Location.Trim();        //  檔案位置
                    _rInfo.UpdateTime = _updateTime;        //  更新時間

                    return _msg.TransformResult(true, _rInfo);
                }
                else
                    return _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), updateData.FileId.ToString()));

            }
            catch (Exception ex)
            {
                return _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

        }
        #endregion 更新附加檔案資訊


        #endregion 附加檔案紀錄


        #region 試卷草稿

        //#region 試卷草稿清單--- old code disabled
        //public ObjResult List(Guid UserId, String IP, Boolean isCourseId, Guid? CourseId, Int32 skipAmount, Int32 getAmount)
        //{
        //    ObjResult _oResult = new ObjResult();
        //    List<crsQuizDTO> _list = new List<crsQuizDTO>();
        //    try
        //    {
        //        // get record
        //        var _records = crsQuizDraftRepository.GetAll().ToList();

        //        if (isCourseId)  // 撈出該課號所有試卷草稿
        //        {
        //            _records = crsQuizDraftRepository.Get(a => a.cqd_CourseId == CourseId)
        //                        .OrderByDescending(a => a.cqd_UpdateTime).ToList();
        //        }
        //        else  // 撈出使用者編譯過的試卷草稿
        //        {
        //            _records = crsQuizDraftRepository.Get(a => a.cqd_CreaterId == UserId || a.cqd_EditorId == UserId)
        //                            .OrderByDescending(a => a.cqd_UpdateTime).ToList();
        //        }
        //        // 限制輸出資料範圍
        //        if (getAmount > 0) _records = _records.Skip(skipAmount).Take(getAmount).ToList();

        //        if ((_records != null) && (_records.Count > 0))
        //        {
        //            foreach (crsQuizDraft _obj in _records)
        //            {
        //                // 判斷資料鎖定是否已逾期(超過6小時)
        //                crsQuizDTO _temp = new crsQuizDTO();
        //                TimeSpan _gapLocked = (_obj.cqd_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqd_LockedTime) : _updateTime.Subtract(_updateTime); //鎖定日期相減
        //                TimeSpan _gapUpdate = (_obj.cqd_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqd_UpdateTime) : _updateTime.Subtract(_updateTime); //更新日期相減

        //                _temp.UserId = UserId;
        //                _temp.Locked = (_gapLocked.Hours > 106 && _gapUpdate.Hours > 6) ? false : true;
        //                _temp.LockedRemark = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqd_LockedRemark;
        //                _temp.LockedUser = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqd_LockedUser;
        //                _temp.LockedTime = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqd_LockedTime;
        //                _temp.TheTable = "QuizDraft";
        //                if (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) Lock(_temp);  // 將資料解鎖

        //                _list.Add(new crsQuizDTO()
        //                {
        //                    #region 屬性對應, 因為主要作為清單用, 所以僅取部分欄位
        //                    QuizId = _obj.cqd_QuizId,
        //                    CreaterId = (Guid)_obj.cqd_CreaterId,
        //                    CreateTime = _obj.cqd_CreateTime,
        //                    UpdateTime = _obj.cqd_UpdateTime,
        //                    EditorId = (Guid)_obj.cqd_EditorId,
        //                    CourseId = (Guid)_obj.cqd_CourseId,
        //                    AcrossCourse = _obj.cqd_AcrossCourse,
        //                    QuizType = _obj.cqd_QuizType,
        //                    Caption = _obj.cqd_Caption,
        //                    BeginDate = _obj.cqd_BeginDate,
        //                    EndDate = _obj.cqd_EndDate,
        //                    PublicFlag = _obj.cqd_PublicFlag,
        //                    Locked = _temp.Locked,
        //                    LockedUser = _temp.LockedUser,
        //                    LockedTime = _temp.LockedTime,
        //                    LockedRemark = _temp.LockedRemark,

        //                    #region 隱藏不輸出
        //                    // Content = _obj.cqd_Content,
        //                    // Comment = _obj.cqd_Comment,
        //                    // Invited = _obj.cqd_Invited,
        //                    // GroupId = _obj.cqd_GroupId,
        //                    // Notify = _obj.cqd_Notify,
        //                    // NotifyRuleId = _obj.cqd_NotifyRuleId,
        //                    // IsDisorder = _obj.cqd_IsDisorder,
        //                    // OptionDisorder = _obj.cqd_OptionDisorder,
        //                    // DisplayType = _obj.cqd_DisplayType,
        //                    // AnswerSetting = _obj.cqd_AnswerSetting,
        //                    // TimeLimit = _obj.cqd_TimeLimit,
        //                    // TimeoutProcess = _obj.cqd_TimeoutProcess,
        //                    // QuestionSetting = _obj.cqd_QuestionSetting,
        //                    // TotalQuestion = _obj.cqd_TotalQuestion,
        //                    // TotalScore = _obj.cqd_TotalScore,
        //                    // DefaultScore = _obj.cqd_DefaultScore,
        //                    // DisplayAnswer = _obj.cqd_DisplayAnswer,
        //                    // DispAnsPutOffDays = _obj.cqd_DispAnsPutOffDays,
        //                    // CheckDisplayAnswer = _obj.cqd_CheckDisplayAnswer,
        //                    // CkDispAnsPutOffDays = _obj.cqd_CkDispAnsPutOffDays,
        //                    // Feedback = _obj.cqd_Feedback,
        //                    // FeedbackNotes = _obj.cqd_FeedbackNotes,
        //                    // Anew = _obj.cqd_Anew,
        //                    // ScoreSetting = _obj.cqd_ScoreSetting,
        //                    // ScoreOption = _obj.cqd_ScoreOption,
        //                    // DisplayScoreType = _obj.cqd_DisplayScoreType,
        //                    // DisplayScore = _obj.cqd_DisplayScore,
        //                    // DispScorePutOffDays = _obj.cqd_DispScorePutOffDays,
        //                    // CheckDisplayScore = _obj.cqd_CheckDisplayScore,
        //                    // CkDispScorePutOffDays = _obj.cqd_CkDispScorePutOffDays,
        //                    #endregion 隱藏不輸出
        //                    #endregion 屬性對應

        //                });
        //            }

        //            _oResult = _msg.TransformResult(true, _list);
        //        }
        //        else
        //        {
        //            _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
        //    }

        //    #region  insert Log
        //    _rLog.IP = IP;
        //    _rLog.UserId = UserId;
        //    _rLog.TheTable = "QuizDraft";         // 指定資料表
        //    _rLog.BeginDate = _updateTime;        // 開始時間
        //    _rLog.EndDate = DateTime.Now;         // 結束時間
        //    _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
        //    _rLog.Success = _oResult.Success;        // 執行成功
        //    _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

        //    _rLog.Comment = JsonConvert.SerializeObject(_list); // _list.ToString();     // 內容
        //    //_rLog.CourseId = ;      // 課程ID
        //    //_rLog.Subject = ;       // 主題名稱
        //    //_rLog.QuizId = ;        // (新)試卷ID
        //    //_rLog.OriginQuizId = ;  // 原始(來源)試卷ID
        //    _log.ExamLog(_rLog);
        //    #endregion

        //    return _oResult;
        //}
        //#endregion 試卷草稿清單


        #region 試卷草稿清單 --- 匯出 分享/共同 編輯的程式段未完成
        public ObjResult List(Guid UserId, String IP, Boolean isCourseId, Guid? CourseId, Int32 skipAmount, Int32 getAmount, Boolean onlyOwnData)
        {
            ObjResult _oResult = new ObjResult();
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            List<crsQuizDraft> _jointRecords = new List<crsQuizDraft>();
            try
            {
                List<Guid> _CourseId = new List<Guid>();     // 課程
                List<Guid> _jointQuizId = new List<Guid>();  // 共同/分享的試卷
                var _records = crsQuizDraftRepository.GetAll().ToList();

                if (isCourseId)  // 撈出該課號所有試卷草稿
                {
                    _records = crsQuizDraftRepository.Get(a => a.cqd_CourseId == CourseId)
                                .OrderByDescending(a => a.cqd_UpdateTime).ToList();

                    #region 共同/分享的試卷Id
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)CourseId, UserId);
                    if (_coursePermissions != null)
                        if (_coursePermissions.Quiz == false && onlyOwnData == false)
                            _jointQuizId = (from p in E4db.crsPublicUnitPermit
                                            join q in E4db.crsQuizDraft on p.cpup_UnitId equals q.cqd_QuizId
                                            where (CourseId == q.cqd_CourseId) && (CourseId == p.cpup_KeyId)
                                            select q.cqd_QuizId).ToList();
                    #endregion
                }
                else  // 撈出使用者編譯過的試卷草稿
                {
                    _records = crsQuizDraftRepository.Get(a => a.cqd_CreaterId == UserId || a.cqd_EditorId == UserId)
                                    .OrderByDescending(a => a.cqd_UpdateTime).ToList();

                    #region 共同/分享的試卷Id
                    if (onlyOwnData == false)
                    {
                        List<Guid> _temp = new List<Guid>();
                        _temp = (from p in E35db.autRCrsTea
                                 where p.TeacherId == UserId
                                 select (p.CourseId)).ToList();


                        // 篩選出有權限檢視的課程
                        foreach (var _obj in _temp)
                        {
                            CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)_obj, UserId);
                            if (_coursePermissions != null)
                                if (_coursePermissions.Quiz == true) _CourseId.Add(_obj);
                        }

                        // 共同/分享的試卷Id ---- error here
                        _jointQuizId = (from q in E4db.crsQuizDraft
                                        join p in E4db.crsPublicUnitPermit on q.cqd_QuizId equals p.cpup_UnitId 
                                        join m in E35db.crsTeamMember on p.cpup_KeyId equals m.TeamId
                                        where p.cpup_View == true && (p.cpup_KeyId == UserId || m.AccountId == UserId || (_CourseId.Contains((Guid)q.cqd_CourseId) && _CourseId.Contains((Guid)p.cpup_KeyId)))
                                        select q.cqd_QuizId).ToList();

                    }
                    #endregion

                }
                #region 移除重複 共同/分享的試題
                if (_jointQuizId != null)
                {
                    _jointRecords = crsQuizDraftRepository.Get(a => _jointQuizId.Contains((Guid)a.cqd_QuizId)).ToList();
                    foreach (var _obj in _jointRecords)
                        if (_records.Contains(_obj) == true) _jointRecords.Remove(_obj);
                }
                #endregion

                // 限制輸出資料範圍
                if (getAmount > 0) _records = _records.Skip(skipAmount).Take(getAmount).ToList();

                if ((_records != null) && (_records.Count > 0))
                {
                    foreach (crsQuizDraft _obj in _records)
                    {
                        // 判斷資料鎖定是否已逾期(超過6小時)
                        crsQuizDTO _temp = new crsQuizDTO();
                        TimeSpan _gapLocked = (_obj.cqd_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqd_LockedTime) : _updateTime.Subtract(_updateTime); //鎖定日期相減
                        TimeSpan _gapUpdate = (_obj.cqd_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqd_UpdateTime) : _updateTime.Subtract(_updateTime); //更新日期相減

                        _temp.UserId = UserId;
                        _temp.Locked = (_gapLocked.Hours > 106 && _gapUpdate.Hours > 6) ? false : true;
                        _temp.LockedRemark = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqd_LockedRemark;
                        _temp.LockedUser = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqd_LockedUser;
                        _temp.LockedTime = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqd_LockedTime;
                        _temp.TheTable = "QuizDraft";
                        if (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) Lock(_temp);  // 將資料解鎖

                        _list.Add(new crsQuizDTO()
                        {
                            #region 屬性對應, 因為主要作為清單用, 所以僅取部分欄位
                            QuizId = _obj.cqd_QuizId,
                            CreaterId = (Guid)_obj.cqd_CreaterId,
                            CreateTime = _obj.cqd_CreateTime,
                            UpdateTime = _obj.cqd_UpdateTime,
                            EditorId = (Guid)_obj.cqd_EditorId,
                            CourseId = (Guid)_obj.cqd_CourseId,
                            AcrossCourse = _obj.cqd_AcrossCourse,
                            QuizType = _obj.cqd_QuizType,
                            Caption = _obj.cqd_Caption,
                            BeginDate = _obj.cqd_BeginDate,
                            EndDate = _obj.cqd_EndDate,
                            PublicFlag = _obj.cqd_PublicFlag,
                            Locked = _temp.Locked,
                            LockedUser = _temp.LockedUser,
                            LockedTime = _temp.LockedTime,
                            LockedRemark = _temp.LockedRemark,

                            #region 隱藏不輸出
                            // Content = _obj.cqd_Content,
                            // Comment = _obj.cqd_Comment,
                            // Invited = _obj.cqd_Invited,
                            // GroupId = _obj.cqd_GroupId,
                            // Notify = _obj.cqd_Notify,
                            // NotifyRuleId = _obj.cqd_NotifyRuleId,
                            // IsDisorder = _obj.cqd_IsDisorder,
                            // OptionDisorder = _obj.cqd_OptionDisorder,
                            // DisplayType = _obj.cqd_DisplayType,
                            // AnswerSetting = _obj.cqd_AnswerSetting,
                            // TimeLimit = _obj.cqd_TimeLimit,
                            // TimeoutProcess = _obj.cqd_TimeoutProcess,
                            // QuestionSetting = _obj.cqd_QuestionSetting,
                            // TotalQuestion = _obj.cqd_TotalQuestion,
                            // TotalScore = _obj.cqd_TotalScore,
                            // DefaultScore = _obj.cqd_DefaultScore,
                            // DisplayAnswer = _obj.cqd_DisplayAnswer,
                            // DispAnsPutOffDays = _obj.cqd_DispAnsPutOffDays,
                            // CheckDisplayAnswer = _obj.cqd_CheckDisplayAnswer,
                            // CkDispAnsPutOffDays = _obj.cqd_CkDispAnsPutOffDays,
                            // Feedback = _obj.cqd_Feedback,
                            // FeedbackNotes = _obj.cqd_FeedbackNotes,
                            // Anew = _obj.cqd_Anew,
                            // ScoreSetting = _obj.cqd_ScoreSetting,
                            // ScoreOption = _obj.cqd_ScoreOption,
                            // DisplayScoreType = _obj.cqd_DisplayScoreType,
                            // DisplayScore = _obj.cqd_DisplayScore,
                            // DispScorePutOffDays = _obj.cqd_DispScorePutOffDays,
                            // CheckDisplayScore = _obj.cqd_CheckDisplayScore,
                            // CkDispScorePutOffDays = _obj.cqd_CkDispScorePutOffDays,
                            #endregion 隱藏不輸出
                            #endregion 屬性對應

                        });
                    }

                    _oResult = _msg.TransformResult(true, _list);
                }
                else
                {
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "QuizDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;        // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            _rLog.Comment = JsonConvert.SerializeObject(_list); // _list.ToString();     // 內容
            //_rLog.CourseId = ;      // 課程ID
            //_rLog.Subject = ;       // 主題名稱
            //_rLog.QuizId = ;        // (新)試卷ID
            //_rLog.OriginQuizId = ;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 試卷草稿清單


        #region 試卷狀態 -1:不存在; 0:編輯草稿中; 1:未開始; 2:進行中,未有考生繳卷; 3:進行中,已有考生繳卷; 4:已結束; 5:批閱中; 6:完成批閱; 7:公布成績 --- 新
        public ObjResult Status(Guid UserId, String IP, Guid QuizId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                Int32 _status = -1; // 預設不存在
                _oResult = Get(UserId, IP, QuizId);   // 檢查草稿是否有該試卷
                if (_oResult.Success == true) _status = 0;  // 編輯草稿中
                else
                {
                    _oResult = Acquire(UserId, IP, QuizId);   // 檢查正式試卷是否有該試卷
                    if (_oResult.Success == true)
                    {
                        crsQuizDTO _info = (crsQuizDTO)_oResult.DataCollection;
                        bool _PublishedScore = crsQuizScoreRepository.Get(a => a.cqs_PublishDate != null && a.cqs_QuizId == QuizId).Count() > 0;
                        Guid[] _submitAccount = crsQuizSubmitRepository.Get(a => a.cqs_QuizId == QuizId && a.cqs_EndDate != null).Select(a => a.cqs_AccountId).Distinct().Distinct().ToArray();
                        Guid[] _scoreAccount = crsQuizScoreRepository.Get(a => a.cqs_QuizId == QuizId && a.cqs_Checked == 2).Select(a => a.cqs_AccountId).Distinct().Distinct().ToArray();

                        if (_PublishedScore && _info.EndDate < _updateTime) _status = 7;   // 公布成績
                        else if (_submitAccount == _scoreAccount && _info.EndDate < _updateTime) _status = 6;   // 完成批閱
                        else if (_submitAccount != _scoreAccount && _info.EndDate < _updateTime) _status = 5;   // 批閱中
                        else if (_info.EndDate < _updateTime) _status = 4;   // 已結束
                        else if (_info.EndDate > _updateTime && _submitAccount.Count() > 0) _status = 3;   // 進行中,已有考生繳卷
                        else if (_info.EndDate > _updateTime) _status = 2;   // 進行中,未有考生繳卷
                        else if (_info.BeginDate > _updateTime) _status = 1; // 未開始
                    }
                }

                _oResult = _msg.TransformResult(true, _status);
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }


            return _oResult;
        }
        #endregion 取得試卷草稿


        #region 取得試卷草稿
        public ObjResult Get(Guid UserId, String IP, Guid QuizId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // get record
                var _quizDraft = crsQuizDraftRepository.GetFirst(a => a.cqd_QuizId == QuizId);
                if (_quizDraft != null)
                {
                    #region 屬性對應
                    _record.QuizId = _quizDraft.cqd_QuizId;
                    _record.CreaterId = (Guid)_quizDraft.cqd_CreaterId;
                    _record.CreateTime = _quizDraft.cqd_CreateTime;
                    _record.UpdateTime = _quizDraft.cqd_UpdateTime;
                    _record.EditorId = (_quizDraft.cqd_EditorId!=null)?_quizDraft.cqd_EditorId:null;
                    _record.CourseId = (Guid)_quizDraft.cqd_CourseId;
                    _record.AcrossCourse = _quizDraft.cqd_AcrossCourse;
                    _record.QuizType = _quizDraft.cqd_QuizType;
                    _record.Caption = _quizDraft.cqd_Caption;
                    _record.Content = _quizDraft.cqd_Content;
                    _record.Comment = _quizDraft.cqd_Comment;
                    _record.Invited = _quizDraft.cqd_Invited;
                    _record.GroupId = _quizDraft.cqd_GroupId;
                    _record.BeginDate = _quizDraft.cqd_BeginDate;
                    _record.EndDate = _quizDraft.cqd_EndDate;
                    _record.Notify = _quizDraft.cqd_Notify;
                    _record.NotifyRuleId = _quizDraft.cqd_NotifyRuleId;
                    _record.IsDisorder = _quizDraft.cqd_IsDisorder;
                    _record.OptionDisorder = _quizDraft.cqd_OptionDisorder;
                    _record.DisplayType = _quizDraft.cqd_DisplayType;
                    _record.AnswerSetting = _quizDraft.cqd_AnswerSetting;
                    _record.TimeLimit = _quizDraft.cqd_TimeLimit;
                    _record.TimeoutProcess = _quizDraft.cqd_TimeoutProcess;
                    _record.QuestionSetting = _quizDraft.cqd_QuestionSetting;
                    _record.TotalQuestion = _quizDraft.cqd_TotalQuestion;
                    _record.TotalScore = _quizDraft.cqd_TotalScore;
                    _record.DefaultScore = _quizDraft.cqd_DefaultScore;
                    _record.DisplayAnswer = _quizDraft.cqd_DisplayAnswer;
                    _record.DispAnsPutOffDays = _quizDraft.cqd_DispAnsPutOffDays;
                    _record.CheckDisplayAnswer = _quizDraft.cqd_CheckDisplayAnswer;
                    _record.CkDispAnsPutOffDays = _quizDraft.cqd_CkDispAnsPutOffDays;
                    _record.Feedback = _quizDraft.cqd_Feedback;
                    _record.FeedbackNotes = _quizDraft.cqd_FeedbackNotes;
                    _record.Anew = _quizDraft.cqd_Anew;
                    _record.ScoreSetting = _quizDraft.cqd_ScoreSetting;
                    _record.ScoreOption = _quizDraft.cqd_ScoreOption;
                    _record.DisplayScoreType = _quizDraft.cqd_DisplayScoreType;
                    _record.DisplayScore = _quizDraft.cqd_DisplayScore;
                    _record.DispScorePutOffDays = _quizDraft.cqd_DispScorePutOffDays;
                    _record.CheckDisplayScore = _quizDraft.cqd_CheckDisplayScore;
                    _record.CkDispScorePutOffDays = _quizDraft.cqd_CkDispScorePutOffDays;
                    _record.PublicFlag = _quizDraft.cqd_PublicFlag;
                    _record.Locked = _quizDraft.cqd_Locked;
                    _record.LockedUser = _quizDraft.cqd_LockedUser;
                    _record.LockedTime = _quizDraft.cqd_LockedTime;
                    _record.LockedRemark = _quizDraft.cqd_LockedRemark;
                    #endregion 屬性對應

                    _oResult = _msg.TransformResult(true, _record);

                    // Log info
                    _rLog.QuizId = QuizId;                // (新)試卷ID
                    _rLog.CourseId = _record.CourseId;    // 課程ID
                    _rLog.Subject = _record.Caption;      // 主題名稱
                    _rLog.Comment = JsonConvert.SerializeObject(_record); // _record.ToString();     // 內容
                    
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), QuizId.ToString())); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "QuizDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 1;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;        // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            //_rLog.OriginQuizId = ;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion 


            return _oResult;
        }
        #endregion 取得試卷草稿


        #region 新增試卷草稿
        public ObjResult Create(crsQuizDTO newData)
        {
            ObjResult _oResult = new ObjResult();
            System.Guid _quizId = Guid.NewGuid();

            #region 屬性對應
            _quizDraft.cqd_CreateTime = _rInfo.CreateTime = _updateTime;
            _quizDraft.cqd_CreaterId  = _rInfo.CreaterId = newData.UserId;
            _quizDraft.cqd_UpdateTime  = _rInfo.UpdateTime = _updateTime;
            _quizDraft.cqd_EditorId  = _rInfo.EditorId = newData.UserId;
            _quizDraft.cqd_QuizId   = _rInfo.QuizId = _quizId;
            _quizDraft.cqd_CourseId = _rInfo.CourseId = newData.CourseId;

            // 以下欄位預設值
            _rInfo.Invited      = _quizDraft.cqd_Invited = 0;     // 參與者:所有學生
            _rInfo.DisplayType  = _quizDraft.cqd_DisplayType = 0; // 題目預設全部顯示
            _rInfo.TimeoutProcess   = _quizDraft.cqd_TimeoutProcess = 1;      // 作答期限:期限內完成試卷
            _rInfo.DisplayAnswer    = _quizDraft.cqd_DisplayAnswer = 1;       // 自動批閱:活動結束馬上公布答案
            _rInfo.CheckDisplayAnswer   = _quizDraft.cqd_CheckDisplayAnswer = 2;  // 手動批閱:教師批閱完後?天公布答案
            _rInfo.CkDispAnsPutOffDays  = _quizDraft.cqd_CkDispAnsPutOffDays = 1; // 手動批閱 1 天後公布答案
            _rInfo.ScoreSetting     = _quizDraft.cqd_ScoreSetting = "1|0|0";  // 系統自動批閱成績(預選)
            _rInfo.ScoreOption      = _quizDraft.cqd_ScoreOption = 0;         // 自動批閱:以最後一次成績為主
            _rInfo.DisplayScoreType = _quizDraft.cqd_DisplayScoreType = 0;    // 成績預設不公佈
            _rInfo.AcrossCourse     = _quizDraft.cqd_AcrossCourse = false;    // 不可跨課程
            _rInfo.PublicFlag       = _quizDraft.cqd_PublicFlag = false;      // 不開放共同編輯
            
            #endregion 屬性對應

            try
            {
                // insert data
                crsQuizDraftRepository.Create(_quizDraft, true);

                _oResult = _msg.TransformResult(true, _rInfo);

                // Log info
                _rLog.QuizId = _quizId;               // (新)試卷ID
                _rLog.CourseId = newData.CourseId;    // 課程ID
                _rLog.Comment = JsonConvert.SerializeObject(_rInfo); // _quizDraft.ToString();// 內容
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = newData.IP;
            _rLog.UserId = newData.UserId;
            _rLog.TheTable = "QuizDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 2;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;       // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage; // 錯誤訊息

            //_rLog.Subject = _record.Caption;    // 主題名稱
            //_rLog.OriginQuizId = ;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 新增試卷草稿


        #region 引用試卷設定為草稿(不含題目)
        public ObjResult Recreate(Guid QuizId, Guid UserId, String IP)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                System.Guid _newId = Guid.NewGuid();

                // get record
                var _quiz = crsQuizRepository.GetFirst(a => a.cq_QuizId == QuizId);
                if (_quiz!=null)
                { 
                    #region 屬性對應
                    _quizDraft.cqd_CreaterId = _rInfo.CreaterId = UserId;
                    _quizDraft.cqd_EditorId  = _rInfo.EditorId  = UserId;
                    _quizDraft.cqd_CourseId  = _rInfo.CourseId  = (Guid)_quiz.cq_CourseId;

                    _rInfo.QuizId       = _quizDraft.cqd_QuizId         = _newId;
                    _rInfo.CreateTime   = _quizDraft.cqd_CreateTime     = _updateTime;
                    _rInfo.UpdateTime   = _quizDraft.cqd_UpdateTime     = _updateTime;
                    _rInfo.AcrossCourse = _quizDraft.cqd_AcrossCourse   = _quiz.cq_AcrossCourse;
                    _rInfo.QuizType     = _quizDraft.cqd_QuizType   = _quiz.cq_QuizType;
                    _rInfo.Caption      = _quizDraft.cqd_Caption    = _quiz.cq_Caption;
                    _rInfo.Content      = _quizDraft.cqd_Content    = _quiz.cq_Content;
                    _rInfo.Comment      = _quizDraft.cqd_Comment    = _quiz.cq_Comment;
                    _rInfo.Invited      = _quizDraft.cqd_Invited    = (int)_quiz.cq_Invited;
                    _rInfo.GroupId      = _quizDraft.cqd_GroupId    = _quiz.cq_GroupId;
                    _rInfo.Notify       = _quizDraft.cqd_Notify     = _quiz.cq_Notify;
                    _rInfo.NotifyRuleId = _quizDraft.cqd_NotifyRuleId   = _quiz.cq_NotifyRuleId;
                    _rInfo.IsDisorder   = _quizDraft.cqd_IsDisorder     = _quiz.cq_IsDisorder;
                    _rInfo.OptionDisorder   = _quizDraft.cqd_OptionDisorder     = _quiz.cq_OptionDisorder;
                    _rInfo.DisplayType      = _quizDraft.cqd_DisplayType        = (int)_quiz.cq_DisplayType;
                    _rInfo.AnswerSetting    = _quizDraft.cqd_AnswerSetting      = _quiz.cq_AnswerSetting;
                    _rInfo.TimeLimit        = _quizDraft.cqd_TimeLimit          = _quiz.cq_TimeLimit;
                    _rInfo.TimeoutProcess   = _quizDraft.cqd_TimeoutProcess     = (int)_quiz.cq_TimeoutProcess;
                    _rInfo.QuestionSetting  = _quizDraft.cqd_QuestionSetting    = _quiz.cq_QuestionSetting;
                    _rInfo.TotalQuestion    = _quizDraft.cqd_TotalQuestion      = _quiz.cq_TotalQuestion;
                    _rInfo.TotalScore       = _quizDraft.cqd_TotalScore         = _quiz.cq_TotalScore;
                    _rInfo.DefaultScore     = _quizDraft.cqd_DefaultScore       = _quiz.cq_DefaultScore;
                    _rInfo.DisplayAnswer    = _quizDraft.cqd_DisplayAnswer      = (int)_quiz.cq_DisplayAnswer;
                    _rInfo.DispAnsPutOffDays    = _quizDraft.cqd_DispAnsPutOffDays      = _quiz.cq_DispAnsPutOffDays;
                    _rInfo.CheckDisplayAnswer   = _quizDraft.cqd_CheckDisplayAnswer     = (int)_quiz.cq_CheckDisplayAnswer;
                    _rInfo.CkDispAnsPutOffDays  = _quizDraft.cqd_CkDispAnsPutOffDays    = (int)_quiz.cq_CkDispAnsPutOffDays;
                    _rInfo.Feedback         = _quizDraft.cqd_Feedback       = _quiz.cq_Feedback;
                    _rInfo.FeedbackNotes    = _quizDraft.cqd_FeedbackNotes  = _quiz.cq_FeedbackNotes;
                    _rInfo.Anew             = _quizDraft.cqd_Anew           = _quiz.cq_Anew;
                    _rInfo.ScoreSetting     = _quizDraft.cqd_ScoreSetting   = _quiz.cq_ScoreSetting;
                    _rInfo.ScoreOption      = _quizDraft.cqd_ScoreOption    = (int)_quiz.cq_ScoreOption;
                    _rInfo.DisplayScoreType = _quizDraft.cqd_DisplayScoreType   = (int)_quiz.cq_DisplayScoreType;
                    _rInfo.DisplayScore     = _quizDraft.cqd_DisplayScore       = _quiz.cq_DisplayScore;
                    _rInfo.DispScorePutOffDays      = _quizDraft.cqd_DispScorePutOffDays    = _quiz.cq_DispScorePutOffDays;
                    _rInfo.CheckDisplayScore        = _quizDraft.cqd_CheckDisplayScore      = _quiz.cq_CheckDisplayScore;
                    _rInfo.CkDispScorePutOffDays    = _quizDraft.cqd_CkDispScorePutOffDays  = _quiz.cq_CkDispScorePutOffDays;
                    _rInfo.PublicFlag = _quizDraft.cqd_PublicFlag   = _quiz.cq_PublicFlag;

                    //_quizDraft.cqd_BeginDate = _quiz.cq_BeginDate;
                    //_quizDraft.cqd_EndDate = _quiz.cq_EndDate;
                    #endregion 屬性對應

                    // insert data
                    crsQuizDraftRepository.Create(_quizDraft, true);


                    _oResult = _msg.TransformResult(true, _rInfo);

                    // Log info
                    _rLog.QuizId = _newId;               // (新)試卷ID
                    _rLog.OriginQuizId = QuizId;  // 原始(來源)試卷ID
                    _rLog.Subject = _quizDraft.cqd_Caption;    // 主題名稱
                    _rLog.CourseId = (Guid)_quizDraft.cqd_CourseId;    // 課程ID
                    _rLog.Comment = JsonConvert.SerializeObject(_rInfo); // _quizDraft.ToString();// 內容
                }
                else
                  _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), ""));

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "QuizDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 6;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;         // 錯誤訊息

            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 新增試卷


        #region 更新試卷草稿
        public ObjResult Update(crsQuizDTO updateData)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // get record, 未判斷原建立者和修改者是否同人,建議由前端進行權限限制
                var _quizDraft = crsQuizDraftRepository.GetFirst(a => a.cqd_QuizId == updateData.QuizId && a.cqd_LockedUser == updateData.UserId && a.cqd_Locked==true );
                if (_quizDraft != null)
                {

                    #region 屬性對應
                    _rInfo.UpdateTime = _quizDraft.cqd_UpdateTime = _updateTime;
                    _quizDraft.cqd_EditorId = _rInfo.EditorId = updateData.UserId;

                    if (updateData.AcrossCourse != null) _rInfo.AcrossCourse = _quizDraft.cqd_AcrossCourse = updateData.AcrossCourse;
                    if (updateData.QuizType != null) _rInfo.QuizType = _quizDraft.cqd_QuizType = updateData.QuizType;
                    if (updateData.Caption != null) _rInfo.Caption = _quizDraft.cqd_Caption = updateData.Caption.Trim();
                    if (updateData.Content != null) _rInfo.Content = _quizDraft.cqd_Content = updateData.Content.Trim();
                    if (updateData.Comment != null) _rInfo.Comment = _quizDraft.cqd_Comment = updateData.Comment.Trim();
                    if (updateData.Invited != null) _rInfo.Invited = _quizDraft.cqd_Invited = (int)updateData.Invited;
                    if (updateData.GroupId != null) _rInfo.GroupId = _quizDraft.cqd_GroupId = updateData.GroupId;
                    if (updateData.BeginDate != null) _rInfo.BeginDate = _quizDraft.cqd_BeginDate = updateData.BeginDate;
                    if (updateData.EndDate != null) _rInfo.EndDate = _quizDraft.cqd_EndDate = updateData.EndDate;
                    if (updateData.Notify != null) _rInfo.Notify = _quizDraft.cqd_Notify = updateData.Notify.Trim();
                    if (updateData.NotifyRuleId != null) _rInfo.NotifyRuleId = _quizDraft.cqd_NotifyRuleId = updateData.NotifyRuleId;
                    if (updateData.IsDisorder != null) _rInfo.IsDisorder = _quizDraft.cqd_IsDisorder = updateData.IsDisorder;
                    if (updateData.OptionDisorder != null) _rInfo.OptionDisorder = _quizDraft.cqd_OptionDisorder = updateData.OptionDisorder;
                    if (updateData.DisplayType != null) _rInfo.DisplayType = _quizDraft.cqd_DisplayType = (int)updateData.DisplayType;
                    if (updateData.AnswerSetting != null) _rInfo.AnswerSetting = _quizDraft.cqd_AnswerSetting = updateData.AnswerSetting.Trim();
                    if (updateData.TimeLimit != null) _rInfo.TimeLimit = _quizDraft.cqd_TimeLimit = updateData.TimeLimit;
                    if (updateData.TimeoutProcess != null) _rInfo.TimeoutProcess = _quizDraft.cqd_TimeoutProcess = (int)updateData.TimeoutProcess;
                    if (updateData.QuestionSetting != null) _rInfo.QuestionSetting = _quizDraft.cqd_QuestionSetting = updateData.QuestionSetting.Trim();
                    if (updateData.TotalQuestion != null) _rInfo.TotalQuestion = _quizDraft.cqd_TotalQuestion = updateData.TotalQuestion;
                    if (updateData.TotalScore != null) _rInfo.TotalScore = _quizDraft.cqd_TotalScore = updateData.TotalScore;
                    if (updateData.DefaultScore != null) _rInfo.DefaultScore = _quizDraft.cqd_DefaultScore = updateData.DefaultScore;
                    if (updateData.DisplayAnswer != null) _rInfo.DisplayAnswer = _quizDraft.cqd_DisplayAnswer = (int)updateData.DisplayAnswer;
                    if (updateData.DispAnsPutOffDays != null) _rInfo.DispAnsPutOffDays = _quizDraft.cqd_DispAnsPutOffDays = updateData.DispAnsPutOffDays;
                    if (updateData.CheckDisplayAnswer != null) _rInfo.CheckDisplayAnswer = _quizDraft.cqd_CheckDisplayAnswer = (int)updateData.CheckDisplayAnswer;
                    if (updateData.CkDispAnsPutOffDays != null) _rInfo.CkDispAnsPutOffDays = _quizDraft.cqd_CkDispAnsPutOffDays = (int)updateData.CkDispAnsPutOffDays;
                    if (updateData.Feedback != null) _rInfo.Feedback = _quizDraft.cqd_Feedback = updateData.Feedback.Trim();
                    if (updateData.FeedbackNotes != null) _rInfo.FeedbackNotes = _quizDraft.cqd_FeedbackNotes = updateData.FeedbackNotes.Trim();
                    if (updateData.Anew != null) _rInfo.Anew = _quizDraft.cqd_Anew = updateData.Anew;
                    if (updateData.ScoreSetting != null) _rInfo.ScoreSetting = _quizDraft.cqd_ScoreSetting = updateData.ScoreSetting.Trim();
                    if (updateData.ScoreOption != null) _rInfo.ScoreOption = _quizDraft.cqd_ScoreOption = (int)updateData.ScoreOption;
                    if (updateData.DisplayScoreType != null) _rInfo.DisplayScoreType = _quizDraft.cqd_DisplayScoreType = (int)updateData.DisplayScoreType;
                    if (updateData.DisplayScore != null) _rInfo.DisplayScore = _quizDraft.cqd_DisplayScore = updateData.DisplayScore;
                    if (updateData.DispScorePutOffDays != null) _rInfo.DispScorePutOffDays = _quizDraft.cqd_DispScorePutOffDays = updateData.DispScorePutOffDays;
                    if (updateData.CheckDisplayScore != null) _rInfo.CheckDisplayScore = _quizDraft.cqd_CheckDisplayScore = updateData.CheckDisplayScore;
                    if (updateData.CkDispScorePutOffDays != null) _rInfo.CkDispScorePutOffDays = _quizDraft.cqd_CkDispScorePutOffDays = updateData.CkDispScorePutOffDays;
                    if (updateData.PublicFlag != null) _rInfo.PublicFlag = _quizDraft.cqd_PublicFlag = updateData.PublicFlag;

                    #endregion 屬性對應

                    // Update data
                    crsQuizDraftRepository.Update(_quizDraft, true);

                    _oResult = _msg.TransformResult(true, _rInfo);

                    // Log info
                    _rLog.CourseId = _material.CourseId;    // 課程ID
                    _rLog.QuizId = updateData.QuizId;               // (新)試卷ID
                    _rLog.Subject = updateData.Caption;    // 主題名稱
                    _rLog.Comment = JsonConvert.SerializeObject(_rInfo); // _quizDraft.ToString();// 內容
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), ""));

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = updateData.IP;
            _rLog.UserId = updateData.UserId;
            _rLog.TheTable = "QuizDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;        // 錯誤訊息

            //_rLog.OriginQuizId = quizId;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 更新試卷草稿


        #region 刪除試卷草稿
        public ObjResult Delete(Guid UserId, String IP, Guid QuizId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                var _quizRecord = crsQuizDraftRepository.Get(a => a.cqd_QuizId == QuizId && (a.cqd_CreaterId == UserId || a.cqd_EditorId == UserId));

                if (_quizRecord.Count() > 0)
                {
                    _rLog.QuizId = _rInfo.QuizId = QuizId;               // 試卷ID
                    foreach (crsQuizDraft _crsQuizDraft in _quizRecord)
                        crsQuizDraftRepository.Delete(_crsQuizDraft, false);

                    crsQuizDraftRepository.SaveChanges();

                    _oResult = _msg.TransformResult(true, _rInfo);
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "QuizId:" + QuizId.ToString()));
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "QuizDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 4;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;    // 錯誤訊息

            //_rLog.CourseId = _material.CourseId;    // 課程ID
            //_rLog.Subject = updateData.Caption;    // 主題名稱
            //_rLog.Comment = updateData.ToString();// 內容
            //_rLog.OriginQuizId = quizId;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 刪除試卷草稿

        #endregion 試卷草稿

        #region 正式試卷

        #region 試卷紀錄清單 --- 尚未加入分享/共同編輯的資料判斷
        public ObjResult Records(Guid UserId, String IP, Boolean isCourseId, Guid? CourseId, Int32 skipAmount, Int32 getAmount, Int32 getType)
        {
            ObjResult _oResult = new ObjResult();
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            try
            {
                // get record
                var _records = crsQuizRepository.GetAll().ToList();

                if (isCourseId)  // 撈出該課號所有試卷
                {
                    _records = crsQuizRepository.Get(a => a.cq_CourseId == CourseId)
                                .OrderByDescending(a => a.cq_UpdateTime).ToList();
                }
                else  // 撈出使用者編譯過的試卷
                {
                    _records = crsQuizRepository.Get(a => a.cq_CreaterId == UserId || a.cq_EditorId == UserId)
                                .OrderByDescending(a => a.cq_UpdateTime).ToList();
                }

                // 資料範圍, 0:所有紀錄, 1:未刪除的紀錄, 2:已刪除的紀錄
                if (getType == 1)
                    _records = _records.FindAll(a => a.cq_IsDeleted == false).ToList();
                else if (getType == 2)
                    _records = _records.FindAll(a => a.cq_IsDeleted == true).ToList();

                // 限制輸出資料範圍
                if (getAmount > 0) _records = _records.Skip(skipAmount).Take(getAmount).ToList();

                if ((_records != null) && (_records.Count > 0))
                {
                    foreach (var _obj in _records)
                    {
                        _list.Add(new crsQuizDTO()
                        {
                            #region 屬性對應, 因為主要作為清單用, 所以僅取部分欄位
                            QuizId = _obj.cq_QuizId,
                            CreaterId = (Guid)_obj.cq_CreaterId,
                            CreateTime = _obj.cq_CreateTime,
                            UpdateTime = _obj.cq_UpdateTime,
                            EditorId = (Guid)_obj.cq_EditorId,
                            CourseId = (Guid)_obj.cq_CourseId,
                            AcrossCourse = _obj.cq_AcrossCourse,
                            QuizType = _obj.cq_QuizType,
                            Caption = _obj.cq_Caption,
                            BeginDate = _obj.cq_BeginDate,
                            EndDate = _obj.cq_EndDate,
                            PublicFlag = _obj.cq_PublicFlag,
                            Locked = _obj.cq_Locked,
                            LockedUser = _obj.cq_LockedUser,
                            LockedTime = _obj.cq_LockedTime,
                            LockedRemark = _obj.cq_LockedRemark
                            //Content = _obj.cq_Content,
                            //Comment = _obj.cq_Comment,
                            //Invited = _obj.cq_Invited,
                            //GroupId = _obj.cq_GroupId,
                            //Notify = _obj.cq_Notify,
                            //NotifyRuleId = _obj.cq_NotifyRuleId,
                            //IsDisorder = _obj.cq_IsDisorder,
                            //OptionDisorder = _obj.cq_OptionDisorder,
                            //DisplayType = _obj.cq_DisplayType,
                            //AnswerSetting = _obj.cq_AnswerSetting,
                            //TimeLimit = _obj.cq_TimeLimit,
                            //TimeoutProcess = _obj.cq_TimeoutProcess,
                            //QuestionSetting = _obj.cq_QuestionSetting,
                            //TotalQuestion = _obj.cq_TotalQuestion,
                            //TotalScore = _obj.cq_TotalScore,
                            //DefaultScore = _obj.cq_DefaultScore,
                            //DisplayAnswer = _obj.cq_DisplayAnswer,
                            //DispAnsPutOffDays = _obj.cq_DispAnsPutOffDays,
                            //CheckDisplayAnswer = _obj.cq_CheckDisplayAnswer,
                            //CkDispAnsPutOffDays = _obj.cq_CkDispAnsPutOffDays,
                            //Feedback = _obj.cq_Feedback,
                            //FeedbackNotes = _obj.cq_FeedbackNotes,
                            //Anew = _obj.cq_Anew,
                            //ScoreSetting = _obj.cq_ScoreSetting,
                            //ScoreOption = _obj.cq_ScoreOption,
                            //DisplayScoreType = _obj.cq_DisplayScoreType,
                            //DisplayScore = _obj.cq_DisplayScore,
                            //DispScorePutOffDays = _obj.cq_DispScorePutOffDays,
                            //CheckDisplayScore = _obj.cq_CheckDisplayScore,
                            //CkDispScorePutOffDays = _obj.cq_CkDispScorePutOffDays,
                            #endregion 屬性對應
                        }
                        );
                    }

                    _oResult = _msg.TransformResult(true, _list);
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), CourseId.ToString())); // Can not found the record !\r\n xxxxx
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "Quiz";              // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;        // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            _rLog.Comment = JsonConvert.SerializeObject(_list); // _list.ToString();     // 內容
            //_rLog.CourseId = ;      // 課程ID
            //_rLog.Subject = ;       // 主題名稱
            //_rLog.QuizId = ;        // (新)試卷ID
            //_rLog.OriginQuizId = ;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 試卷紀錄清單


        #region 取得試卷
        public ObjResult Acquire(Guid UserId, String IP, Guid QuizId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // get record
                var _quiz = crsQuizRepository.GetFirst(a => a.cq_QuizId == QuizId);
                if (_quiz != null)
                {
                    #region 屬性對應
                    _record.QuizId = _quiz.cq_QuizId;
                    _record.CreaterId = (Guid)_quiz.cq_CreaterId;
                    _record.CreateTime = _quiz.cq_CreateTime;
                    _record.UpdateTime = _quiz.cq_UpdateTime;
                    _record.EditorId = (Guid)_quiz.cq_EditorId;
                    _record.CourseId = (Guid)_quiz.cq_CourseId;
                    _record.AcrossCourse = _quiz.cq_AcrossCourse;
                    _record.QuizType = _quiz.cq_QuizType;
                    _record.Caption = _quiz.cq_Caption;
                    _record.Content = _quiz.cq_Content;
                    _record.Comment = _quiz.cq_Comment;
                    _record.Invited = _quiz.cq_Invited;
                    _record.GroupId = _quiz.cq_GroupId;
                    _record.BeginDate = _quiz.cq_BeginDate;
                    _record.EndDate = _quiz.cq_EndDate;
                    _record.Notify = _quiz.cq_Notify;
                    _record.NotifyRuleId = _quiz.cq_NotifyRuleId;
                    _record.IsDisorder = _quiz.cq_IsDisorder;
                    _record.OptionDisorder = _quiz.cq_OptionDisorder;
                    _record.DisplayType = _quiz.cq_DisplayType;
                    _record.AnswerSetting = _quiz.cq_AnswerSetting;
                    _record.TimeLimit = _quiz.cq_TimeLimit;
                    _record.TimeoutProcess = _quiz.cq_TimeoutProcess;
                    _record.QuestionSetting = _quiz.cq_QuestionSetting;
                    _record.TotalQuestion = _quiz.cq_TotalQuestion;
                    _record.TotalScore = _quiz.cq_TotalScore;
                    _record.DefaultScore = _quiz.cq_DefaultScore;
                    _record.DisplayAnswer = _quiz.cq_DisplayAnswer;
                    _record.DispAnsPutOffDays = _quiz.cq_DispAnsPutOffDays;
                    _record.CheckDisplayAnswer = _quiz.cq_CheckDisplayAnswer;
                    _record.CkDispAnsPutOffDays = _quiz.cq_CkDispAnsPutOffDays;
                    _record.Feedback = _quiz.cq_Feedback;
                    _record.FeedbackNotes = _quiz.cq_FeedbackNotes;
                    _record.Anew = _quiz.cq_Anew;
                    _record.ScoreSetting = _quiz.cq_ScoreSetting;
                    _record.ScoreOption = _quiz.cq_ScoreOption;
                    _record.DisplayScoreType = _quiz.cq_DisplayScoreType;
                    _record.DisplayScore = _quiz.cq_DisplayScore;
                    _record.DispScorePutOffDays = _quiz.cq_DispScorePutOffDays;
                    _record.CheckDisplayScore = _quiz.cq_CheckDisplayScore;
                    _record.CkDispScorePutOffDays = _quiz.cq_CkDispScorePutOffDays;
                    _record.PublicFlag = _quiz.cq_PublicFlag;
                    _record.IsDeleted = _quiz.cq_IsDeleted;
                    _record.Locked = _quiz.cq_Locked;
                    _record.LockedUser = _quiz.cq_LockedUser;
                    _record.LockedTime = _quiz.cq_LockedTime;
                    _record.LockedRemark = _quiz.cq_LockedRemark;
                    #endregion 屬性對應

                    _oResult = _msg.TransformResult(true, _record);

                    // Log info
                    _rLog.QuizId = QuizId;                // (新)試卷ID
                    _rLog.CourseId = _record.CourseId;    // 課程ID
                    _rLog.Subject = _record.Caption;      // 主題名稱
                    _rLog.Comment = JsonConvert.SerializeObject(_record); // _record.ToString();     // 內容
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), QuizId.ToString())); // Can not found the record !\r\n xxxxx
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "Quiz";              // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 1;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;        // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            //_rLog.OriginQuizId = ;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion 


            return _oResult;
        }
        #endregion 取得試卷

        
        #region 新增試卷
        public ObjResult Publish(Guid UserId, String IP, Guid QuizId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // get record
                var _quizDraft = crsQuizDraftRepository.GetFirst(a => a.cqd_QuizId == QuizId && (a.cqd_CreaterId == UserId || a.cqd_EditorId == UserId));

                #region 屬性對應
                _quiz.cq_CreaterId = _rInfo.CreaterId = (Guid)_quizDraft.cqd_CreaterId;
                _quiz.cq_EditorId = _rInfo.EditorId = (Guid)_quizDraft.cqd_EditorId;
                _quiz.cq_CourseId = _rInfo.CourseId = (Guid)_quizDraft.cqd_CourseId;

                _rInfo.QuizId = _quiz.cq_QuizId = _quizDraft.cqd_QuizId;
                _rInfo.CreateTime = _quiz.cq_CreateTime = _quizDraft.cqd_CreateTime;
                _rInfo.UpdateTime = _quiz.cq_UpdateTime = _updateTime;
                _rInfo.AcrossCourse = _quiz.cq_AcrossCourse = _quizDraft.cqd_AcrossCourse;
                _rInfo.QuizType = _quiz.cq_QuizType = _quizDraft.cqd_QuizType;
                _rInfo.Caption = _quiz.cq_Caption = _quizDraft.cqd_Caption;
                _rInfo.Content = _quiz.cq_Content = _quizDraft.cqd_Content;
                _rInfo.Comment = _quiz.cq_Comment = _quizDraft.cqd_Comment;
                _rInfo.Invited = _quiz.cq_Invited = _quizDraft.cqd_Invited;
                _rInfo.GroupId = _quiz.cq_GroupId = _quizDraft.cqd_GroupId;
                _rInfo.BeginDate = _quiz.cq_BeginDate = _quizDraft.cqd_BeginDate;
                _rInfo.EndDate = _quiz.cq_EndDate = _quizDraft.cqd_EndDate;
                _rInfo.Notify = _quiz.cq_Notify = _quizDraft.cqd_Notify;
                _rInfo.NotifyRuleId = _quiz.cq_NotifyRuleId = _quizDraft.cqd_NotifyRuleId;
                _rInfo.IsDisorder = _quiz.cq_IsDisorder = _quizDraft.cqd_IsDisorder;
                _rInfo.OptionDisorder = _quiz.cq_OptionDisorder = _quizDraft.cqd_OptionDisorder;
                _rInfo.DisplayType = _quiz.cq_DisplayType = _quizDraft.cqd_DisplayType;
                _rInfo.AnswerSetting = _quiz.cq_AnswerSetting = _quizDraft.cqd_AnswerSetting;
                _rInfo.TimeLimit = _quiz.cq_TimeLimit = _quizDraft.cqd_TimeLimit;
                _rInfo.TimeoutProcess = _quiz.cq_TimeoutProcess = _quizDraft.cqd_TimeoutProcess;
                _rInfo.QuestionSetting = _quiz.cq_QuestionSetting = _quizDraft.cqd_QuestionSetting;
                _rInfo.TotalQuestion = _quiz.cq_TotalQuestion = _quizDraft.cqd_TotalQuestion;
                _rInfo.TotalScore = _quiz.cq_TotalScore = _quizDraft.cqd_TotalScore;
                _rInfo.DefaultScore = _quiz.cq_DefaultScore = _quizDraft.cqd_DefaultScore;
                _rInfo.DisplayAnswer = _quiz.cq_DisplayAnswer = _quizDraft.cqd_DisplayAnswer;
                _rInfo.DispAnsPutOffDays = _quiz.cq_DispAnsPutOffDays = _quizDraft.cqd_DispAnsPutOffDays;
                _rInfo.CheckDisplayAnswer = _quiz.cq_CheckDisplayAnswer = _quizDraft.cqd_CheckDisplayAnswer;
                _rInfo.CkDispAnsPutOffDays = _quiz.cq_CkDispAnsPutOffDays = _quizDraft.cqd_CkDispAnsPutOffDays;
                _rInfo.Feedback = _quiz.cq_Feedback = _quizDraft.cqd_Feedback;
                _rInfo.FeedbackNotes = _quiz.cq_FeedbackNotes = _quizDraft.cqd_FeedbackNotes;
                _rInfo.Anew = _quiz.cq_Anew = _quizDraft.cqd_Anew;
                _rInfo.ScoreSetting = _quiz.cq_ScoreSetting = _quizDraft.cqd_ScoreSetting;
                _rInfo.ScoreOption = _quiz.cq_ScoreOption = _quizDraft.cqd_ScoreOption;
                _rInfo.DisplayScoreType = _quiz.cq_DisplayScoreType = _quizDraft.cqd_DisplayScoreType;
                _rInfo.DisplayScore = _quiz.cq_DisplayScore = _quizDraft.cqd_DisplayScore;
                _rInfo.DispScorePutOffDays = _quiz.cq_DispScorePutOffDays = _quizDraft.cqd_DispScorePutOffDays;
                _rInfo.CheckDisplayScore = _quiz.cq_CheckDisplayScore = _quizDraft.cqd_CheckDisplayScore;
                _rInfo.CkDispScorePutOffDays = _quiz.cq_CkDispScorePutOffDays = _quizDraft.cqd_CkDispScorePutOffDays;
                _rInfo.PublicFlag = _quiz.cq_PublicFlag = _quizDraft.cqd_PublicFlag;
                _rInfo.IsDeleted = _quiz.cq_IsDeleted = false;
                _rInfo.PublishDate = _quiz.cq_PublishDate = _updateTime;

                #endregion 屬性對應

                // insert data
                crsQuizRepository.Create(_quiz, true);

                _oResult = _msg.TransformResult(true, _rInfo);

                // Log info
                _rLog.QuizId = QuizId;               // (新)試卷ID
                _rLog.CourseId = (Guid)_quiz.cq_CourseId;    // 課程ID
                _rLog.Subject = _quiz.cq_Caption;    // 主題名稱
                _rLog.Comment = JsonConvert.SerializeObject(_rInfo); // _quiz.ToString();// 內容
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "Quiz";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 7;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6, 發佈 = 7
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;        // 錯誤訊息

            //_rLog.OriginQuizId = ;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 新增試卷


        #region 修改試卷
        public ObjResult Revise(crsQuizDTO updateData)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // get record, 未判斷原建立者和修改者是否同人,建議由前端進行權限限制
                var _quiz = crsQuizRepository.GetFirst(a => a.cq_QuizId == updateData.QuizId && a.cq_LockedUser == updateData.UserId && a.cq_Locked == true);
                if (_quiz != null)
                {

                    #region 屬性對應,僅提供部分欄位可修改
                    _rInfo.UpdateTime = _quiz.cq_UpdateTime = _updateTime;
                    _quiz.cq_EditorId = _rInfo.EditorId = updateData.UserId;

                    if (updateData.BeginDate != null) _rInfo.BeginDate = _quiz.cq_BeginDate = updateData.BeginDate;
                    if (updateData.EndDate != null) _rInfo.EndDate = _quiz.cq_EndDate = updateData.EndDate;
                    if (updateData.TimeLimit != null) _rInfo.TimeLimit = _quiz.cq_TimeLimit = updateData.TimeLimit;
                    if (updateData.TimeoutProcess != null) _rInfo.TimeoutProcess = _quiz.cq_TimeoutProcess = (int)updateData.TimeoutProcess;
                    if (updateData.TotalScore != null) _rInfo.TotalScore = _quiz.cq_TotalScore = updateData.TotalScore;
                    if (updateData.DefaultScore != null) _rInfo.DefaultScore = _quiz.cq_DefaultScore = updateData.DefaultScore;
                    if (updateData.Anew != null) _rInfo.Anew = _quiz.cq_Anew = updateData.Anew;
                    if (updateData.ScoreSetting != null) _rInfo.ScoreSetting = _quiz.cq_ScoreSetting = updateData.ScoreSetting.Trim();
                    if (updateData.ScoreOption != null) _rInfo.ScoreOption = _quiz.cq_ScoreOption = (int)updateData.ScoreOption;

                    // 以下欄位建議不開放給前端使用者修改
                    if (updateData.AcrossCourse != null) _rInfo.AcrossCourse = _quiz.cq_AcrossCourse = updateData.AcrossCourse;
                    if (updateData.QuizType != null) _rInfo.QuizType = _quiz.cq_QuizType = updateData.QuizType;
                    if (updateData.Caption != null) _rInfo.Caption = _quiz.cq_Caption = updateData.Caption.Trim();
                    if (updateData.Content != null) _rInfo.Content = _quiz.cq_Content = updateData.Content.Trim();
                    if (updateData.Comment != null) _rInfo.Comment = _quiz.cq_Comment = updateData.Comment.Trim();
                    if (updateData.Invited != null) _rInfo.Invited = _quiz.cq_Invited = (int)updateData.Invited;
                    if (updateData.GroupId != null) _rInfo.GroupId = _quiz.cq_GroupId = updateData.GroupId;
                    if (updateData.Notify != null) _rInfo.Notify = _quiz.cq_Notify = updateData.Notify;
                    if (updateData.NotifyRuleId != null) _rInfo.NotifyRuleId = _quiz.cq_NotifyRuleId = updateData.NotifyRuleId;
                    if (updateData.IsDisorder != null) _rInfo.IsDisorder = _quiz.cq_IsDisorder = updateData.IsDisorder;
                    if (updateData.OptionDisorder != null) _rInfo.OptionDisorder = _quiz.cq_OptionDisorder = updateData.OptionDisorder;
                    if (updateData.DisplayType != null) _rInfo.DisplayType = _quiz.cq_DisplayType = (int)updateData.DisplayType;
                    if (updateData.AnswerSetting != null) _rInfo.AnswerSetting = _quiz.cq_AnswerSetting = updateData.AnswerSetting.Trim();
                    if (updateData.QuestionSetting != null) _rInfo.QuestionSetting = _quiz.cq_QuestionSetting = updateData.QuestionSetting.Trim();
                    if (updateData.TotalQuestion != null) _rInfo.TotalQuestion = _quiz.cq_TotalQuestion = updateData.TotalQuestion;
                    if (updateData.DisplayAnswer != null) _rInfo.DisplayAnswer = _quiz.cq_DisplayAnswer = (int)updateData.DisplayAnswer;
                    if (updateData.DispAnsPutOffDays != null) _rInfo.DispAnsPutOffDays = _quiz.cq_DispAnsPutOffDays = updateData.DispAnsPutOffDays;
                    if (updateData.CheckDisplayAnswer != null) _rInfo.CheckDisplayAnswer = _quiz.cq_CheckDisplayAnswer = (int)updateData.CheckDisplayAnswer;
                    if (updateData.CkDispAnsPutOffDays != null) _rInfo.CkDispAnsPutOffDays = _quiz.cq_CkDispAnsPutOffDays = (int)updateData.CkDispAnsPutOffDays;
                    if (updateData.Feedback != null) _rInfo.Feedback = _quiz.cq_Feedback = updateData.Feedback.Trim();
                    if (updateData.FeedbackNotes != null) _rInfo.FeedbackNotes = _quiz.cq_FeedbackNotes = updateData.FeedbackNotes.Trim();
                    if (updateData.DisplayScoreType != null) _rInfo.DisplayScoreType = _quiz.cq_DisplayScoreType = (int)updateData.DisplayScoreType;
                    if (updateData.DisplayScore != null) _rInfo.DisplayScore = _quiz.cq_DisplayScore = updateData.DisplayScore;
                    if (updateData.DispScorePutOffDays != null) _rInfo.DispScorePutOffDays = _quiz.cq_DispScorePutOffDays = updateData.DispScorePutOffDays;
                    if (updateData.CheckDisplayScore != null) _rInfo.CheckDisplayScore = _quiz.cq_CheckDisplayScore = updateData.CheckDisplayScore;
                    if (updateData.CkDispScorePutOffDays != null) _rInfo.CkDispScorePutOffDays = _quiz.cq_CkDispScorePutOffDays = updateData.CkDispScorePutOffDays;
                    if (updateData.PublicFlag != null) _rInfo.PublicFlag = _quiz.cq_PublicFlag = updateData.PublicFlag;
                    if (updateData.IsDeleted != null) _rInfo.IsDeleted = _quiz.cq_IsDeleted = updateData.IsDeleted;
                    #endregion 屬性對應

                    // Update data
                    crsQuizRepository.Update(_quiz, true);

                    _oResult = _msg.TransformResult(true, _rInfo);

                    // Log info
                    _rLog.CourseId = _material.CourseId;    // 課程ID
                    _rLog.QuizId = updateData.QuizId;               // (新)試卷ID
                    _rLog.Subject = updateData.Caption;    // 主題名稱
                    _rLog.Comment = JsonConvert.SerializeObject(_rInfo); // _quiz.ToString();// 內容
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), ""));

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = updateData.IP;
            _rLog.UserId = updateData.UserId;
            _rLog.TheTable = "Quiz";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = (updateData.IsDeleted ==true)?4:3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;    // 錯誤訊息

            //_rLog.OriginQuizId = quizId;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 更新試卷


        #endregion 正式試卷

        #region 試卷題目
        // ==== 試卷題目 =========================================================================================================================

        #region 試卷題目清單
        public ObjResult QuestionList(Guid UserId, String IP, Guid QuizId, Boolean isRandom, Int32 skipAmount, Int32 getAmount)
        {
            ObjResult _oResult = new ObjResult();
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            try
            {
                // get record
                var _records = crsQuizQuestionRepository.Get(a => a.cqq_QuizId == QuizId).ToList();
                if (isRandom) _records = _records.OrderBy(a => Guid.NewGuid()).ToList();  // 隨機排序
                else _records = _records.OrderBy(a => a.cqq_Serial).OrderBy(a => a.cqq_CreateTime).ToList();

                // 限制輸出資料範圍
                if (getAmount > 0) _records = _records.Skip(skipAmount).Take(getAmount).ToList();

                if ((_records != null) && (_records.Count > 0))
                {
                    foreach (var _obj in _records)
                    {
                        _list.Add(new crsQuizDTO()
                        {
                            #region 屬性對應
                            QuestionId = _obj.cqq_QuestionId,
                            QuizId = (Guid)_obj.cqq_QuizId,
                            PoolId = (Guid)_obj.cqq_PoolId,
                            Serial = _obj.cqq_Serial,
                            ScorePlus = _obj.cqq_ScorePlus,
                            ScoreMinus = _obj.cqq_ScoreMinus,
                            CreaterId = (Guid)_obj.cqq_CreaterId,
                            CreateTime = _obj.cqq_CreateTime
                            #endregion 屬性對應
                        }
                        );
                    }

                    _oResult = _msg.TransformResult(true, _list);


                    // Log info
                    _rLog.QuizId = QuizId;        // (新)試卷ID
                    _rLog.Comment = JsonConvert.SerializeObject(_list); // _list.ToString();     // 內容
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "QuizDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;        // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            //_rLog.CourseId = ;      // 課程ID
            //_rLog.Subject = ;       // 主題名稱
            //_rLog.OriginQuizId = ;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion 


            return _oResult;
        }
        #endregion 試卷題目清單


        #region 新增試卷題目
        public ObjResult QuestionAdd(crsQuizDTO newData)
        {
            ObjResult _oResult = new ObjResult();
            if(newData.QuizId!=null)
            { 
                System.Guid _questionId = Guid.NewGuid();

                // 序號
                var _lastSerial = (from p in E4db.crsQuizQuestion
                                   where p.cqq_QuizId == newData.QuizId
                                   orderby p.cqq_Serial descending
                                select p.cqq_Serial ).FirstOrDefault();
                newData.Serial = (_lastSerial != null) ? _lastSerial + 1 : 1;


                #region 屬性對應
                _question.cqq_QuizId = _rInfo.QuizId = newData.QuizId;
                _question.cqq_PoolId = _rInfo.PoolId = newData.PoolId;
                _question.cqq_CreaterId = _rInfo.CreaterId = newData.CreaterId;

                _rInfo.QuestionId = _question.cqq_QuestionId = _questionId;
                _rInfo.Serial = _question.cqq_Serial = newData.Serial;
                _rInfo.ScorePlus = _question.cqq_ScorePlus = newData.ScorePlus;
                _rInfo.ScoreMinus = _question.cqq_ScoreMinus = newData.ScoreMinus;
                _rInfo.CreateTime = _question.cqq_CreateTime = _updateTime;
                #endregion 屬性對應

                try
                {
                    // insert data
                    crsQuizQuestionRepository.Create(_question, true);

                    _oResult = _msg.TransformResult(true, _rInfo);

                    // Log info
                    _rLog.QuizId = newData.QuizId;        // (新)試卷ID
                    _rLog.Comment = JsonConvert.SerializeObject(_rInfo); // _question.ToString(); // 內容
                }
                catch (Exception ex)
                {
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
                }
            }
            else
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId"));


            #region  insert Log
            _rLog.IP = newData.IP;
            _rLog.UserId = newData.UserId;
            _rLog.TheTable = "QuizDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            //_rLog.CourseId = _material.CourseId;    // 課程ID
            //_rLog.Subject = updateData.Caption;    // 主題名稱
            //_rLog.OriginQuizId = quizId;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 新增試卷題目


        #region 更新試卷題目配分,順序
        public ObjResult ScoreSet(crsQuizDTO updateData)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // get record, 未判斷原建立者和修改者是否同人,建議由前端進行權限限制
                var _record = crsQuizQuestionRepository.GetFirst(a => a.cqq_QuestionId == updateData.QuestionId);
                if (_record != null)
                {

                    #region 屬性對應
                    if (updateData.ScorePlus != null) _rInfo.ScorePlus = _record.cqq_ScorePlus = updateData.ScorePlus;
                    if (updateData.ScoreMinus != null) _rInfo.ScoreMinus = _record.cqq_ScoreMinus = updateData.ScoreMinus;
                    if (updateData.Serial != null) _rInfo.Serial = _record.cqq_Serial = updateData.Serial;
                    #endregion 屬性對應

                    // Update data
                    crsQuizQuestionRepository.Update(_record, true);

                    _oResult = _msg.TransformResult(true, _rInfo);


                    // Log info
                    _rInfo.QuizId = updateData.QuestionId;
                    _rLog.QuizId = _rInfo.QuizId = updateData.QuizId;        // (新)試卷ID
                    _rLog.Comment = JsonConvert.SerializeObject(_rInfo); // _record.ToString(); // 內容
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), updateData.QuestionId.ToString())); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = updateData.IP;
            _rLog.UserId = updateData.UserId;
            _rLog.TheTable = "QuizDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;      // 錯誤訊息

            //_rLog.CourseId = _material.CourseId;    // 課程ID
            //_rLog.Subject = updateData.Caption;    // 主題名稱
            //_rLog.OriginQuizId = quizId;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 更新試卷題目配分


        #region 替換試卷題目
        public ObjResult QuestionReplace(crsQuizDTO delInfo, Guid newPoolId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // 不判斷只有建立/修改者可刪除, 在呼叫前就要判斷是否有權限異動
                var _record = crsQuizQuestionRepository.GetFirst(a => a.cqq_QuestionId == delInfo.QuestionId);

                if (_record != null)
                {
                    // Log info
                    _rLog.QuizId = _rInfo.QuizId = (Guid)_record.cqq_QuizId;
                    _rLog.Comment = "Replace Question (" + _record.cqq_QuestionId.ToString() + ")." + delInfo.PoolId.ToString() + " to " + newPoolId.ToString(); // 內容

                    _rInfo.QuestionId = _record.cqq_QuestionId;
                    _record.cqq_PoolId = _rInfo.PoolId = newPoolId;

                    // update data
                    crsQuizQuestionRepository.Update(_record, true);

                    _oResult = _msg.TransformResult(true, _rInfo);
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "QuestionId: " + delInfo.QuestionId.ToString())); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = delInfo.IP;
            _rLog.UserId = delInfo.UserId;
            _rLog.TheTable = "Quiz";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;      // 錯誤訊息

            //_rLog.QuizId = _logData.;        // (新)試卷ID
            //_rLog.CourseId = _material.CourseId;    // 課程ID
            //_rLog.Subject = updateData.Caption;    // 主題名稱
            //_rLog.OriginQuizId = quizId;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 替換試卷題目


        #region 刪除試卷題目
        public ObjResult QuestionDel(crsQuizDTO delInfo)
        {
            ObjResult _oResult = new ObjResult();
            try
            {   // 不判斷只有建立/修改者可刪除, 在呼叫前就要判斷是否有權限異動
                var _record = crsQuizQuestionRepository.GetFirst(a => a.cqq_QuestionId == delInfo.QuestionId);

                if (_record != null)
                {
                    // Log info
                    _rLog.QuestionId = _rInfo.QuestionId = _record.cqq_QuestionId;
                    _rLog.QuizId = (Guid)_record.cqq_QuizId;
                    _rLog.Comment = "Deleted QuestionId:" + _rLog.QuestionId.ToString(); // 內容

                    crsQuizQuestionRepository.Delete(_record, true);

                    _oResult = _msg.TransformResult(true, _rInfo);
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "QuestionId: " + delInfo.QuestionId.ToString())); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = delInfo.IP;
            _rLog.UserId = delInfo.UserId;
            _rLog.TheTable = "QuizDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;      // 錯誤訊息

            //_rLog.QuizId = _logData.;        // (新)試卷ID
            //_rLog.CourseId = _material.CourseId;    // 課程ID
            //_rLog.Subject = updateData.Caption;    // 主題名稱
            //_rLog.OriginQuizId = quizId;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 刪除試卷題目

        #endregion 試卷題目

        #region 試卷出題
        public ObjResult QuestionAssign(Guid UserId, String IP, Guid QuizId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                _quiz = crsQuizRepository.GetFirst(a => a.cq_QuizId == QuizId);

                if (_record != null)
                    if (_quiz.cq_QuestionSetting != null)
                    {
                        // 出題數量: 自行出題|自選題目|題庫隨機出題|題庫特定類型取得|題型|難度
                        List<Guid> _pool = new List<Guid>();
                        List<Guid> _poolId = new List<Guid>();
                        string[] _questionSet = (_quiz.cq_QuestionSetting).Split('|');
                        _poolId = crsQuizQuestionRepository.Get(a => a.cqq_QuizId == QuizId).OrderBy(a=>a.cqq_Serial).Select(a => (Guid)a.cqq_PoolId).ToList();

                        #region 題庫隨機出題
                        int n;
                        int _setCount = (int.TryParse(_questionSet[2], out n))?Convert.ToInt32(_questionSet[2]):0;
                        if (_setCount > 0)
                        {
                            _pool = crsQuestionPoolRepository.Get(a => a.cqp_CourseId == _quiz.cq_CourseId).OrderBy(a => Guid.NewGuid()).Select(a => (Guid)a.cqp_PoolId).ToList();
                            foreach (Guid _id in _pool)
                            if (_poolId.FindAll(a => a.ToString() == _id.ToString()).Count() == 0)
                            {
                                _poolId.Add(_id);
                                _setCount = _setCount - 1;
                                if (_setCount == 0) break;
                            }
                        }
                        #endregion

                        #region 題庫特定類型取得
                        _setCount = (int.TryParse(_questionSet[3], out n))?Convert.ToInt32(_questionSet[3]):0;
                        if (_setCount > 0)
                        {
                            if(int.TryParse(_questionSet[4], out n) && int.TryParse(_questionSet[5], out n))
                                _pool = crsQuestionPoolRepository.Get(a => a.cqp_CourseId == _quiz.cq_CourseId && a.cqp_Category==Convert.ToInt32(_questionSet[4]) && 
                                        a.cqp_Difficult==Convert.ToInt32(_questionSet[5])).OrderBy(a => Guid.NewGuid()).Select(a => (Guid)a.cqp_PoolId).ToList();
                            if(int.TryParse(_questionSet[4], out n) )
                                _pool = crsQuestionPoolRepository.Get(a => a.cqp_CourseId == _quiz.cq_CourseId && a.cqp_Category==Convert.ToInt32(_questionSet[4])).OrderBy(a => Guid.NewGuid()).Select(a => (Guid)a.cqp_PoolId).ToList();
                            if (int.TryParse(_questionSet[5], out n))
                                _pool = crsQuestionPoolRepository.Get(a => a.cqp_CourseId == _quiz.cq_CourseId && a.cqp_Difficult == Convert.ToInt32(_questionSet[5])).OrderBy(a => Guid.NewGuid()).Select(a => (Guid)a.cqp_PoolId).ToList();
                            else _pool = null;

                            foreach (Guid _id in _pool)
                            if (_poolId.FindAll(a => a.ToString() == _id.ToString()).Count() == 0)
                            {
                                _poolId.Add(_id);
                                _setCount = _setCount - 1;
                                if (_setCount == 0) break;
                            }
                        }
                        #endregion

                        // 隨機排序
                        if(_quiz.cq_IsDisorder==true)     
                            _poolId = _poolId.OrderBy(a=>new Guid()).ToList();

                        if (_poolId.Count() > _quiz.cq_TotalQuestion) 
                            _poolId.RemoveRange((int)_quiz.cq_TotalQuestion, (_poolId.Count() - (int)_quiz.cq_TotalQuestion));
                        if (_poolId.Count() < _quiz.cq_TotalQuestion)
                                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgLacking"), _msg.Get("objQuestion")));
                        else _oResult = _msg.TransformResult(true, _poolId);

                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgIncomplete"), _msg.Get("objQuestion") + _msg.Get("actSetting")));
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.QuizId = QuizId; 
            
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "Pool";              // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;      // 錯誤訊息

            //_rLog.QuizId = _logData.;        // (新)試卷ID
            //_rLog.CourseId = _material.CourseId;    // 課程ID
            //_rLog.Subject = updateData.Caption;    // 主題名稱
            //_rLog.OriginQuizId = quizId;  // 原始(來源)試卷ID
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 試卷出題


        #region 試題庫-試題草稿

        //#region 試題草稿清單 --- old code disabled
        //public ObjResult PoolDraftList(Guid UserId, String IP, Boolean isCourseId, Guid? CourseId, Int32 skipAmount, Int32 getAmount)
        //{
        //    ObjResult _oResult = new ObjResult();
        //    List<crsQuizDTO> _list = new List<crsQuizDTO>();
        //    try
        //    {
        //        bool _isPermited = false;
        //        Guid[] _jointPoolId = null;  // 共同/分享的試題
        //        var _records = crsQuestionPoolDraftRepository.GetAll().ToList();

        //        #region 取出可用試題
        //        if (isCourseId)  // 撈出該課號所有試卷草稿
        //        {
        //            CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)CourseId, UserId);
        //            _isPermited = _coursePermissions.Quiz;
        //            _records = crsQuestionPoolDraftRepository.Get(a => a.cqpd_CourseId == CourseId && (a.cqpd_AcrossCourse == true || _isPermited == true)).ToList();

        //            // 共同/分享的試題Id
        //            if (_isPermited == true)
        //                _jointPoolId = (from p in E4db.crsPublicUnitPermit
        //                                join q in E4db.crsQuestionPoolDraft on p.cpup_UnitId equals q.cqpd_PoolId
        //                                where p.cpup_View == true && p.cpup_KeyId == CourseId
        //                                select q.cqpd_PoolId).ToArray();
        //        }
        //        else  // 撈出使用者編譯過的試卷草稿
        //        {
        //            _records = crsQuestionPoolDraftRepository.Get(a => a.cqpd_CreaterId == UserId || a.cqpd_EditorId == UserId).ToList();

        //            // 共同/分享的試題Id
        //            _jointPoolId = (from p in E4db.crsPublicUnitPermit
        //                            join q in E4db.crsQuestionPoolDraft on p.cpup_UnitId equals q.cqpd_PoolId
        //                            join g in E35db.crsTeamMember on p.cpup_KeyId equals g.TeamId
        //                            where p.cpup_View == true && (p.cpup_KeyId == UserId || g.AccountId == UserId)
        //                            select q.cqpd_PoolId).ToArray();
        //        }

        //        // 加入 共同/分享的試題
        //        if (_jointPoolId != null)
        //            foreach (var _obj in _jointPoolId)
        //                if (_records.FindAll(a => a.cqpd_PoolId == _obj).Count() == 0)
        //                    _records.AddRange(crsQuestionPoolDraftRepository.Get(a => a.cqpd_PoolId == _obj).ToList());
        //        _records = _records.OrderByDescending(a => a.cqpd_UpdateTime).ToList();

        //        // 限制輸出資料範圍
        //        if (getAmount > 0) _records = _records.Skip(skipAmount).Take(getAmount).ToList();

        //        #endregion

        //        if ((_records != null) && (_records.Count > 0))
        //        {
        //            foreach (var _obj in _records)
        //            {
        //                // 判斷資料鎖定是否已逾期(超過6小時)
        //                crsQuizDTO _temp = new crsQuizDTO();
        //                TimeSpan _gapLocked = (_obj.cqpd_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqpd_LockedTime) : _updateTime.Subtract(_updateTime); //鎖定日期相減
        //                TimeSpan _gapUpdate = (_obj.cqpd_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqpd_UpdateTime) : _updateTime.Subtract(_updateTime); //更新日期相減
        //                _temp.Locked = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? false : true;
        //                _temp.LockedRemark = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqpd_LockedRemark;
        //                _temp.LockedUser = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqpd_LockedUser;
        //                _temp.TheTable = "PoolDraft";
        //                if (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) Lock(_temp);  // 將資料解鎖

        //                _list.Add(new crsQuizDTO()
        //                {
        //                    #region 屬性對應
        //                    PoolId = _obj.cqpd_PoolId,
        //                    OriginalGroupId = _obj.cqpd_OriginalGroupId,
        //                    CreaterId = _obj.cqpd_CreaterId,
        //                    CreateTime = _obj.cqpd_CreateTime,
        //                    EditorId = _obj.cqpd_EditorId,
        //                    UpdateTime = _obj.cqpd_UpdateTime,
        //                    Unit = _obj.cqpd_Unit,
        //                    Topic = _obj.cqpd_Topic,
        //                    AcrossCourse = _obj.cqpd_AcrossCourse,
        //                    Category = _obj.cqpd_Category,
        //                    Difficult = _obj.cqpd_Difficult,
        //                    Grade = _obj.cqpd_Grade,
        //                    Subject = _obj.cqpd_Subject,
        //                    Comment = _obj.cqpd_Comment,
        //                    Locked = _temp.Locked,
        //                    LockedUser = _temp.LockedUser,
        //                    LockedTime = _temp.LockedTime,
        //                    LockedRemark = _temp.LockedRemark,
        //                    Permited = (_isPermited == true && _temp.Locked != true) ? true : false
        //                    #endregion 屬性對應
        //                });
        //            }

        //            _oResult = _msg.TransformResult(true, _list);

        //        }
        //        else
        //            _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx

        //    }
        //    catch (Exception ex)
        //    {
        //        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
        //    }

        //    #region  insert Log
        //    _rLog.IP = IP;
        //    _rLog.UserId = UserId;
        //    _rLog.TheTable = "PoolDraft";         // 指定資料表
        //    _rLog.BeginDate = _updateTime;        // 開始時間
        //    _rLog.EndDate = DateTime.Now;         // 結束時間
        //    _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
        //    _rLog.Success = _oResult.Success;        // 執行成功
        //    _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

        //    _rLog.Comment = JsonConvert.SerializeObject(_list); // _list.ToString();     // 內容
        //    //_rLog.PoolId = ;        // 目的(新)題庫ID	
        //    //_rLog.Subject = ;        // 主題名稱	
        //    //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
        //    _log.ExamLog(_rLog);
        //    #endregion


        //    return _oResult;
        //}
        //#endregion 試卷草稿清單


        #region 試題草稿清單
        public ObjResult PoolDraftList(Guid UserId, String IP, Boolean isCourseId, Guid? CourseId, Int32 skipAmount, Int32 getAmount, Boolean onlyOwnData)
        {
            ObjResult _oResult = new ObjResult();
            ObjResult _chResult = new ObjResult();
            List<crsQuestionPoolDraft> _records = new List<crsQuestionPoolDraft>();       // 個人有權查閱的試題
            List<crsQuestionPoolDraft> _jointRecords = new List<crsQuestionPoolDraft>();  // 他人分享的試題
            objectGroupDTO _group = new objectGroupDTO();
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            List<crsQuizDTO> _groupList = new List<crsQuizDTO>();
            try
            {
                bool _isPermited = false;
                List<Guid> _CourseId = new List<Guid>();     // 課程
                List<Guid> _jointPoolId = new List<Guid>();  // 共同/分享的試題

                #region 取出可用試題
                if (isCourseId)  // 撈出該課號所有試卷草稿
                {
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)CourseId, UserId);
                    _isPermited = (_coursePermissions != null)?_coursePermissions.Quiz:false;
                    _records = crsQuestionPoolDraftRepository.Get(a => a.cqpd_CourseId == CourseId && (a.cqpd_AcrossCourse == true || _isPermited == true)).ToList();

                    #region 共同/分享的試題Id
                    if (_isPermited == true && onlyOwnData == false)
                        _jointPoolId = (from p in E4db.crsPublicUnitPermit
                                        join q in E4db.crsQuestionPoolDraft on p.cpup_UnitId equals q.cqpd_PoolId
                                        where p.cpup_View == true && p.cpup_KeyId == CourseId
                                        select q.cqpd_PoolId).ToList();
                    #endregion
                }
                else  // 撈出使用者編譯過的試卷草稿
                {
                    _records = crsQuestionPoolDraftRepository.Get(a => a.cqpd_CreaterId == UserId || a.cqpd_EditorId == UserId).ToList();

                    #region 共同/分享的試題Id
                    if (onlyOwnData == false)
                    {
                        List<Guid> _temp = new List<Guid>();
                        _temp = (from p in E35db.autRCrsTea
                                 where p.TeacherId == UserId
                                 select (p.CourseId)).ToList();

                        // 篩選出有權限檢視的課程
                        foreach (var _obj in _temp)
                        {
                            CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)_obj, UserId);
                            if (_coursePermissions != null)
                            if (_coursePermissions.Quiz == true) _CourseId.Add(_obj);
                        }

                        // 共同/分享的試題Id
                        _jointPoolId = (from p in E4db.crsPublicUnitPermit
                                        join q in E4db.crsQuestionPoolDraft on p.cpup_UnitId equals q.cqpd_PoolId
                                        join g in E35db.crsTeamMember on p.cpup_KeyId equals g.TeamId
                                        where p.cpup_View == true && (p.cpup_KeyId == UserId || g.AccountId == UserId || (_CourseId.Contains((Guid)q.cqpd_CourseId) && _CourseId.Contains((Guid)p.cpup_KeyId)))
                                        select q.cqpd_PoolId).ToList();
                    }
                    #endregion
                }

                #region 移除重複 共同/分享的試題
                if (_jointPoolId != null)
                {
                    _jointRecords = crsQuestionPoolDraftRepository.Get(a => _jointPoolId.Contains((Guid)a.cqpd_PoolId)).ToList();
                    foreach (var _obj in _jointRecords)
                        if (_records.Contains(_obj) == true) _jointRecords.Remove(_obj);
                }
                #endregion

                #endregion

                if ((_records.Count > 0) || (_jointRecords.Count > 0))
                {
                    #region MainData
                    foreach (var _obj in _records)
                    {
                        // 判斷資料鎖定是否已逾期(超過6小時)
                        crsQuizDTO _temp = new crsQuizDTO();
                        TimeSpan _gapLocked = (_obj.cqpd_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqpd_LockedTime) : _updateTime.Subtract(_updateTime); //鎖定日期相減
                        TimeSpan _gapUpdate = (_obj.cqpd_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqpd_UpdateTime) : _updateTime.Subtract(_updateTime); //更新日期相減
                        _temp.Locked = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? false : true;
                        _temp.LockedRemark = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqpd_LockedRemark;
                        _temp.LockedUser = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqpd_LockedUser;
                        _temp.TheTable = "PoolDraft";
                        if (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) Lock(_temp);  // 將資料解鎖

                        _list.Add(new crsQuizDTO()
                        {
                            #region 屬性對應
                            PoolId = _obj.cqpd_PoolId,
                            OriginalGroupId = _obj.cqpd_OriginalGroupId,
                            CreaterId = _obj.cqpd_CreaterId,
                            CreateTime = _obj.cqpd_CreateTime,
                            EditorId = _obj.cqpd_EditorId,
                            UpdateTime = _obj.cqpd_UpdateTime,
                            Unit = _obj.cqpd_Unit,
                            Topic = _obj.cqpd_Topic,
                            AcrossCourse = _obj.cqpd_AcrossCourse,
                            Category = _obj.cqpd_Category,
                            Difficult = _obj.cqpd_Difficult,
                            Grade = _obj.cqpd_Grade,
                            Subject = _obj.cqpd_Subject,
                            Comment = _obj.cqpd_Comment,
                            Locked = _temp.Locked,
                            LockedUser = _temp.LockedUser,
                            LockedTime = _temp.LockedTime,
                            LockedRemark = _temp.LockedRemark,
                            Permited = (_isPermited == true && _temp.Locked != true) ? true : false
                            #endregion 屬性對應
                        });
                    }
                    _groupList = _list;

                    // 限制輸出資料範圍
                    if (getAmount > 0 && _list != null) _list = _list.Skip(skipAmount).Take(getAmount).ToList();
                    _group.MainData = _list;
                    #endregion

                    #region ShareData
                    _list = null;
                    foreach (var _obj in _jointRecords)
                    {
                        // 判斷資料鎖定是否已逾期(超過6小時)
                        crsQuizDTO _temp = new crsQuizDTO();
                        TimeSpan _gapLocked = (_obj.cqpd_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqpd_LockedTime) : _updateTime.Subtract(_updateTime); //鎖定日期相減
                        TimeSpan _gapUpdate = (_obj.cqpd_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqpd_UpdateTime) : _updateTime.Subtract(_updateTime); //更新日期相減
                        _temp.Locked = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? false : true;
                        _temp.LockedRemark = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqpd_LockedRemark;
                        _temp.LockedUser = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqpd_LockedUser;
                        _temp.TheTable = "PoolDraft";
                        if (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) Lock(_temp);  // 將資料解鎖

                        _list.Add(new crsQuizDTO()
                        {
                            #region 屬性對應
                            PoolId = _obj.cqpd_PoolId,
                            OriginalGroupId = _obj.cqpd_OriginalGroupId,
                            CreaterId = _obj.cqpd_CreaterId,
                            CreateTime = _obj.cqpd_CreateTime,
                            EditorId = _obj.cqpd_EditorId,
                            UpdateTime = _obj.cqpd_UpdateTime,
                            Unit = _obj.cqpd_Unit,
                            Topic = _obj.cqpd_Topic,
                            AcrossCourse = _obj.cqpd_AcrossCourse,
                            Category = _obj.cqpd_Category,
                            Difficult = _obj.cqpd_Difficult,
                            Grade = _obj.cqpd_Grade,
                            Subject = _obj.cqpd_Subject,
                            Comment = _obj.cqpd_Comment,
                            Locked = _temp.Locked,
                            LockedUser = _temp.LockedUser,
                            LockedTime = _temp.LockedTime,
                            LockedRemark = _temp.LockedRemark,
                            Permited = (_isPermited == true && _temp.Locked != true) ? true : false
                            #endregion 屬性對應
                        });
                    }
                    if (_list != null)
                    {
                        _groupList.AddRange(_list);

                        // 限制輸出資料範圍
                        if (getAmount > 0 && _list.Count() > 0) _list = _list.Skip(skipAmount).Take(getAmount).ToList();
                        _group.ShareData = _list;
                    }
                    #endregion

                    #region GroupData = MainData + ShareData
                    // 限制輸出資料範圍
                    if (getAmount > 0 && _list.Count() > 0) _groupList = _groupList.Skip(skipAmount).Take(getAmount).ToList();
                    _group.GroupData = _groupList;
                    #endregion


                    if (_groupList.Count > 0) _oResult = (onlyOwnData) ? _msg.TransformResult(true, _group.MainData) : _msg.TransformResult(true, _group);
                    else _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "PoolDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;        // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            _rLog.Comment = JsonConvert.SerializeObject(_list); // _list.ToString();     // 內容
            //_rLog.PoolId = ;        // 目的(新)題庫ID	
            //_rLog.Subject = ;        // 主題名稱	
            //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
            _log.ExamLog(_rLog);
            #endregion


            return _oResult;
        }
        #endregion 試卷草稿清單


        #region 取得試題草稿
        public ObjResult PoolDraftGet(Guid UserId, String IP, Guid PoolId, Int32 Behavior = 1, Boolean display = false)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // get record
                var _poolDraft = crsQuestionPoolDraftRepository.GetFirst(a => a.cqpd_PoolId == PoolId);
                if (_poolDraft != null)
                {
                    // 判斷權限
                    bool _isPermited = false;
                    if (_poolDraft.cqpd_AcrossCourse && display) _isPermited = true;    // ViewPoolDraft時display = true, 顯示該資料, 但不可修改僅可複製
                    else
                    {
                        List<assignTeamDTO> _teamList = null;
                        CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)_poolDraft.cqpd_CourseId, UserId);
                        if (_coursePermissions.Quiz) _isPermited = true;
                        else
                        {
                            _rInfo.UnitId = PoolId;
                            _rInfo.UserId = UserId;
                            _rInfo.KeyId = UserId;
                            _oResult = PermitGet(_rInfo);   // 個人權限
                            if (_oResult.Success == false)
                            {   // 小組權限
                                _teamList = CurrentState.AssignTeamInfo((Guid)_poolDraft.cqpd_CourseId);
                                _rInfo.KeyId = _teamList.First(t => t.AccountId == UserId).TeamId;
                                _oResult = PermitGet(_rInfo);
                            }
                            //執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                            if (_oResult.Success && (Behavior == 0 || Behavior == 1)) _isPermited = (bool)((crsQuizDTO)_oResult.DataCollection).View;
                            if (_oResult.Success && (Behavior == 2 || Behavior == 6)) _isPermited = (bool)((crsQuizDTO)_oResult.DataCollection).Add;
                            if (_oResult.Success && Behavior == 3) _isPermited = (bool)((crsQuizDTO)_oResult.DataCollection).Edit;
                            if (_oResult.Success && Behavior == 4) _isPermited = (bool)((crsQuizDTO)_oResult.DataCollection).Delete;
                        }
                    }

                    if (_isPermited)
                    {
                        #region 屬性對應
                        _record.PoolId = _poolDraft.cqpd_PoolId;
                        _record.CourseId = (Guid)_poolDraft.cqpd_CourseId;
                        _record.OriginalGroupId = _poolDraft.cqpd_OriginalGroupId;
                        _record.CreaterId = _poolDraft.cqpd_CreaterId;
                        _record.CreateTime = _poolDraft.cqpd_CreateTime;
                        _record.EditorId = _poolDraft.cqpd_EditorId;
                        _record.UpdateTime = _poolDraft.cqpd_UpdateTime;
                        _record.Unit = _poolDraft.cqpd_Unit;
                        _record.Topic = _poolDraft.cqpd_Topic;
                        _record.AcrossCourse = _poolDraft.cqpd_AcrossCourse;
                        _record.Category = _poolDraft.cqpd_Category;
                        _record.Difficult = _poolDraft.cqpd_Difficult;
                        _record.Grade = _poolDraft.cqpd_Grade;
                        _record.Subject = _poolDraft.cqpd_Subject;
                        _record.Comment = _poolDraft.cqpd_Comment;
                        _record.Locked = _poolDraft.cqpd_Locked;
                        _record.LockedRemark = _poolDraft.cqpd_LockedRemark;
                        _record.LockedTime = _poolDraft.cqpd_LockedTime;
                        _record.LockedUser = _poolDraft.cqpd_LockedUser;
                        #endregion 屬性對應

                        _oResult = _msg.TransformResult(true, _record);


                        // Log info
                        _rLog.PoolId = _record.PoolId;        // 目的(新)題庫ID	
                        _rLog.Subject = _record.Topic;        // 主題名稱	
                        _rLog.Comment = JsonConvert.SerializeObject(_record); // _record.ToString();     // 內容
                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actGet").ToLower(), _msg.Get("objQuestion"))); // You do not have permission  to {0} {1} !
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "PoolId: " + PoolId.ToString())); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "PoolDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 1;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;        // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
            _log.ExamLog(_rLog);
            #endregion 

            return _oResult;
        }
        #endregion 取得試題草稿


        #region 新增試題草稿
        public ObjResult PoolDraftCreate(crsQuizDTO newData)
        {
            ObjResult _oResult = new ObjResult();
            System.Guid _poolId = Guid.NewGuid();

            #region 屬性對應
            _rInfo.PoolId = _poolDraft.cqpd_PoolId = _poolId;
            _rInfo.CreateTime = _poolDraft.cqpd_CreateTime = _updateTime;
            _poolDraft.cqpd_CreaterId = _rInfo.CreaterId = newData.UserId;
            _rInfo.UpdateTime = _poolDraft.cqpd_UpdateTime = _updateTime;
            _rInfo.EditorId = _poolDraft.cqpd_EditorId = (Guid)newData.UserId;
            if (newData.OriginalGroupId != null) _rInfo.OriginalGroupId = _poolDraft.cqpd_OriginalGroupId = newData.OriginalGroupId; // 體組型子題目的上層題庫ID
            if (newData.CourseId != null) _poolDraft.cqpd_CourseId = _rInfo.CourseId = newData.CourseId;
            if (newData.Unit != null) _rInfo.Unit = _poolDraft.cqpd_Unit = newData.Unit.Trim();      // 單元
            if (newData.Topic != null) _rInfo.Topic = _poolDraft.cqpd_Topic = newData.Topic.Trim();   // 主題
            _rInfo.AcrossCourse = _poolDraft.cqpd_AcrossCourse = (newData.AcrossCourse != null) ? (bool)newData.AcrossCourse : false; // 不可跨課程使用
            #endregion 屬性對應

            try
            {
                // insert data
                crsQuestionPoolDraftRepository.Create(_poolDraft, true);

                _oResult = _msg.TransformResult(true, _rInfo);


                // Log info
                _rLog.PoolId = _poolId;        // 目的(新)題庫ID	
                _rLog.Subject = newData.Topic;        // 主題名稱	
                _rLog.Comment = JsonConvert.SerializeObject(_rInfo); // _poolDraft.ToString();     // 內容
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = newData.IP;
            _rLog.UserId = newData.UserId;
            _rLog.TheTable = "PoolDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 2;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 新增試題草稿


        #region 引用試題(包含答案項)
        public ObjResult PoolDraftRecreate(Guid UserId, String IP, Guid PoolId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                System.Guid _newId = Guid.NewGuid();

                // get record
                var _pool = crsQuestionPoolRepository.GetFirst(a => a.cqp_PoolId == PoolId);
                if (_pool!=null)
                { 
                    #region 屬性對應
                    _rInfo.CreateTime = _poolDraft.cqpd_CreateTime = _pool.cqp_CreateTime;
                    _rInfo.CreaterId = _poolDraft.cqpd_CreaterId = _pool.cqp_CreaterId;
                    _rInfo.UpdateTime = _poolDraft.cqpd_UpdateTime = _pool.cqp_UpdateTime;
                    _rInfo.EditorId = _poolDraft.cqpd_EditorId = _pool.cqp_EditorId;

                    _rInfo.PoolId = _poolDraft.cqpd_PoolId = _newId;
                    _poolDraft.cqpd_CourseId = _rInfo.CourseId = (Guid)_poolDraft.cqpd_CourseId;    // 課程識別碼
                    _rInfo.OriginalGroupId = _poolDraft.cqpd_OriginalGroupId = _pool.cqp_OriginalGroupId; // 體組型子題目的上層題庫ID
                    _rInfo.Unit = _poolDraft.cqpd_Unit = _pool.cqp_Unit;      // 單元
                    _rInfo.Topic = _poolDraft.cqpd_Topic = _pool.cqp_Topic;   // 主題
                    _rInfo.AcrossCourse = _poolDraft.cqpd_AcrossCourse = (bool)_poolDraft.cqpd_AcrossCourse; // 是否跨課程使用
                    _rInfo.Category = _poolDraft.cqpd_Category = (int)_poolDraft.cqpd_Category;       // 題型
                    _rInfo.Difficult = _poolDraft.cqpd_Difficult = (int)_poolDraft.cqpd_Difficult;    // 難易度
                    _rInfo.Grade = _poolDraft.cqpd_Grade = _pool.cqp_Grade;       // 參考分數
                    _rInfo.Subject = _poolDraft.cqpd_Subject = _pool.cqp_Subject;   // 題目
                    _rInfo.Comment = _poolDraft.cqpd_Comment = _pool.cqp_Comment;   // 備註
                    #endregion 屬性對應

                    // insert data
                    crsQuestionPoolDraftRepository.Create(_poolDraft, true);
                    var _temp = OptionRecreate(UserId, IP, PoolId, _newId); // 引用答案項
                    _rInfo.OptionList = (_temp.Success) ? _temp.DataCollection : null;

                    _oResult = _msg.TransformResult(true, _rInfo);

                    // Log info
                    _rLog.OriginPoolId = PoolId;        // 原始(來源)題庫ID	                
                    _rLog.PoolId = _poolDraft.cqpd_PoolId;        // 目的(新)題庫ID	
                    _rLog.Subject = _poolDraft.cqpd_Topic;        // 主題名稱	
                    _rLog.Comment = JsonConvert.SerializeObject(_rInfo); // _poolDraft.ToString();     // 內容
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "PoolId:" + PoolId));
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "PoolDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 6;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion


        #region 更新試題草稿
        public ObjResult PoolDraftUpdate(crsQuizDTO updateData)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // get record, 未判斷原建立者和修改者是否同人,建議由前端進行權限限制
                var _poolDraft = crsQuestionPoolDraftRepository.GetFirst(a => a.cqpd_PoolId == updateData.PoolId && a.cqpd_LockedUser == updateData.UserId && a.cqpd_Locked == true);
                if (_poolDraft != null)
                {

                    #region 屬性對應
                    _rInfo.UpdateTime = _poolDraft.cqpd_UpdateTime = _updateTime;
                    _rInfo.EditorId = _poolDraft.cqpd_EditorId = updateData.UserId;
                    if (updateData.OriginalGroupId != null) _rInfo.OriginalGroupId = _poolDraft.cqpd_OriginalGroupId = updateData.OriginalGroupId; // 體組型子題目的上層題庫ID
                    if (updateData.CourseId != null) _poolDraft.cqpd_CourseId = _rInfo.CourseId = updateData.CourseId;    // 課程識別碼
                    if (updateData.Unit != null) _rInfo.Unit = _poolDraft.cqpd_Unit = updateData.Unit.Trim();      // 單元
                    if (updateData.Topic != null) _rInfo.Topic = _poolDraft.cqpd_Topic = updateData.Topic.Trim();   // 主題
                    if (updateData.AcrossCourse != null) _rInfo.AcrossCourse = _poolDraft.cqpd_AcrossCourse = (bool)updateData.AcrossCourse; // 是否跨課程使用
                    if (updateData.Category != null) _rInfo.Category = _poolDraft.cqpd_Category = (int)updateData.Category;       // 題型
                    if (updateData.Difficult != null) _rInfo.Difficult = _poolDraft.cqpd_Difficult = (int)updateData.Difficult;    // 難易度
                    if (updateData.Grade != null) _rInfo.Grade = _poolDraft.cqpd_Grade = (decimal)updateData.Grade;        // 參考分數
                    if (updateData.Subject != null) _rInfo.Subject = _poolDraft.cqpd_Subject = updateData.Subject.Trim();    // 題目
                    if (updateData.Comment != null) _rInfo.Comment = _poolDraft.cqpd_Comment = updateData.Comment.Trim();    // 備註
                    #endregion 屬性對應

                    // Update data
                    crsQuestionPoolDraftRepository.Update(_poolDraft, true);

                    
                    _oResult = _msg.TransformResult(true, _rInfo);

                    // Log info
                    _rLog.PoolId = updateData.PoolId;        // 目的(新)題庫ID	
                    _rLog.Subject = updateData.Topic;        // 主題名稱	
                    _rLog.Comment = JsonConvert.SerializeObject(_rInfo); // _poolDraft.ToString();     // 內容
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "PoolId: "+updateData.PoolId.ToString())); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = updateData.IP;
            _rLog.UserId = updateData.UserId;
            _rLog.TheTable = "PoolDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;

            //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 更新試卷草稿


        #region 刪除試題草稿
        public ObjResult PoolDraftDelete(Guid UserId, String IP, Guid PoolId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                _rLog.PoolId = PoolId;        // 目的(新)題庫ID	
                var _quizRecord = crsQuestionPoolDraftRepository.GetFirst(a => a.cqpd_PoolId == PoolId && (a.cqpd_CreaterId == UserId || a.cqpd_EditorId == UserId));
                if (_quizRecord!=null)
                {
                    crsQuestionPoolDraftRepository.Delete(_quizRecord, true);

                    _rInfo.PoolId = PoolId;

                    _oResult = _msg.TransformResult(true, _rInfo);
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "PoolId:" + PoolId));

            }
            catch (Exception ex)
            {
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "PoolDraft";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 4;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;     // 錯誤訊息
            
            //_rLog.Subject = ;        // 主題名稱	
            //_rLog.Comment = newData.ToString();     // 內容
            //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 刪除試題草稿

        #endregion 試題庫-試題草稿

        #region 試題庫-正式試題

        //#region 試題紀錄清單 --- old code disabled
        //public ObjResult PoolRecords(Guid UserId, String IP, Boolean isDeleted, Boolean isCourseId, Guid CourseId, Int32 skipAmount, Int32 getAmount)
        //{
        //    ObjResult _oResult = new ObjResult();
        //    List<crsQuizDTO> _list = new List<crsQuizDTO>();
        //    try
        //    {
        //        bool _isPermited = true;
        //        Guid[] _jointPoolId = null;  // 共同/分享的試題
        //        var _records = crsQuestionPoolRepository.GetAll().ToList();

        //        #region 取出可用試題
        //        if (isCourseId)  // 撈出該課號所有試卷
        //        {
        //            CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)CourseId, UserId);
        //            _isPermited = _coursePermissions.Quiz;
        //            _records = crsQuestionPoolRepository.Get(a => a.cqp_CourseId == CourseId && a.cqp_IsDeleted == isDeleted && (a.cqp_AcrossCourse == true || _isPermited == true))
        //                                                .OrderByDescending(a => a.cqp_UpdateTime).ToList();

        //            // 共同/分享的試題Id
        //            if (_isPermited == true)
        //                _jointPoolId = (from p in E4db.crsPublicUnitPermit
        //                                join q in E4db.crsQuestionPool on p.cpup_UnitId equals q.cqp_PoolId
        //                                where p.cpup_View == true && (q.cqp_CourseId == CourseId && p.cpup_KeyId == CourseId)
        //                                select q.cqp_PoolId).ToArray();
        //        }
        //        else  // 撈出使用者編譯過的試卷
        //        {
        //            _records = crsQuestionPoolRepository.Get(a => a.cqp_CreaterId == UserId || a.cqp_EditorId == UserId)
        //                                                .OrderByDescending(a => a.cqp_UpdateTime).ToList();

        //            // 共同/分享的試題Id
        //            _jointPoolId = (from p in E4db.crsPublicUnitPermit
        //                            join q in E4db.crsQuestionPool on p.cpup_UnitId equals q.cqp_PoolId
        //                            join g in E35db.crsTeamMember on p.cpup_KeyId equals g.TeamId
        //                            where p.cpup_View == true && (p.cpup_KeyId == UserId || g.AccountId == UserId)
        //                            select q.cqp_PoolId).ToArray();
        //        }

        //        // 加入 共同/分享的試題
        //        if (_jointPoolId != null)
        //            foreach (var _obj in _jointPoolId)
        //                if (_records.FindAll(a => a.cqp_PoolId == _obj).Count() == 0)
        //                    _records.AddRange(crsQuestionPoolRepository.Get(a => a.cqp_PoolId == _obj).ToList());
        //        _records = _records.OrderByDescending(a => a.cqp_UpdateTime).ToList();

        //        // 限制輸出資料範圍
        //        if (getAmount > 0) _records = _records.Skip(skipAmount).Take(getAmount).ToList();
        //        #endregion

        //        if ((_records != null) && (_records.Count > 0))
        //        {
        //            foreach (var _obj in _records)
        //            {
        //                _list.Add(new crsQuizDTO()
        //                {
        //                    #region 屬性對應
        //                    PoolId = _obj.cqp_PoolId,
        //                    CreateTime = _obj.cqp_CreateTime,
        //                    CreaterId = _obj.cqp_CreaterId,
        //                    UpdateTime = _obj.cqp_UpdateTime,
        //                    EditorId = _obj.cqp_EditorId,
        //                    OriginalGroupId = _obj.cqp_OriginalGroupId, // 體組型子題目的上層題庫ID
        //                    CourseId = (Guid)_obj.cqp_CourseId,    // 課程識別碼
        //                    Unit = _obj.cqp_Unit,      // 單元
        //                    Topic = _obj.cqp_Topic,   // 主題
        //                    AcrossCourse = _obj.cqp_AcrossCourse, // 是否跨課程使用
        //                    Category = _obj.cqp_Category,       // 題型
        //                    Difficult = _obj.cqp_Difficult,    // 難易度
        //                    Grade = _obj.cqp_Grade,       // 參考分數
        //                    Subject = _obj.cqp_Subject,   // 題目
        //                    Comment = _obj.cqp_Comment,   // 備註
        //                    IsDeleted = _obj.cqp_IsDeleted,   // 紀錄刪除標記
        //                    Permited = (_isPermited == true || _obj.cqp_AcrossCourse == true) ? true : false
        //                    #endregion 屬性對應
        //                }
        //                );
        //            }

        //            _oResult = _msg.TransformResult(true, _list);
        //        }
        //        else
        //            _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx
        //    }
        //    catch (Exception ex)
        //    {
        //        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
        //    }

        //    #region  insert Log
        //    _rLog.IP = IP;
        //    _rLog.UserId = UserId;
        //    _rLog.TheTable = "Pool";         	  // 指定資料表
        //    _rLog.BeginDate = _updateTime;        // 開始時間
        //    _rLog.EndDate = DateTime.Now;         // 結束時間
        //    _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
        //    _rLog.Success = _oResult.Success;        // 執行成功
        //    _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

        //    _rLog.Comment = JsonConvert.SerializeObject(_list); // _list.ToString();     // 內容
        //    //_rLog.PoolId = ;        // 目的(新)題庫ID	
        //    //_rLog.Subject = ;        // 主題名稱	
        //    //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
        //    _log.ExamLog(_rLog);
        //    #endregion


        //    return _oResult;
        //}
        //#endregion 試題紀錄清單


        #region 試題紀錄清單
        public ObjResult PoolRecords(Guid UserId, String IP, Boolean isDeleted, Boolean isCourseId, Guid CourseId, Int32 skipAmount, Int32 getAmount, Boolean onlyOwnData)
        {
            ObjResult _oResult = new ObjResult();
            ObjResult _chResult = new ObjResult();
            List<crsQuestionPool> _records = new List<crsQuestionPool>();       // 個人有權查閱的試題
            List<crsQuestionPool> _jointRecords = new List<crsQuestionPool>();  // 他人分享的試題
            objectGroupDTO _group = new objectGroupDTO();
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            List<crsQuizDTO> _groupList = new List<crsQuizDTO>();
            try
            {
                bool _isPermited = true;
                List<Guid> _CourseId = new List<Guid>();    // 課程
                List<Guid> _jointPoolId = new List<Guid>();  // 共同/分享的試題

                #region 取出可用試題
                if (isCourseId)  // 撈出該課號所有試卷
                {
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)CourseId, UserId);
                    _isPermited = (_coursePermissions != null)?_coursePermissions.Quiz:false;
                    _records = crsQuestionPoolRepository.Get(a => a.cqp_CourseId == CourseId && a.cqp_IsDeleted == isDeleted && (a.cqp_AcrossCourse == true || _isPermited == true))
                                                        .OrderByDescending(a => a.cqp_UpdateTime).ToList();

                    #region 共同/分享的試題Id
                    if (_isPermited == true && onlyOwnData == false)
                        _jointPoolId = (from p in E4db.crsPublicUnitPermit
                                        join q in E4db.crsQuestionPool on p.cpup_UnitId equals q.cqp_PoolId
                                        where p.cpup_View == true && (q.cqp_CourseId == CourseId && p.cpup_KeyId == CourseId)
                                        select q.cqp_PoolId).ToList();
                    #endregion
                }
                else  // 撈出使用者編譯過的試卷
                {
                    _records = crsQuestionPoolRepository.Get(a => a.cqp_CreaterId == UserId || a.cqp_EditorId == UserId)
                                                        .OrderByDescending(a => a.cqp_UpdateTime).ToList();
                    #region 共同/分享的試題Id
                    if (onlyOwnData == false)
                    {
                        _CourseId = (from p in E35db.autRCrsTea
                                     where p.TeacherId == UserId
                                     select (p.CourseId)).ToList();
                        // 共同/分享的試題Id
                        _jointPoolId = (from p in E4db.crsPublicUnitPermit
                                        join q in E4db.crsQuestionPool on p.cpup_UnitId equals q.cqp_PoolId
                                        join g in E35db.crsTeamMember on p.cpup_KeyId equals g.TeamId
                                        where p.cpup_View == true && (p.cpup_KeyId == UserId || g.AccountId == UserId || (_CourseId.Contains((Guid)q.cqp_CourseId) && _CourseId.Contains((Guid)p.cpup_KeyId)))
                                        select q.cqp_PoolId).ToList();
                    }
                    #endregion
                }

                #region 移除重複 共同/分享的試題
                if (_jointPoolId != null)
                {
                    _jointRecords = crsQuestionPoolRepository.Get(a => _jointPoolId.Contains((Guid)a.cqp_PoolId)).ToList();
                    foreach (var _obj in _jointRecords)
                        if (_records.Contains(_obj) == true) _jointRecords.Remove(_obj);
                }
                #endregion

                #endregion

                // 排序
                _records = _records.OrderByDescending(a => a.cqp_CreateTime.Year).OrderBy(a => a.cqp_Unit).OrderBy(a => a.cqp_Topic).ToList();
                _jointRecords = _jointRecords.OrderByDescending(a => a.cqp_CreateTime.Year).OrderBy(a => a.cqp_Unit).OrderBy(a => a.cqp_Topic).ToList();
                if (((_records != null) && (_records.Count > 0)) || ((_jointRecords != null) && (_jointRecords.Count > 0)))
                {
                    #region MainData
                    if (_records != null)
                    {
                        _chResult = PoolSearchDataFilter(_records, UserId);
                        if (_chResult.Success)
                        {
                            _list = (List<crsQuizDTO>)_chResult.DataCollection;
                            _groupList = _list;

                            // 限制輸出資料範圍
                            if (getAmount > 0 && _list.Count() > 0) _list = _list.Skip(skipAmount).Take(getAmount).ToList();
                            _group.MainData = _list;
                        }
                    }
                    #endregion

                    #region ShareData
                    if (_jointRecords != null)
                    {
                        _chResult = PoolSearchDataFilter(_jointRecords, UserId);
                        if (_chResult.Success)
                        {
                            _list = (List<crsQuizDTO>)_chResult.DataCollection;
                            _groupList.AddRange(_list);

                            // 限制輸出資料範圍
                            if (getAmount > 0 && _list.Count() > 0) _list = _list.Skip(skipAmount).Take(getAmount).ToList();
                            _group.ShareData = _list;
                        }
                    }
                    #endregion

                    #region GroupData = MainData + ShareData
                    // 限制輸出資料範圍
                    if (getAmount > 0 && _list.Count() > 0) _groupList = _groupList.Skip(skipAmount).Take(getAmount).ToList();
                    _group.GroupData = _groupList;
                    #endregion

                    if (_groupList != null) _oResult = (onlyOwnData) ? _msg.TransformResult(true, _group.MainData) : _msg.TransformResult(true, _group);
                    else _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "Pool";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;        // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            _rLog.Comment = JsonConvert.SerializeObject(_list); // _list.ToString();     // 內容
            //_rLog.PoolId = ;        // 目的(新)題庫ID	
            //_rLog.Subject = ;        // 主題名稱	
            //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
            _log.ExamLog(_rLog);
            #endregion


            return _oResult;
        }
        #endregion 試題紀錄清單


        #region 試題使用狀態 -- 新
        public ObjResult PoolGetProcess(crsQuizDTO updateData)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                bool _answered = (from p in E4db.crsQuizQuestion
                                    join a in E4db.crsQuizSubmitAnswer on p.cqq_PoolId equals a.cqsa_PoolId
                                    where p.cqq_PoolId == updateData.PoolId
                                    select (a.cqsa_PoolId)).Count()>0;
                bool _inOtherQuiz = (from p in E4db.crsQuizQuestion
                                   join q in E4db.crsQuiz on p.cqq_QuizId equals q.cq_QuizId
                                     where p.cqq_PoolId == updateData.PoolId && p.cqq_QuizId != updateData.QuizId
                                   select (p.cqq_QuizId)).Count() > 0;
                bool _inProcess = (from p in E4db.crsQuizQuestion
                                   join q in E4db.crsQuiz on p.cqq_QuizId equals q.cq_QuizId
                                   where p.cqq_PoolId == updateData.PoolId && p.cqq_QuizId == updateData.QuizId && q.cq_EndDate > _updateTime
                                   select (p.cqq_QuizId)).Count() > 0;

                if (_answered)          // 試題已被使用於答案卷, 無法修改
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgWasUsed") + _msg.Get("msgCnatModify"), _msg.Get("objQuestion"), _msg.Get("objSheet")));
                else if (_inOtherQuiz)  // 試題已被使用於其他試卷, 無法修改
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgUsing") + _msg.Get("msgCnatModify"), _msg.Get("objOther") + _msg.Get("objQuiz")));
                else if (_inProcess)    // 進行中, 但可修改
                {
                    _oResult = _msg.TransformResult(true, null); // 試題使用中
                    _oResult.ErrorMessage = String.Format(_msg.Get("msgUsing"), _msg.Get("objQuiz"));
                }
                else    // 可修改
                    _oResult = _msg.TransformResult(true, null);
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = updateData.IP;
            _rLog.UserId = updateData.UserId;
            _rLog.TheTable = "Pool";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 8;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6, 公佈 = 7, 檢查 = 8
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;      // 錯誤訊息

            _rLog.PoolId = updateData.PoolId;        // 目的(新)題庫ID	
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 試題使用狀態


        //#region 搜尋試題 --- old code disabled
        //public ObjResult PoolSearch(crsQuizDTO searchFactor, String Key, Int32 skipAmount, Int32 getAmount)
        //{
        //    ObjResult _oResult = new ObjResult();
        //    Guid[] _CourseId = null;    // 課程
        //    Guid[] _jointPoolId = null;  // 共同/分享的試題
        //    List<crsQuestionPool> _records = new List<crsQuestionPool>();       // 個人有權查閱的試題
        //    List<crsQuestionPool> _jointRecords = new List<crsQuestionPool>();  // 他人分享的試題
        //    List<crsQuestionPool> _otherRecords = new List<crsQuestionPool>();  // 其他相關試題
        //    List<crsQuizDTO> _list = new List<crsQuizDTO>();
        //    objectGroupDTO _group = new objectGroupDTO();
        //    try
        //    {
        //        bool _isPermited = false;
        //        #region 取出相關試題
        //        _CourseId = (from p in E35db.autRCrsTea
        //                     join s in E35db.autRCrsStu on p.CourseId equals s.CourseId
        //                     where p.TeacherId == searchFactor.UserId || s.StudentId == searchFactor.UserId
        //                     select (p.CourseId)).ToArray();
        //        // 共同/分享的試題Id
        //        if (_isPermited == true)
        //            _jointPoolId = (from p in E4db.crsPublicUnitPermit
        //                            join q in E4db.crsQuestionPool on p.cpup_UnitId equals q.cqp_PoolId
        //                            where (p.cpup_View == true) && _CourseId.Contains((Guid)q.cqp_CourseId) && _CourseId.Contains((Guid)p.cpup_KeyId)
        //                            select q.cqp_PoolId).ToArray();

        //        _records = crsQuestionPoolRepository.Get(a => _CourseId.Contains((Guid)a.cqp_CourseId)).ToList();
        //        _jointRecords = crsQuestionPoolRepository.Get(a => _jointPoolId.Contains((Guid)a.cqp_PoolId)).ToList();
        //        foreach (var _obj in _jointRecords)
        //            if (_records.Contains(_obj) == false) _jointRecords.Remove(_obj);
        //        #endregion

        //        #region 條件限制
        //        if (Key != null)        // 關鍵字
        //        {
        //            _records = _records.FindAll(a => a.cqp_Subject.Contains(Key) || a.cqp_Topic.Contains(Key) ||
        //                        a.cqp_Unit.Contains(Key) || _CourseId.Contains((Guid)a.cqp_CourseId)).ToList();
        //            _jointRecords = _jointRecords.FindAll(a => a.cqp_Subject.Contains(Key) || a.cqp_Topic.Contains(Key) ||
        //                        a.cqp_Unit.Contains(Key) || _CourseId.Contains((Guid)a.cqp_CourseId)).ToList();
        //            // 其他課程試題
        //            _CourseId = (from p in E35db.crsCourse
        //                         where p.zhTWName.Contains(Key) || p.zhCNName.Contains(Key) || p.enUSName.Contains(Key)
        //                         select (p.CourseId)).ToArray();
        //            if (_CourseId.Count() > 0)
        //            {
        //                _otherRecords = crsQuestionPoolRepository.Get(a => _CourseId.Contains((Guid)a.cqp_CourseId)).ToList();
        //                foreach (var _obj in _otherRecords)
        //                    if (_records.Contains(_obj) == false) _otherRecords.Remove(_obj);
        //            }
        //        }

        //        if (searchFactor.Unit != null)      // 單元
        //        {
        //            _records = _records.FindAll(a => a.cqp_Unit == searchFactor.Unit).ToList();
        //            if (_jointRecords != null) _jointRecords = _records.FindAll(a => a.cqp_Unit == searchFactor.Unit).ToList();
        //            if (_otherRecords != null) _otherRecords = _records.FindAll(a => a.cqp_Unit == searchFactor.Unit).ToList();
        //        }
        //        if (searchFactor.Topic != null)     // 主題
        //        {
        //            _records = _records.FindAll(a => a.cqp_Topic == searchFactor.Topic).ToList();
        //            if (_jointRecords != null) _jointRecords = _records.FindAll(a => a.cqp_Topic == searchFactor.Topic).ToList();
        //            if (_otherRecords != null) _otherRecords = _records.FindAll(a => a.cqp_Topic == searchFactor.Topic).ToList();
        //        }
        //        if (searchFactor.Difficult > -1)    // 難度
        //        {
        //            _records = _records.FindAll(a => a.cqp_Difficult == searchFactor.Difficult).ToList();
        //            if (_jointRecords != null) _jointRecords = _records.FindAll(a => a.cqp_Difficult == searchFactor.Difficult).ToList();
        //            if (_otherRecords != null) _otherRecords = _records.FindAll(a => a.cqp_Difficult == searchFactor.Difficult).ToList();
        //        }
        //        if (searchFactor.Category > -1)     // 題型
        //        {
        //            _records = _records.FindAll(a => a.cqp_Category == searchFactor.Category).ToList();
        //            if (_jointRecords != null) _jointRecords = _records.FindAll(a => a.cqp_Category == searchFactor.Category).ToList();
        //            if (_otherRecords != null) _otherRecords = _records.FindAll(a => a.cqp_Category == searchFactor.Category).ToList();
        //        }
        //        #endregion

        //        // 排序
        //        _records = _records.OrderByDescending(a => a.cqp_CreateTime.Year).OrderBy(a => a.cqp_Unit).OrderBy(a => a.cqp_Topic).ToList();
        //        _jointRecords = _jointRecords.OrderByDescending(a => a.cqp_CreateTime.Year).OrderBy(a => a.cqp_Unit).OrderBy(a => a.cqp_Topic).ToList();
        //        _otherRecords = _otherRecords.OrderByDescending(a => a.cqp_CreateTime.Year).OrderBy(a => a.cqp_Unit).OrderBy(a => a.cqp_Topic).ToList();
        //        if ((_records != null) && (_records.Count > 0))
        //        {
        //            List<assignTeamDTO> _teamList = null;
        //            #region MainData
        //            foreach (var _obj in _records)
        //            {
        //                #region  判斷權限
        //                _isPermited = false; _teamList = null;
        //                if (_obj.cqp_AcrossCourse) _isPermited = true;
        //                else
        //                {
        //                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)_obj.cqp_CourseId, searchFactor.UserId);
        //                    if (_coursePermissions.Quiz) _isPermited = true;
        //                    else
        //                    {
        //                        _rInfo.UnitId = (Guid)_obj.cqp_PoolId;
        //                        _rInfo.UserId = searchFactor.UserId;
        //                        _rInfo.KeyId = searchFactor.UserId;
        //                        _oResult = PermitGet(_rInfo);   // 個人權限
        //                        if (_oResult.Success == false)
        //                        {   // 小組權限
        //                            _teamList = CurrentState.AssignTeamInfo((Guid)_obj.cqp_CourseId);
        //                            _rInfo.KeyId = _teamList.First(t => t.AccountId == searchFactor.UserId).TeamId;
        //                            _oResult = PermitGet(_rInfo);
        //                        }

        //                        if (_oResult.Success) _isPermited = (bool)((crsQuizDTO)_oResult.DataCollection).View;
        //                    }
        //                }
        //                #endregion

        //                #region  取得有權限查閱的清單
        //                if (_isPermited)
        //                {
        //                    // 判斷資料鎖定是否已逾期(超過6小時)
        //                    crsQuizDTO _temp = new crsQuizDTO();
        //                    TimeSpan _gapLocked = (_obj.cqp_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqp_LockedTime) : _updateTime.Subtract(_updateTime); //鎖定日期相減
        //                    TimeSpan _gapUpdate = (_obj.cqp_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqp_UpdateTime) : _updateTime.Subtract(_updateTime); //更新日期相減
        //                    _temp.Locked = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? false : true;
        //                    _temp.LockedRemark = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqp_LockedRemark;
        //                    _temp.LockedUser = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqp_LockedUser;
        //                    _temp.TheTable = "Pool";
        //                    if (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) Lock(_temp);  // 將資料解鎖

        //                    _list.Add(new crsQuizDTO()
        //                    {
        //                        #region 屬性對應
        //                        PoolId = _obj.cqp_PoolId,
        //                        OriginalGroupId = _obj.cqp_OriginalGroupId,
        //                        CreaterId = _obj.cqp_CreaterId,
        //                        CreateTime = _obj.cqp_CreateTime,
        //                        EditorId = _obj.cqp_EditorId,
        //                        UpdateTime = _obj.cqp_UpdateTime,
        //                        Unit = _obj.cqp_Unit,
        //                        Topic = _obj.cqp_Topic,
        //                        AcrossCourse = _obj.cqp_AcrossCourse,
        //                        Category = _obj.cqp_Category,
        //                        Difficult = _obj.cqp_Difficult,
        //                        Grade = _obj.cqp_Grade,
        //                        Subject = _obj.cqp_Subject,
        //                        Comment = _obj.cqp_Comment,
        //                        Locked = _temp.Locked,
        //                        LockedUser = _temp.LockedUser,
        //                        LockedTime = _temp.LockedTime,
        //                        LockedRemark = _temp.LockedRemark,
        //                        Permited = (_isPermited == true && _temp.Locked != true) ? true : false
        //                        #endregion 屬性對應
        //                    });
        //                }
        //                #endregion
        //            }

        //            // 限制輸出資料範圍
        //            if (getAmount > 0 && _list.Count() > 0) _list = _list.Skip(skipAmount).Take(getAmount).ToList();
        //            _group.MainData = _list;
        //            #endregion


        //            _oResult = _msg.TransformResult(true, _group);
        //        }
        //        else
        //            _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx

        //    }
        //    catch (Exception ex)
        //    {
        //        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
        //    }

        //    #region  insert Log
        //    _rLog.IP = searchFactor.IP;
        //    _rLog.UserId = searchFactor.UserId;
        //    _rLog.TheTable = "Pool";         // 指定資料表
        //    _rLog.BeginDate = _updateTime;        // 開始時間
        //    _rLog.EndDate = DateTime.Now;         // 結束時間
        //    _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
        //    _rLog.Success = _oResult.Success;        // 執行成功
        //    _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

        //    _rLog.Comment = JsonConvert.SerializeObject(_list); // _list.ToString();     // 內容
        //    //_rLog.PoolId = ;        // 目的(新)題庫ID	
        //    //_rLog.Subject = ;        // 主題名稱	
        //    //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
        //    _log.ExamLog(_rLog);
        //    #endregion


        //    return _oResult;
        //}
        //#endregion 


        #region 搜尋試題
        public ObjResult PoolSearch(crsQuizDTO searchFactor, String Key, Int32 skipAmount, Int32 getAmount, Boolean onlyOwnData)
        {
            ObjResult _oResult = new ObjResult();
            ObjResult _chResult = new ObjResult();
            List<Guid> _CourseId = new List<Guid>();    // 課程
            List<Guid> _jointPoolId = new List<Guid>();  // 共同/分享的試題
            List<crsQuestionPool> _records = new List<crsQuestionPool>();       // 個人有權查閱的試題
            List<crsQuestionPool> _jointRecords = new List<crsQuestionPool>();  // 他人分享的試題
            List<crsQuestionPool> _otherRecords = new List<crsQuestionPool>();  // 其他相關試題
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            objectGroupDTO _group = new objectGroupDTO();
            try
            {
                #region 取出相關試題
                _CourseId = (from p in E35db.autRCrsTea
                             where p.TeacherId == searchFactor.UserId
                             select (p.CourseId)).ToList();

                #region 共同/分享的試題Id
                if (onlyOwnData == false)
                {
                    _jointPoolId = (from p in E4db.crsPublicUnitPermit
                                    join q in E4db.crsQuestionPool on p.cpup_UnitId equals q.cqp_PoolId
                                    where (p.cpup_View == true) && _CourseId.Contains((Guid)q.cqp_CourseId) && _CourseId.Contains((Guid)p.cpup_KeyId)
                                    select q.cqp_PoolId).ToList();

                    _records = crsQuestionPoolRepository.Get(a => _CourseId.Contains((Guid)a.cqp_CourseId)).ToList();
                    _jointRecords = crsQuestionPoolRepository.Get(a => _jointPoolId.Contains((Guid)a.cqp_PoolId)).ToList();
                    foreach (var _obj in _jointRecords)
                        if (_records.Contains(_obj) == true) _jointRecords.Remove(_obj);
                }
                #endregion

                #endregion

                #region 條件限制
                if (Key != null)        // 關鍵字
                {
                    _records = _records.FindAll(a => a.cqp_Subject.Contains(Key) || a.cqp_Topic.Contains(Key) ||
                                a.cqp_Unit.Contains(Key) || _CourseId.Contains((Guid)a.cqp_CourseId)).ToList();

                    #region 共同/分享的試題Id
                    if (onlyOwnData == false)
                    {
                        _jointRecords = _jointRecords.FindAll(a => a.cqp_Subject.Contains(Key) || a.cqp_Topic.Contains(Key) ||
                                    a.cqp_Unit.Contains(Key) || _CourseId.Contains((Guid)a.cqp_CourseId)).ToList();
                        // 其他課程試題
                        _CourseId = (from p in E35db.crsCourse
                                     where p.zhTWName.Contains(Key) || p.zhCNName.Contains(Key) || p.enUSName.Contains(Key)
                                     select (p.CourseId)).ToList();
                        if (_CourseId.Count() > 0)
                        {
                            _otherRecords = crsQuestionPoolRepository.Get(a => _CourseId.Contains((Guid)a.cqp_CourseId)).ToList();
                            foreach (var _obj in _otherRecords)
                                if (_records.Contains(_obj) == false) _otherRecords.Remove(_obj);
                        }
                    }
                    #endregion
                }

                if (searchFactor.Unit != null)      // 單元
                {
                    _records = _records.FindAll(a => a.cqp_Unit == searchFactor.Unit).ToList();
                    if (_jointRecords != null) _jointRecords = _records.FindAll(a => a.cqp_Unit == searchFactor.Unit).ToList();
                    if (_otherRecords != null) _otherRecords = _records.FindAll(a => a.cqp_Unit == searchFactor.Unit).ToList();
                }
                if (searchFactor.Topic != null)     // 主題
                {
                    _records = _records.FindAll(a => a.cqp_Topic == searchFactor.Topic).ToList();
                    if (_jointRecords != null) _jointRecords = _records.FindAll(a => a.cqp_Topic == searchFactor.Topic).ToList();
                    if (_otherRecords != null) _otherRecords = _records.FindAll(a => a.cqp_Topic == searchFactor.Topic).ToList();
                }
                if (searchFactor.Difficult > -1)    // 難度
                {
                    _records = _records.FindAll(a => a.cqp_Difficult == searchFactor.Difficult).ToList();
                    if (_jointRecords != null) _jointRecords = _records.FindAll(a => a.cqp_Difficult == searchFactor.Difficult).ToList();
                    if (_otherRecords != null) _otherRecords = _records.FindAll(a => a.cqp_Difficult == searchFactor.Difficult).ToList();
                }
                if (searchFactor.Category > -1)     // 題型
                {
                    _records = _records.FindAll(a => a.cqp_Category == searchFactor.Category).ToList();
                    if (_jointRecords != null) _jointRecords = _records.FindAll(a => a.cqp_Category == searchFactor.Category).ToList();
                    if (_otherRecords != null) _otherRecords = _records.FindAll(a => a.cqp_Category == searchFactor.Category).ToList();
                }
                #endregion

                // 排序
                _records = _records.OrderByDescending(a => a.cqp_CreateTime.Year).OrderBy(a => a.cqp_Unit).OrderBy(a => a.cqp_Topic).ToList();
                if (_jointRecords != null) _jointRecords = _jointRecords.OrderByDescending(a => a.cqp_CreateTime.Year).OrderBy(a => a.cqp_Unit).OrderBy(a => a.cqp_Topic).ToList();
                if (_otherRecords != null) _otherRecords = _otherRecords.OrderByDescending(a => a.cqp_CreateTime.Year).OrderBy(a => a.cqp_Unit).OrderBy(a => a.cqp_Topic).ToList();
                if (((_records != null) && (_records.Count > 0)) || ((_jointRecords != null) && (_jointRecords.Count > 0)) || ((_otherRecords != null) && (_otherRecords.Count > 0)))
                {
                    List<crsQuizDTO> _groupList = new List<crsQuizDTO>();

                    #region MainData
                    if (_records != null)
                    {
                        _chResult = PoolSearchDataFilter(_records, searchFactor.UserId);
                        if (_chResult.Success)
                        {
                            _list = (List<crsQuizDTO>)_chResult.DataCollection;
                            _groupList = _list;

                            // 限制輸出資料範圍
                            if (getAmount > 0 && _list.Count() > 0) _list = _list.Skip(skipAmount).Take(getAmount).ToList();
                            _group.MainData = _list;
                        }
                    }
                    #endregion

                    #region 共同/分享的試題
                    if (onlyOwnData == false)
                    {
                        #region ShareData
                        if (_jointRecords != null)
                        {
                            _chResult = PoolSearchDataFilter(_jointRecords, searchFactor.UserId);
                            if (_chResult.Success)
                            {
                                _list = (List<crsQuizDTO>)_chResult.DataCollection;
                                _groupList.AddRange(_list);

                                // 限制輸出資料範圍
                                if (getAmount > 0 && _list.Count() > 0) _list = _list.Skip(skipAmount).Take(getAmount).ToList();
                                _group.ShareData = _list;
                            }
                        }
                        #endregion

                        #region ExtraData
                        if (_otherRecords != null)
                        {
                            _chResult = PoolSearchDataFilter(_otherRecords, searchFactor.UserId);
                            if (_chResult.Success)
                            {
                                _list = (List<crsQuizDTO>)_chResult.DataCollection;
                                _groupList.AddRange(_list);

                                // 限制輸出資料範圍
                                if (getAmount > 0 && _list.Count() > 0) _list = _list.Skip(skipAmount).Take(getAmount).ToList();
                                _group.ExtraData = _list;
                            }
                        }
                        #endregion
                    }
                    #endregion

                    #region GroupData = MainData + ShareData + ExtraData
                    // 限制輸出資料範圍
                    if (getAmount > 0 && _list.Count() > 0) _groupList = _groupList.Skip(skipAmount).Take(getAmount).ToList();
                    _group.GroupData = _groupList;
                    #endregion

                    if (_groupList != null) _oResult = (onlyOwnData) ? _msg.TransformResult(true, _group.MainData) : _msg.TransformResult(true, _group);
                    else _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = searchFactor.IP;
            _rLog.UserId = searchFactor.UserId;
            _rLog.TheTable = "Pool";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;        // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            _rLog.Comment = JsonConvert.SerializeObject(_list); // _list.ToString();     // 內容
            //_rLog.PoolId = ;        // 目的(新)題庫ID	
            //_rLog.Subject = ;        // 主題名稱	
            //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
            _log.ExamLog(_rLog);
            #endregion


            return _oResult;
        }
        #endregion 


        #region 篩選已搜尋的試題
        public ObjResult PoolSearchDataFilter(List<crsQuestionPool> SearchData, Guid UserId)
        {
            ObjResult _oResult = new ObjResult();
            bool _isPermited = false;
            List<assignTeamDTO> _teamList = null;
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            try
            {
                foreach (var _obj in SearchData)
                {
                    #region  判斷權限
                    _isPermited = false; _teamList = null;
                    if (_obj.cqp_AcrossCourse) _isPermited = true;
                    else
                    {
                        CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)_obj.cqp_CourseId, UserId);
                        if (_coursePermissions != null)
                            _isPermited =_coursePermissions.Quiz;
                        else
                        {
                            _rInfo.UnitId = (Guid)_obj.cqp_PoolId;
                            _rInfo.UserId = UserId;
                            _rInfo.KeyId = UserId;
                            _oResult = PermitGet(_rInfo);   // 個人權限
                            if (_oResult.Success == false)
                            {   // 小組權限
                                _teamList = CurrentState.AssignTeamInfo((Guid)_obj.cqp_CourseId);
                                _rInfo.KeyId = _teamList.First(t => t.AccountId == UserId).TeamId;
                                _oResult = PermitGet(_rInfo);
                            }

                            if (_oResult.Success) _isPermited = (bool)((crsQuizDTO)_oResult.DataCollection).View;
                        }
                    }
                    #endregion

                    #region  取得有權限查閱的清單
                    if (_isPermited)
                    {
                        // 判斷資料鎖定是否已逾期(超過6小時)
                        crsQuizDTO _temp = new crsQuizDTO();
                        TimeSpan _gapLocked = (_obj.cqp_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqp_LockedTime) : _updateTime.Subtract(_updateTime); //鎖定日期相減
                        TimeSpan _gapUpdate = (_obj.cqp_Locked == true) ? _updateTime.Subtract((DateTime)_obj.cqp_UpdateTime) : _updateTime.Subtract(_updateTime); //更新日期相減
                        _temp.Locked = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? false : true;
                        _temp.LockedRemark = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqp_LockedRemark;
                        _temp.LockedUser = (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) ? null : _obj.cqp_LockedUser;
                        _temp.TheTable = "Pool";
                        if (_gapLocked.Hours > 6 && _gapUpdate.Hours > 6) Lock(_temp);  // 將資料解鎖

                        _list.Add(new crsQuizDTO()
                        {
                            #region 屬性對應
                            PoolId = _obj.cqp_PoolId,
                            OriginalGroupId = _obj.cqp_OriginalGroupId,
                            CreaterId = _obj.cqp_CreaterId,
                            CreateTime = _obj.cqp_CreateTime,
                            EditorId = _obj.cqp_EditorId,
                            UpdateTime = _obj.cqp_UpdateTime,
                            Unit = _obj.cqp_Unit,
                            Topic = _obj.cqp_Topic,
                            AcrossCourse = _obj.cqp_AcrossCourse,
                            Category = _obj.cqp_Category,
                            Difficult = _obj.cqp_Difficult,
                            Grade = _obj.cqp_Grade,
                            Subject = _obj.cqp_Subject,
                            Comment = _obj.cqp_Comment,
                            Locked = _temp.Locked,
                            LockedUser = _temp.LockedUser,
                            LockedTime = _temp.LockedTime,
                            LockedRemark = _temp.LockedRemark,
                            Permited = (_isPermited == true && _temp.Locked != true) ? true : false
                            #endregion 屬性對應
                        });
                    }
                    #endregion
                }

                if (_list.Count > 0) _oResult = _msg.TransformResult(true, _list);
                else _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), ""));
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return _oResult;
        }
        #endregion 


        #region 取得試題
        public ObjResult PoolAcquire(Guid UserId, String IP, Guid PoolId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // get record
                var _pool = crsQuestionPoolRepository.GetFirst(a => a.cqp_PoolId == PoolId);
                if (_pool != null)
                {
                    #region 屬性對應
                    _record.PoolId = PoolId;
                    _record.CreateTime = _pool.cqp_CreateTime;
                    _record.CreaterId = _pool.cqp_CreaterId;
                    _record.UpdateTime = _pool.cqp_UpdateTime;
                    _record.EditorId = _pool.cqp_EditorId;
                    _record.OriginalGroupId = _pool.cqp_OriginalGroupId; // 體組型子題目的上層題庫ID
                    _record.CourseId = (Guid)_pool.cqp_CourseId;    // 課程識別碼
                    _record.Unit = _pool.cqp_Unit;      // 單元
                    _record.Topic = _pool.cqp_Topic;   // 主題
                    _record.AcrossCourse = _pool.cqp_AcrossCourse; // 是否跨課程使用
                    _record.Category = _pool.cqp_Category;       // 題型
                    _record.Difficult = _pool.cqp_Difficult;    // 難易度
                    _record.Grade = _pool.cqp_Grade;       // 參考分數
                    _record.Subject = _pool.cqp_Subject;   // 題目
                    _record.Comment = _pool.cqp_Comment;   // 備註
                    _record.IsDeleted = _pool.cqp_IsDeleted;   // 紀錄刪除標記
                    #endregion 屬性對應

                    _oResult = _msg.TransformResult(true, _record);

                    // Log info
                    _rLog.PoolId = PoolId;        // 目的(新)題庫ID	
                    _rLog.Subject = _record.Topic;        // 主題名稱	
                    _rLog.Comment = JsonConvert.SerializeObject(_record); // _record.ToString();     // 內容
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "PoolId: " + PoolId.ToString())); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "Pool";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 1;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;        // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
            _log.ExamLog(_rLog);
            #endregion 


            return _oResult;
        }
        #endregion 取得試題


        #region 新增試題
        public ObjResult PoolPublish(Guid UserId, String IP, Guid PoolId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // 判斷權限
                var _temp = crsQuestionPoolDraftRepository.GetFirst(a => a.cqpd_PoolId == PoolId);
                CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)_temp.cqpd_CourseId, UserId);
                if (_coursePermissions.Quiz==false)
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actAdd"), _msg.Get("objQuestion")));
                else
                { 
                    // get record
                    var _poolDraft = crsQuestionPoolDraftRepository.GetFirst(a => a.cqpd_PoolId == PoolId && (a.cqpd_CreaterId == UserId || a.cqpd_EditorId == UserId));
                    if (_poolDraft==null)
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "PoolId: "+PoolId));
                    else
                    { 
                        #region 屬性對應
                        _rInfo.PoolId = _pool.cqp_PoolId = PoolId;
                        _rInfo.CreateTime = _pool.cqp_CreateTime = _poolDraft.cqpd_CreateTime;
                        _rInfo.CreaterId = _pool.cqp_CreaterId = _poolDraft.cqpd_CreaterId;
                        _rInfo.UpdateTime = _pool.cqp_UpdateTime = _poolDraft.cqpd_UpdateTime;
                        _rInfo.EditorId = _pool.cqp_EditorId = _poolDraft.cqpd_EditorId;
                        _rInfo.OriginalGroupId = _pool.cqp_OriginalGroupId = _poolDraft.cqpd_OriginalGroupId; // 體組型子題目的上層題庫ID
                        _pool.cqp_CourseId = _rInfo.CourseId = (Guid)_poolDraft.cqpd_CourseId;    // 課程識別碼
                        _rInfo.Unit = _pool.cqp_Unit = _poolDraft.cqpd_Unit;      // 單元
                        _rInfo.Topic = _pool.cqp_Topic = _poolDraft.cqpd_Topic;   // 主題
                        _rInfo.AcrossCourse = _pool.cqp_AcrossCourse = (bool)_poolDraft.cqpd_AcrossCourse; // 是否跨課程使用
                        _rInfo.Category = _pool.cqp_Category = (int)_poolDraft.cqpd_Category;       // 題型
                        _rInfo.Difficult = _pool.cqp_Difficult = (int)_poolDraft.cqpd_Difficult;    // 難易度
                        _rInfo.Grade = _pool.cqp_Grade = _poolDraft.cqpd_Grade;       // 參考分數
                        _rInfo.Subject = _pool.cqp_Subject = _poolDraft.cqpd_Subject;   // 題目
                        _rInfo.Comment = _pool.cqp_Comment = _poolDraft.cqpd_Comment;   // 備註
                        _rInfo.IsDeleted = _pool.cqp_IsDeleted = false;   // 紀錄刪除標記
                        #endregion 屬性對應

                        // insert data
                        crsQuestionPoolRepository.Create(_pool, true);

                        _oResult = _msg.TransformResult(true, _rInfo);


                        // Log info
                        _rLog.PoolId = PoolId;        // 目的(新)題庫ID	
                        _rLog.Subject = _pool.cqp_Topic;        // 主題名稱	
                        _rLog.Comment = JsonConvert.SerializeObject(_rInfo); // _pool.ToString();     // 內容
                    }
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "Pool";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 2;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;     // 錯誤訊息

            //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 新增試題


        #region 修改試題 
        public ObjResult PoolRevise(crsQuizDTO updateData)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // get record, 未判斷原建立者和修改者是否同人,建議由前端進行權限限制
                var _pool = crsQuestionPoolRepository.GetFirst(a => a.cqp_PoolId == updateData.PoolId && a.cqp_LockedUser == updateData.UserId && a.cqp_Locked == true);
                if (_pool != null)
                {

                    #region 屬性對應,僅提供部分欄位可修改
                    _rInfo.UpdateTime = _pool.cqp_UpdateTime = _updateTime;
                    _rInfo.EditorId = _pool.cqp_EditorId = updateData.UserId;
                    if (updateData.AcrossCourse != null) _rInfo.AcrossCourse = _pool.cqp_AcrossCourse = (bool)updateData.AcrossCourse; // 是否跨課程使用
                    if (updateData.Difficult != null) _rInfo.Difficult = _pool.cqp_Difficult = (int)updateData.Difficult;    // 難易度
                    if (updateData.Grade != null) _rInfo.Grade = _pool.cqp_Grade = (decimal)updateData.Grade;       // 參考分數
                    if (updateData.Comment != null) _rInfo.Comment = _pool.cqp_Comment = updateData.Comment.Trim();   // 備註
                    if (updateData.IsDeleted != null) _rInfo.IsDeleted = _pool.cqp_IsDeleted = updateData.IsDeleted;   // 紀錄刪除標記

                    // 以下欄位建議不開放給前端使用者修改
                    if (updateData.OriginalGroupId != null) _rInfo.OriginalGroupId = _pool.cqp_OriginalGroupId = updateData.OriginalGroupId; // 體組型子題目的上層題庫ID
                    if (updateData.CourseId != null) _pool.cqp_CourseId = _rInfo.CourseId = (Guid)updateData.CourseId;    // 課程識別碼
                    if (updateData.Unit != null) _rInfo.Unit = _pool.cqp_Unit = updateData.Unit.Trim();      // 單元
                    if (updateData.Topic != null) _rInfo.Topic = _pool.cqp_Topic = updateData.Topic.Trim();   // 主題
                    if (updateData.Category != null) _rInfo.Category = _pool.cqp_Category = (int)updateData.Category;       // 題型
                    if (updateData.Subject != null) _rInfo.Subject = _pool.cqp_Subject = updateData.Subject.Trim();   // 題目
                    #endregion 屬性對應

                    // Update data
                    crsQuestionPoolRepository.Update(_pool, true);

                    _oResult = _msg.TransformResult(true, _rInfo);


                    // Log info
                    _rLog.PoolId = updateData.PoolId;        // 目的(新)題庫ID	
                    _rLog.Subject = updateData.Topic;        // 主題名稱	
                    _rLog.Comment = JsonConvert.SerializeObject(_rInfo); // _pool.ToString();     // 內容
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), updateData.PoolId.ToString())); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = updateData.IP;
            _rLog.UserId = updateData.UserId;
            _rLog.TheTable = "Pool";         // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;      // 錯誤訊息

            //_rLog.OriginPoolId = ;        // 原始(來源)題庫ID	
            _log.ExamLog(_rLog);
            #endregion            

            return _oResult;
        }
        #endregion 修改試題


        #endregion 試題庫-正式試題

        #region 試題庫-答案項
// ==== 試題庫-答案項 =========================================================================================================================

        #region 答案項清單
        public ObjResult OptionList(Guid UserId, String IP, Guid PoolId, Boolean isRandom, Int32 skipAmount, Int32 getAmount)
        {
            ObjResult _oResult = new ObjResult();
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            try
            {
                // get record
                var _records = crsQuestionPoolOptionRepository.Get(a => a.cqpo_PoolId == PoolId).ToList();
                if (isRandom) _records = _records.OrderBy(a => Guid.NewGuid()).ToList();  // 隨機排序
                else _records = _records.OrderBy(a => a.cqpo_Serial).OrderBy(a => a.cqpo_CreateTime).ToList();
                // 限制輸出資料範圍
                if (getAmount > 0) _records = _records.Skip(skipAmount).Take(getAmount).ToList();

                if ((_records != null) && (_records.Count > 0))
                {
                    foreach (var _obj in _records)
                    {
                        _list.Add(new crsQuizDTO()
                        {
                            #region 屬性對應
                            OptionId = _obj.cqpo_OptionId,
                            PoolId = _obj.cqpo_PoolId,
                            CreateTime = _obj.cqpo_CreateTime,
                            EditorId = (Guid)_obj.cqpo_EditorId,
                            UpdateTime = _obj.cqpo_UpdateTime,
                            Content = _obj.cqpo_Content,
                            IsAnswer = _obj.cqpo_IsAnswer,
                            Feedback = _obj.cqpo_Feedback
                            #endregion 屬性對應
                        }
                        );
                    }

                    _oResult = _msg.TransformResult(true, _list);
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "")); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "Option";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;        // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            _rLog.Content = JsonConvert.SerializeObject(_list);         // 選項內容敘述	
            //_rLog.OptionId = ;        // 答案選項ID	
            //_rLog.PoolId = ;          // 題庫ID	
            //_rLog.IsAnswer = ;        // 0:非答案, 1:正確答案	
            //_rLog.Feedback = ;        // 答案回饋	
            _log.ExamLog(_rLog);
            #endregion 


            return _oResult;
        }
        #endregion 答案項清單


        #region 新增答案項
        public ObjResult OptionAdd(crsQuizDTO newData)
        {
            ObjResult _oResult = new ObjResult();
            System.Guid _optionId = Guid.NewGuid();

            // 序號
            //var _records = crsQuestionPoolOptionRepository.Get(a => a.cqpo_PoolId == newData.PoolId).OrderByDescending(a => a.cqpo_Serial).ToList().Skip(0).Take(1).ToList();
            //if ((_records != null) && (_records.Count > 0))
            //    foreach (var _obj in _records)
            //        newData.Serial = _obj.cqpo_Serial + 1;
            var _lastSerial = (from p in E4db.crsQuestionPoolOption
                            where p.cqpo_PoolId == newData.PoolId
                            orderby p.cqpo_Serial descending
                            select p.cqpo_Serial ).FirstOrDefault();
            newData.Serial = (_lastSerial != null) ? _lastSerial + 1 : 1;


            #region 屬性對應
            _option.cqpo_CreateTime = _updateTime;
            _option.cqpo_EditorId = newData.UserId;
            _option.cqpo_UpdateTime = _updateTime;

            _rInfo.OptionId = _option.cqpo_OptionId = _optionId;
            _rInfo.PoolId = _option.cqpo_PoolId = newData.PoolId;
            _rInfo.Serial = _option.cqpo_Serial = (newData.Serial != null) ? newData.Serial : 1;
            if (newData.Content != null) _rInfo.Content = _option.cqpo_Content = newData.Content.Trim();
            _rInfo.IsAnswer = _option.cqpo_IsAnswer = (newData.IsAnswer != null) ? (bool)newData.IsAnswer : false;
            if (newData.Feedback != null) _rInfo.Feedback = _option.cqpo_Feedback = newData.Feedback.Trim();
            #endregion 屬性對應

            try
            {
                // insert data
                crsQuestionPoolOptionRepository.Create(_option, true);


                _oResult = _msg.TransformResult(true, _rInfo);


                // Log info
                _rLog.OptionId = _optionId;        // 答案選項ID	
                _rLog.PoolId = newData.PoolId;          // 題庫ID	
                _rLog.Content = newData.Content;         // 選項內容敘述	
                _rLog.IsAnswer = _option.cqpo_IsAnswer;        // 0:非答案, 1:正確答案	
                _rLog.Feedback = newData.Feedback;        // 答案回饋	
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = newData.IP;
            _rLog.UserId = newData.UserId;
            _rLog.TheTable = "Option";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 2;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 新增答案項


        #region 引用答案項
        public ObjResult OptionRecreate(Guid UserId, String IP, Guid PoolId, Guid newPoolId)
        {
            ObjResult _oResult = new ObjResult();
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            try
            {
                // get record
                var _records = crsQuestionPoolOptionRepository.Get(a => a.cqpo_PoolId == PoolId).ToList();
                if ((_records != null) && (_records.Count > 0))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "PoolId:" + PoolId.ToString()));
                else
                {
                    foreach (var _pool in _records)
                    { 
                        System.Guid _newId = Guid.NewGuid();

                        _rInfo = new crsQuizDTO();
                        #region 屬性對應
                        _rInfo.OptionId = _option.cqpo_OptionId = _newId;
                        _rInfo.PoolId = _option.cqpo_PoolId = newPoolId;
                        _rInfo.CreateTime = _option.cqpo_CreateTime = _updateTime;
                        _option.cqpo_EditorId = _rInfo.EditorId = UserId;
                        _rInfo.UpdateTime = _option.cqpo_UpdateTime = _updateTime;
                        _rInfo.Serial = _option.cqpo_Serial = _pool.cqpo_Serial;
                        _rInfo.Content = _option.cqpo_Content = _pool.cqpo_Content;
                        _rInfo.IsAnswer = _option.cqpo_IsAnswer = _pool.cqpo_IsAnswer;
                        _rInfo.Feedback = _option.cqpo_Feedback = _pool.cqpo_Feedback;
                        #endregion 屬性對應

                        // insert data
                        crsQuestionPoolOptionRepository.Create(_option, false);

                        _list.Add(_rInfo);
                    }
                    crsQuestionPoolOptionRepository.SaveChanges();

                    #region  insert Log
                    foreach (var _rInfo in _list)
                    {
                        _rLog.IP = IP;
                        _rLog.UserId = UserId;
                        _rLog.TheTable = "Option";         	  // 指定資料表
                        _rLog.BeginDate = _updateTime;        // 開始時間
                        _rLog.EndDate = DateTime.Now;         // 結束時間
                        _rLog.Behavior = 6;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                        _rLog.Success = true;      // 執行成功

                        _rLog.OptionId = _rInfo.OptionId;        // 答案選項ID	
                        _rLog.PoolId = _rInfo.PoolId;          // 題庫ID	
                        _rLog.Content = _rInfo.Content;         // 選項內容敘述	
                        _rLog.IsAnswer = _rInfo.IsAnswer;        // 0:非答案, 1:正確答案	
                        _rLog.Feedback = _rInfo.Feedback;        // 答案回饋	
                        _log.ExamLog(_rLog);
                    }
                    #endregion

                    _oResult = _msg.TransformResult(true, _list);
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            if (_oResult.Success==false)
            #region  insert Log
            {
                _rLog.IP = IP;
                _rLog.UserId = UserId;
                _rLog.TheTable = "Option";         	  // 指定資料表
                _rLog.BeginDate = _updateTime;        // 開始時間
                _rLog.EndDate = DateTime.Now;         // 結束時間
                _rLog.Behavior = 6;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                _rLog.Success = _oResult.Success;      // 執行成功
                _rLog.ErrorMessage = _oResult.ErrorMessage;    // 錯誤訊息
                _rLog.PoolId = newPoolId;          // 題庫ID	

                _log.ExamLog(_rLog);
            }
            #endregion

            return _oResult;
        }
        #endregion


        #region 修改答案項
        public ObjResult OptionUpdate(crsQuizDTO updateData)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // get record, 未判斷原建立者和修改者是否同人,建議由前端進行權限限制
                var _record = crsQuestionPoolOptionRepository.GetFirst(a => a.cqpo_OptionId == updateData.OptionId);
                if (_record != null)
                {

                    #region 屬性對應
                    _record.cqpo_EditorId = updateData.UserId;
                    _record.cqpo_UpdateTime = _updateTime;
                    if (updateData.Serial != null) _rInfo.Serial = _record.cqpo_Serial = updateData.Serial;
                    if (updateData.Content != null) _rInfo.Content = _record.cqpo_Content = updateData.Content.Trim();
                    if (updateData.IsAnswer != null) _rInfo.IsAnswer = _record.cqpo_IsAnswer = (bool)updateData.IsAnswer;
                    if (updateData.Feedback != null) _rInfo.Feedback = _record.cqpo_Feedback = updateData.Feedback.Trim();
                    #endregion 屬性對應

                    // Update data
                    crsQuestionPoolOptionRepository.Update(_record, true);

                   
                    _oResult = _msg.TransformResult(true, _rInfo);

                    // Log info
                    _rLog.OptionId = updateData.OptionId;        // 答案選項ID	
                    _rLog.PoolId = _record.cqpo_PoolId;          // 題庫ID	
                    _rLog.Content = updateData.Content;         // 選項內容敘述	
                    _rLog.IsAnswer = (bool)updateData.IsAnswer;        // 0:非答案, 1:正確答案	
                    _rLog.Feedback = updateData.Feedback;        // 答案回饋	
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "OptionId: "+updateData.OptionId.ToString())); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = updateData.IP;
            _rLog.UserId = updateData.UserId;
            _rLog.TheTable = "Option";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 4;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 更新答案項


        #region 刪除答案項
        public ObjResult OptionDel(crsQuizDTO delInfo)
        {
            ObjResult _oResult = new ObjResult();
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            try
            {   // 不判斷只有建立/修改者可刪除, 在呼叫前就要判斷是否有權限異動
                var _record = crsQuestionPoolOptionRepository.Get(a => a.cqpo_OptionId == delInfo.OptionId);

                // 撈出該題所有選項
                if (_record.Count() == 0 && delInfo.PoolId!=null) 
                    _record = crsQuestionPoolOptionRepository.Get(a => a.cqpo_PoolId == delInfo.PoolId);

                if (_record.Count() > 0)
                {
                    foreach (crsQuestionPoolOption _option in _record)
                    {
                        _rInfo = new crsQuizDTO();
                        #region 屬性對應
                        _rInfo.OptionId = _option.cqpo_OptionId;
                        _rInfo.PoolId = _option.cqpo_PoolId;
                        _rInfo.Content = _option.cqpo_Content;
                        _rInfo.IsAnswer = _option.cqpo_IsAnswer;
                        _rInfo.Feedback = _option.cqpo_Feedback;
                        #endregion 屬性對應

                        crsQuestionPoolOptionRepository.Delete(_option, false);

                        _list.Add(_rInfo);
                    }
                    crsQuestionPoolOptionRepository.SaveChanges();

                    #region  insert Log
                    foreach (var _rInfo in _list)
                    { 
                        _rLog.IP = delInfo.IP;
                        _rLog.UserId = delInfo.UserId;
                        _rLog.TheTable = "Option";         	  // 指定資料表
                        _rLog.BeginDate = _updateTime;        // 開始時間
                        _rLog.EndDate = DateTime.Now;         // 結束時間
                        _rLog.Behavior = 4;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                        _rLog.Success = true;      // 執行成功

                        _rLog.OptionId = _rInfo.OptionId;        // 答案選項ID	
                        _rLog.PoolId = _rInfo.PoolId;          // 題庫ID	
                        _rLog.Content = _rInfo.Content;         // 選項內容敘述	
                        _rLog.IsAnswer = _rInfo.IsAnswer;        // 0:非答案, 1:正確答案	
                        _rLog.Feedback = _rInfo.Feedback;        // 答案回饋	
                        _log.ExamLog(_rLog);
                    }
                    #endregion
                        
                    _oResult = _msg.TransformResult(true, _list);
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "OptionId: " + delInfo.OptionId + " PoolId: " + delInfo.PoolId)); // Can not found the record !\r\n xxxxx

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            if (_oResult.Success == false)
            #region  insert Log
            {
                _rLog.IP = delInfo.IP;
                _rLog.UserId = delInfo.UserId;
                _rLog.TheTable = "Option";         	  // 指定資料表
                _rLog.BeginDate = _updateTime;        // 開始時間
                _rLog.EndDate = DateTime.Now;         // 結束時間
                _rLog.Behavior = 4;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                _rLog.Success = _oResult.Success;      // 執行成功
                _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

                _rLog.PoolId = delInfo.PoolId;
                _rLog.OptionId = delInfo.OptionId;
                _log.ExamLog(_rLog);
            }
            #endregion


            return _oResult;
        }
        #endregion 刪除答案項

        #endregion 試題庫-答案項

        #region 共同編輯-權限
        // ==== 共同編輯-權限 =========================================================================================================================

        #region 取得授權項目的被授權者清單
        public ObjResult PermitList(Guid UserId, String IP, Guid UnitId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                var _info = (from p in E4db.crsPublicUnitPermit
                             join c in E35db.crsCourse on p.cpup_KeyId equals c.CourseId
                             join s in E35db.autAccountInfo on p.cpup_KeyId equals s.AccountId
                             join t in E35db.crsTeam on p.cpup_KeyId equals t.TeamId
                             where p.cpup_UnitId == UnitId
                             select new crsQuizDTO
                             {
                                 KeyId = p.cpup_KeyId,  // 獲權者ID(個人/課程 Id)
                                 KeyType = p.cpup_KeyType,  // KyeId 類型(0:個人, 1:課程, 2:小組)
                                 Name = (p.cpup_KeyType == 0) ? s.Name : ((p.cpup_KeyType == 1) ? c.zhTWName + "(" + c.enUSName + ")" : t.TeamName),
                                 Account = (p.cpup_KeyType == 0) ? s.Account : ((p.cpup_KeyType == 1) ? c.CourseNo : ""),
                                 UpdateTime = p.cpup_UpdateTime,  // 建立時間
                                 View = p.cpup_View,  // 顯示
                                 Add = p.cpup_Add,  // 新增
                                 Delete = p.cpup_Delete,  // 刪除
                                 Edit = p.cpup_Edit  // 修改
                             }).ToList();

                if (_info != null)
                    _oResult = _msg.TransformResult(true, _info);
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), UnitId));
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }


            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "Permit";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;         // 錯誤訊息

            _rLog.UnitId = UnitId;    //	活動ID(題庫ID/試卷ID)	
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion

        #region 取得被授權者的授權項目清單
        public ObjResult UserPermitList(Guid UserId, String IP, Guid KeyId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                var _info = (from p in E4db.crsPublicUnitPermit
                             join c in E35db.crsCourse on p.cpup_KeyId equals c.CourseId
                             join s in E35db.autAccountInfo on p.cpup_KeyId equals s.AccountId
                             join t in E35db.crsTeam on p.cpup_KeyId equals t.TeamId
                             where p.cpup_KeyId == KeyId
                             select new crsQuizDTO
                             {
                                 UnitId = p.cpup_UnitId,  // 授權項目ID(試卷/試題 Id)
                                 KeyType = p.cpup_KeyType,  // KyeId 類型(0:個人, 1:課程, 2:小組)
                                 Name = (p.cpup_KeyType == 0) ? s.Name : ((p.cpup_KeyType == 1) ? c.zhTWName + "(" + c.enUSName + ")" : t.TeamName),
                                 Account = (p.cpup_KeyType == 0) ? s.Account : ((p.cpup_KeyType == 1) ? c.CourseNo : ""),
                                 UpdateTime = p.cpup_UpdateTime,  // 建立時間
                                 View = p.cpup_View,  // 顯示
                                 Add = p.cpup_Add,  // 新增
                                 Delete = p.cpup_Delete,  // 刪除
                                 Edit = p.cpup_Edit  // 修改
                             }).ToList();

                if (_info != null)
                    _oResult = _msg.TransformResult(true, _info);
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), KeyId));
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }


            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "Permit";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;         // 錯誤訊息

            _rLog.KeyId = KeyId;    //	活動ID(題庫ID/試卷ID)	
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion


        #region 權限設定,自動判斷新增/修改
        public ObjResult PermitSet(crsQuizDTO setInfo)
        {
            ObjResult _oResult = new ObjResult();
            _rLog.Behavior = 1; // 預設假定為"檢視",判斷帳號存在才改其他動作
            try
            {
                if (setInfo.KeyType == null)
                {
                    autAccountInfoDTO _checkUser = new autAccountInfoDTO();
                    teamInfoDTO _checkTeam = new teamInfoDTO();
                    courseInfoDTO _checkCourse = new courseInfoDTO();

                    // 判斷是否存在於課程資訊內
                    _checkCourse = CurrentState.CourseInfo(setInfo.KeyId).FirstOrDefault();   
                    if (_checkCourse != null)    setInfo.KeyType = 1;
                    else
                    {   // 判斷是否存在於使用者帳號內
                        _checkUser = CurrentState.UserInfo(setInfo.KeyId).FirstOrDefault();
                        if (_checkUser != null)     setInfo.KeyType = 0;
                        else
                        {    // 判斷是否存在於群組帳號內
                            _checkTeam = CurrentState.TeamInfo(setInfo.KeyId).FirstOrDefault();
                            if (_checkTeam != null) setInfo.KeyType = 2;
                        }
                    }
                }

                if (setInfo.KeyType == null)
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), setInfo.KeyId));
                else
                { 
                    // 不判斷只有建立/修改者可刪除, 在呼叫前就要判斷是否有權限異動
                    var _record = crsPublicUnitPermitRepository.GetFirst(a => a.cpup_UnitId == setInfo.UnitId && a.cpup_KeyId == setInfo.KeyId);
                    if (_record != null) // Update data
                    #region  Update data
                    {
                        #region 屬性對應
                        _rInfo.KeyId = setInfo.KeyId;
                        _record.cpup_EditorId = setInfo.UserId;
                        _record.cpup_UpdateTime = _updateTime;
                        if (setInfo.View != null) _rInfo.View = _record.cpup_View = setInfo.View;
                        if (setInfo.Add != null) _rInfo.Add = _record.cpup_Add = setInfo.Add;
                        if (setInfo.Delete != null) _rInfo.Delete = _record.cpup_Delete = setInfo.Delete;
                        if (setInfo.Edit != null) _rInfo.Edit = _record.cpup_Edit = setInfo.Edit;
                        #endregion 屬性對應

                        // Update data
                        crsPublicUnitPermitRepository.Update(_record, true);

                        _oResult = _msg.TransformResult(true, _rInfo);

                        // Log info
                        _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                        _rLog.UnitId = _record.cpup_UnitId;    //	活動ID(題庫ID/試卷ID)	
                        _rLog.KeyId = _record.cpup_KeyId;    //	獲權者ID(個人/課程 Id/小組Id)	
                        _rLog.KeyType = _record.cpup_KeyType;    //	KyeId 類型(0:個人, 1:課程, 2:小組)	
                        //	檢示|新增|刪除|修改 ; 0:無權, 1:有權	((((1)|(0))|(0))|(0))
                        _rLog.Permit = (_record.cpup_View == true) ? "1|" : "0|";
                        _rLog.Permit += (_record.cpup_Add == true) ? "1|" : "0|";
                        _rLog.Permit += (_record.cpup_Delete == true) ? "1|" : "0|";
                        _rLog.Permit += (_record.cpup_Edit == true) ? "1" : "0";
                    }
                    #endregion 

                    else
                    #region Insert data
                    {
                        #region 屬性對應
                        _publicPermit.cpup_UnitId = setInfo.UnitId;
                        _publicPermit.cpup_EditorId = setInfo.UserId;
                        _publicPermit.cpup_UpdateTime = _updateTime;
                        _rInfo.KeyId = _publicPermit.cpup_KeyId = setInfo.KeyId;
                        _rInfo.KeyType = _publicPermit.cpup_KeyType = setInfo.KeyType;
                        _rInfo.View = _publicPermit.cpup_View = (setInfo.View == null) ? true : setInfo.View;
                        _rInfo.Add = _publicPermit.cpup_Add = (setInfo.Add == null) ? false : setInfo.Add;
                        _rInfo.Delete = _publicPermit.cpup_Delete = (setInfo.Delete == null) ? false : setInfo.Delete;
                        _rInfo.Edit = _publicPermit.cpup_Edit = (setInfo.Edit == null) ? false : setInfo.Edit;
                        #endregion 屬性對應

                        // insert data
                        crsPublicUnitPermitRepository.Create(_publicPermit, true);

                        _oResult = _msg.TransformResult(true, _rInfo);

                        // Log info
                        _rLog.Behavior = 2;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                        _rLog.UnitId = setInfo.UnitId;    //	活動ID(題庫ID/試卷ID)	
                        _rLog.KeyId	= setInfo.KeyId;    //	獲權者ID(個人/課程 Id/小組Id)	
                        _rLog.KeyType	= setInfo.KeyType;    //	KyeId 類型(0:個人, 1:課程, 2:小組)	
                        //	檢示|新增|刪除|修改 ; 0:無權, 1:有權 (預設:1|0|0|0)
                        _rLog.Permit = (_publicPermit.cpup_View == true) ? "1|" : "0|";
                        _rLog.Permit += (_publicPermit.cpup_Add == true) ? "1|" : "0|";
                        _rLog.Permit += (_publicPermit.cpup_Delete == true) ? "1|" : "0|";
                        _rLog.Permit += (_publicPermit.cpup_Edit == true) ? "1" : "0";
                    }
                    #endregion

                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }


            #region  insert Log
            _rLog.IP = setInfo.IP;
            _rLog.UserId = setInfo.UserId;
            _rLog.TheTable = "Permit";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;        // 錯誤訊息

            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion


        #region 取得權限資訊
        public ObjResult PermitGet(crsQuizDTO permitInfo)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                crsQuizDTO _info = (from p in E4db.crsPublicUnitPermit
                             where p.cpup_UnitId == permitInfo.UnitId && p.cpup_KeyId == permitInfo.KeyId
                             select new crsQuizDTO
                             {
                                 UnitId = p.cpup_UnitId,  // ex. 題庫ID/試卷ID
                                 KeyId = p.cpup_KeyId,  // 獲權者ID(個人/課程 Id)
                                 KeyType = p.cpup_KeyType,  // KyeId 類型(0:個人, 1:課程)
                                 EditorId = (Guid)p.cpup_EditorId,  // 建立者ID
                                 UpdateTime = p.cpup_UpdateTime,  // 建立時間
                                 View = p.cpup_View,  // 顯示
                                 Add = p.cpup_Add,  // 新增
                                 Delete = p.cpup_Delete,  // 刪除
                                 Edit = p.cpup_Edit  // 修改
                             }).FirstOrDefault();

                if (_info != null)
                #region 獲權者資訊
                {   
                    if (_info.KeyType == 0)
                        _info.ExtraData = CurrentState.UserInfo(_info.KeyId);
                    else if (_info.KeyType == 1)
                        _info.ExtraData = CurrentState.CourseInfo(_info.KeyId);
                    else
                        _info.ExtraData = CurrentState.TeamInfo(_info.KeyId);

                    _rLog.IP = permitInfo.IP;
                    _rLog.UserId = permitInfo.UserId;
                    _rLog.UnitId = _info.UnitId;    //	活動ID(題庫ID/試卷ID)	
                    _rLog.KeyId = _info.KeyId;    //	獲權者ID(個人/課程 Id/小組Id)	
                    _rLog.KeyType = _info.KeyType;    //	KyeId 類型(0:個人, 1:課程, 2:小組)	
                    //	檢示|新增|刪除|修改 ; 0:無權, 1:有權 (預設:1|0|0|0)
                    _rLog.Permit = (_info.View == true) ? "1|" : "0|";
                    _rLog.Permit += (_info.Add == true) ? "1|" : "0|";
                    _rLog.Permit += (_info.Delete == true) ? "1|" : "0|";
                    _rLog.Permit += (_info.Edit == true) ? "1" : "0";

                }
                #endregion
                else
                #region 查不到獲權者=無權限
                {
                    _info.UnitId = permitInfo.UnitId;  // ex. 題庫ID/試卷ID
                    _info.KeyId = permitInfo.KeyId;  // 獲權者ID(個人/課程 Id)
                    _info.KeyType = permitInfo.KeyType;  // KyeId 類型(0:個人; 1:課程)
                    _info.EditorId = null;  // 建立者ID
                    _info.UpdateTime = null;  // 建立時間
                    _info.View = false;    // 顯示
                    _info.Add = false;     // 新增
                    _info.Delete = false;  // 刪除
                    _info.Edit = false;    // 修改

                }
                #endregion
                
                _oResult = _msg.TransformResult(true, _info);

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }


            #region  insert Log
            _rLog.IP = permitInfo.IP;
            _rLog.UserId = permitInfo.UserId;
            _rLog.TheTable = "Permit";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 1;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;         // 錯誤訊息

            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 取得試卷草稿


        #region 刪除權限
        public ObjResult PermitDel(crsQuizDTO delInfo)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                var _record = crsPublicUnitPermitRepository.GetFirst(a => a.cpup_UnitId == delInfo.UnitId && a.cpup_KeyId == delInfo.KeyId);

                if (_record!=null)
                {
                    _rInfo = new crsQuizDTO();
                    // Log info
                    _rInfo.UnitId = _rLog.UnitId = _record.cpup_UnitId;    //	活動ID(題庫ID/試卷ID)	
                    _rInfo.KeyId = _rLog.KeyId = _record.cpup_KeyId;    //	獲權者ID(個人/課程 Id/小組Id)	
                    _rInfo.KeyType = _rLog.KeyType = _record.cpup_KeyType;    //	KyeId 類型(0:個人, 1:課程, 2:小組)	
                    //	檢示|新增|刪除|修改 ; 0:無權, 1:有權 (預設:1|0|0|0)
                    _rLog.Permit = (_record.cpup_View == true) ? "1|" : "0|";
                    _rLog.Permit += (_record.cpup_Add == true) ? "1|" : "0|";
                    _rLog.Permit += (_record.cpup_Delete == true) ? "1|" : "0|";
                    _rLog.Permit += (_record.cpup_Edit == true) ? "1" : "0";

                    crsPublicUnitPermitRepository.Delete(_record, true);

                    _oResult = _msg.TransformResult(true, _rInfo);
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), delInfo.KeyId));

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = delInfo.IP;
            _rLog.UserId = delInfo.UserId;
            _rLog.TheTable = "Permit";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 4;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;         // 錯誤訊息

            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion

        #endregion


        #region 答案卷

        #region 答卷清單
        public ObjResult SheetList(Guid UserId, String IP, Guid QuizId, Guid? StudentId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                List<Guid> _students = new List<Guid>();
                crsQuizDTO _info = new crsQuizDTO();
                List<crsQuizDTO> _list = new List<crsQuizDTO>();
                List<crsQuizDTO> _detail = new List<crsQuizDTO>();
                var _sheets = crsQuizSubmitRepository.Get(a => a.cqs_QuizId == QuizId).OrderBy(a => a.cqs_AccountId).OrderByDescending(a => a.cqs_BeginDate).ToList();
                if ((StudentId != null) && (StudentId.ToString().Substring(0, 8) != "00000000"))
                    _sheets = _sheets.FindAll(a => a.cqs_AccountId == StudentId).ToList();
                if (_sheets.Count() == 0) _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), ""));
                else
                {
                    int _count = 0;
                    foreach (var _tmp in _sheets)
                    {
                        _info.StudentId = _tmp.cqs_AccountId;
                        _detail.Add(new crsQuizDTO()
                        {
                            #region 屬性對應
                            SubmitId = _tmp.cqs_SubmitId,
                            QuizId = _tmp.cqs_QuizId,
                            AccountId = _tmp.cqs_AccountId,
                            BeginDate = _tmp.cqs_BeginDate,
                            EndDate = _tmp.cqs_EndDate,
                            MatchRate = _tmp.cqs_MatchRate,
                            ExtraScore = _tmp.cqs_ExtraScore,
                            Criticism = _tmp.cqs_Criticism,
                            ScoreDate = _tmp.cqs_ScoreDate,
                            IsMainSheet = _tmp.cqs_IsMainSheet,
                            CompleteScored = _tmp.cqs_CompleteScored
                            #endregion 屬性對應
                        });
                        if ((_students.Contains(_tmp.cqs_AccountId) == false || _count == _sheets.Count()) && (_students.Count() > 0))
                        {
                            _list.Add(new crsQuizDTO()
                            {
                                StudentId = _tmp.cqs_AccountId,
                                ExtraData = _detail,
                            });
                            _detail = new List<crsQuizDTO>();
                        }

                        if (_students.Contains(_tmp.cqs_AccountId) == false) _students.Add(_tmp.cqs_AccountId);
                        _count++;
                    }
                    if (_detail.Count() > 0)
                        _list.Add(new crsQuizDTO()
                        {
                            StudentId = (Guid)_detail.First().AccountId,
                            ExtraData = _detail,
                        });

                    _oResult = _msg.TransformResult(true, _list);
                }

                #region  insert Log
                _rLog.IP = IP;
                _rLog.UserId = UserId;
                _rLog.TheTable = "Submit";         	  // 指定資料表
                _rLog.BeginDate = _updateTime;        // 開始時間
                _rLog.EndDate = DateTime.Now;         // 結束時間
                _rLog.Behavior = 0;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                _rLog.Success = _oResult.Success;      // 執行成功
                _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

                _rLog.QuizId = QuizId;    //	測驗ID
                _log.ExamLog(_rLog);
                #endregion


            }
            catch (Exception ex)
            {
                if ((QuizId == null) || (QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId"));
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return _oResult;
        }
        #endregion


        #region 答卷內容
        public ObjResult SheetContentsGet(Guid UserId, String IP, Guid SubmitId, Guid? PoolId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                List<crsQuizDTO> _list = new List<crsQuizDTO>();
                var _answers = crsQuizSubmitAnswerRepository.Get(a => a.cqsa_SubmitId == SubmitId).OrderBy(a => a.cqsa_Serial).ToList();
                if ((PoolId != null) && (PoolId.ToString().Substring(0, 8) != "00000000"))
                    _answers = _answers.FindAll(a => a.cqsa_PoolId == PoolId).ToList();
                if (_answers.Count() == 0) _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), ""));
                else
                {
                    foreach (var _tmp in _answers)
                    {
                        _list.Add(new crsQuizDTO()
                        {
                            #region 屬性對應
                            SubmitId = _tmp.cqsa_SubmitId,
                            PoolId = _tmp.cqsa_PoolId,
                            Serial = _tmp.cqsa_Serial,
                            BeginDate = _tmp.cqsa_BeginDate,
                            EndDate = _tmp.cqsa_EndDate,
                            Answer = _tmp.cqsa_Answer,
                            IsCorrect = _tmp.cqsa_IsCorrect,
                            MatchRate = _tmp.cqsa_MatchRate,
                            AutoToScoreDate = _tmp.cqsa_AutoToScoreDate,
                            ReadToScoreDate = _tmp.cqsa_ReadToScoreDate,
                            Criticism = _tmp.cqsa_Criticism,
                            PublishDate = _tmp.cqsa_PublishDate,
                            #endregion 屬性對應
                        });
                    }

                    _oResult = _msg.TransformResult(true, _list);
                }

                #region  insert Log
                _rLog.IP = IP;
                _rLog.UserId = UserId;
                _rLog.TheTable = "Submit";         	  // 指定資料表
                _rLog.BeginDate = _updateTime;        // 開始時間
                _rLog.EndDate = DateTime.Now;         // 結束時間
                _rLog.Behavior = 1;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                _rLog.Success = _oResult.Success;      // 執行成功
                _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

                _rLog.SubmitId = SubmitId;    //	得分ID
                _log.ExamLog(_rLog);
                #endregion

            }
            catch (Exception ex)
            {
                if ((SubmitId == null) || (SubmitId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "SubmitId"));
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return _oResult;
        }
        #endregion 



        #region 答卷
        public ObjResult SheetSubmit(crsQuizDTO newInfo, Boolean isDone = false)
        {
            ObjResult _oResult = new ObjResult();
            try
            {   // 缺試題Id
                if ((newInfo.PoolId == null) || (newInfo.PoolId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId") + JsonConvert.SerializeObject(newInfo));
                { 
                    if (isDone == true && newInfo.SubmitId != null)
                    #region 完成答案卷
                    {
                        // 寫入最後一題答案
                        _oResult = AnswerSubmit(newInfo, isDone);
                        if (_oResult.Success)
                        {
                            // 更新答案卷-完成時間
                            var _record = crsQuizSubmitRepository.GetFirst(a => a.cqs_SubmitId == newInfo.SubmitId);
                            _sheet.cqs_EndDate = (newInfo.EndDate != null) ? newInfo.EndDate : DateTime.Now;

                            // Update data
                            crsQuizSubmitRepository.Update(_sheet, true);
                            // 自動批閱成績
                            SheetAutoToScore(newInfo.UserId, newInfo.IP, newInfo.QuizId, newInfo.UserId, newInfo.SubmitId);
                        }
                    }
                    #endregion 完成答案卷

                    else if (newInfo.SubmitId != null)
                        _oResult = AnswerSubmit(newInfo);

                    else
                    #region 新的答案卷
                    {
                        System.Guid _submitId = Guid.NewGuid();

                        #region 屬性對應
                        newInfo.SubmitId = _sheet.cqs_SubmitId = _submitId;
                        _sheet.cqs_QuizId = newInfo.QuizId;
                        _sheet.cqs_AccountId = newInfo.UserId;
                        _sheet.cqs_BeginDate = (newInfo.BeginDate!=null)?(DateTime)newInfo.BeginDate:_updateTime;
                        #endregion 屬性對應

                        // insert data
                        crsQuizSubmitRepository.Create(_sheet, true);

                        _oResult = AnswerSubmit(newInfo);

                        // Log info
                        _rLog.SubmitId = _submitId;    //	得分ID
                        _rLog.QuizId = newInfo.QuizId;          //	試卷ID


                        #region  insert Log
                        _rLog.IP = newInfo.IP;
                        _rLog.UserId = newInfo.UserId;
                        _rLog.TheTable = "Submit";         	  // 指定資料表
                        _rLog.BeginDate = _updateTime;        // 開始時間
                        _rLog.EndDate = DateTime.Now;         // 結束時間
                        _rLog.Behavior = 2;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                        _rLog.Success = _oResult.Success;      // 執行成功
                        _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

                        _log.ExamLog(_rLog);
                        #endregion
                    }
                    #endregion 新的答案卷
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return _oResult;
        }
        #endregion 答卷


        #region 答題,一次答一題
        public ObjResult AnswerSubmit(crsQuizDTO newInfo, Boolean isDone = false)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                _rInfo = new crsQuizDTO();
                _answer = new crsQuizSubmitAnswer();
                var _lastRecord = new crsQuizSubmitAnswer();
                var _record = crsQuizSubmitAnswerRepository.GetAll().ToList();

                // 新增序號,取得答案卷最後一筆答題紀錄
                if (_record.Count() > 0)
                    _record = _record.FindAll(a => a.cqsa_SubmitId == newInfo.SubmitId).OrderByDescending(a => a.cqsa_Serial).ToList();
                if (_record.Count() > 0) _lastRecord = _record.First();

                #region 新增答題才需要的欄位
                if (_record.Count() == 0)
                {
                    _answer.cqsa_Serial = 1;
                    _answer.cqsa_BeginDate = (newInfo.BeginDate != null) ? (DateTime)newInfo.BeginDate : DateTime.Now;
                }
                else
                {
                    _answer.cqsa_Serial = _lastRecord.cqsa_Serial + 1;
                    _answer.cqsa_BeginDate = (newInfo.BeginDate != null) ? (DateTime)newInfo.BeginDate : ((_lastRecord.cqsa_EndDate != null) ? (DateTime)_lastRecord.cqsa_EndDate : DateTime.Now);
                }
                _answer.cqsa_SubmitId = (Guid)newInfo.SubmitId;
                _answer.cqsa_PoolId = newInfo.PoolId;
                #endregion


                // 檢查題目是否有答過
                _record = _record.FindAll(a => a.cqsa_SubmitId == newInfo.SubmitId && a.cqsa_PoolId == newInfo.PoolId).OrderByDescending(a => a.cqsa_Serial).ToList();
                if (_record.Count() > 0) _answer = _record.First(); // 更新答題

                #region 屬性對應
                _answer.cqsa_Answer = newInfo.Answer;
                _answer.cqsa_EndDate = (newInfo.EndDate == null) ? DateTime.Now : newInfo.EndDate;
                #endregion 屬性對應

                // 新增答題
                if (_record.Count() == 0 || _answer.cqsa_EndDate != null)
                    crsQuizSubmitAnswerRepository.Create(_answer, true);
                else    // 重新答題,寫入答案
                    crsQuizSubmitAnswerRepository.Update(_answer, true);

                _rInfo.SubmitId = _answer.cqsa_SubmitId;
                _rInfo.PoolId = _answer.cqsa_PoolId;
                _rInfo.Answer = _answer.cqsa_Answer;
                _rInfo.Serial = _answer.cqsa_Serial;
                _rInfo.BeginDate = _answer.cqsa_BeginDate;
                _rInfo.EndDate = _answer.cqsa_EndDate;

                _oResult = _msg.TransformResult(true, _rInfo);

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }


            #region  insert Log
            _rLog.IP = newInfo.IP;
            _rLog.UserId = newInfo.UserId;
            _rLog.TheTable = "Submit";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;        // 錯誤訊息

            _rLog.SubmitId = newInfo.SubmitId;    //	答卷ID
            _rLog.PoolId = newInfo.PoolId;          //	試題ID
            _rLog.Answer = newInfo.Answer;          //	答案內容
            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion 答題


        #region 公布答案
        /// <summary>
        /// </summary>
        public ObjResult AnswerPublish(Guid UserId, String IP, Guid SubmitId)
        {
            ObjResult _oResult = new ObjResult();
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            try
            {
                var _submit = crsQuizSubmitRepository.GetFirst(a => a.cqs_SubmitId == SubmitId);            // 答案卷內容
                if (_submit!=null)
                    if (_submit.cqs_AccountId == UserId)    // 只有答題者本人可取得答案
                    {
                        #region 宣告
                        int _countAnswer;           // 答案計數
                        TimeSpan _endToNowSpan;     // 活動結束至今的天數
                        TimeSpan _scoreToNowSpan;   // 完成批閱至今的天數

                        crsQuestionPool _pool = new crsQuestionPool();            // 試題內容
                        var _score = crsQuizSubmitRepository.GetFirst(a => a.cqs_SubmitId == SubmitId);    // 成績單資訊
                        var _quiz = crsQuizRepository.GetFirst(a => a.cq_QuizId == _score.cqs_QuizId);     // 試卷資訊
                        var _answer = crsQuizSubmitAnswerRepository.Get(a => a.cqsa_SubmitId == SubmitId).ToList();     // 答案內容

                        // 未完成批閱的答卷計數
                        int _countSheet = crsQuizSubmitRepository.Get(a => a.cqs_CompleteScored == false).Count();
                        #region old code
                        //(from s in E4db.crsQuizSubmit
                        //               join a in E4db.crsQuizSubmitAnswer
                        //               on s.cqs_SubmitId equals a.cqsa_SubmitId
                        //               where s.cqs_QuizId == _submit.cqs_QuizId && s.cqs_EndDate != null &&
                        //               a.cqsa_AutoToScoreDate == null && a.cqsa_ReadToScoreDate == null
                        //               select a.cqsa_PoolId).Count();
                        #endregion
                        // 最後批閱時間
                        var _tmpData = crsQuizSubmitRepository.Get(a => a.cqs_EndDate != null && a.cqs_ScoreDate != null).OrderByDescending(a => a.cqs_ScoreDate).Select(a => a.cqs_ScoreDate).First();
                        #region old code
                        //(from s in E4db.crsQuizSubmit
                        //            join a in E4db.crsQuizSubmitAnswer
                        //            on s.cqs_SubmitId equals a.cqsa_SubmitId
                        //            where s.cqs_QuizId == _submit.cqs_QuizId && s.cqs_EndDate != null &&
                        //            (a.cqsa_AutoToScoreDate != null || a.cqsa_ReadToScoreDate != null)
                        //            orderby a.cqsa_ReadToScoreDate descending
                        //            select (a.cqsa_ReadToScoreDate == null) ? a.cqsa_AutoToScoreDate : a.cqsa_ReadToScoreDate).First();
                        #endregion
                        
                        #endregion

                        DateTime _lastScoreTime = (_tmpData == null) ? _updateTime : DateTime.ParseExact(_tmpData.ToString(), "yyyy-MM-dd hh:nn:ss", null);
                        _scoreToNowSpan = _updateTime - _lastScoreTime; // 完成批閱至今的天數
                        _endToNowSpan = _updateTime - (DateTime)_score.cqs_EndDate;   // 活動結束至今的天數

                        crsQuizDTO _scoreData = new crsQuizDTO();
                        foreach (var _record in _answer)
                        #region 判斷答案是否公佈
                        {
                            _scoreData = new crsQuizDTO();
                            _pool = crsQuestionPoolRepository.GetFirst(a => a.cqp_PoolId == _record.cqsa_PoolId);            // 試題內容

                            _scoreData.Success = false; // 預設不公佈
                            _scoreData.SubmitId = _record.cqsa_SubmitId;
                            _scoreData.PoolId = _record.cqsa_PoolId;
                            if (_record.cqsa_EndDate != null)   // 完成答題
                            {
                                #region 自動批閱題型
                                if ((_record.cqsa_AutoToScoreDate != null) && (_pool.cqp_Category < 4))
                                {   // 繳卷後馬上公佈
                                    if (_quiz.cq_DisplayAnswer == 0 && _submit.cqs_EndDate != null) _scoreData.Success = true;
                                    else if (_quiz.cq_DisplayAnswer == 0) _scoreData.ErrorMessage = String.Format(_msg.Get("msgUndone"), "");
                                    
                                    // 活動結束後馬上公佈
                                    if (_quiz.cq_DisplayAnswer == 1 && _quiz.cq_EndDate < _updateTime) _scoreData.Success = true;
                                    else if (_quiz.cq_DisplayAnswer == 1) _scoreData.ErrorMessage = String.Format(_msg.Get("msgTimeYetCome"), _msg.Get("actPublish"));

                                    // 活動結束後?天公佈
                                    if (_quiz.cq_DisplayAnswer == 2 && _endToNowSpan.Days >= _quiz.cq_DispAnsPutOffDays) _scoreData.Success = true;
                                    else if (_quiz.cq_DisplayAnswer == 2) _scoreData.ErrorMessage = String.Format(_msg.Get("msgTimeYetCome"), _msg.Get("actPublish"));
                                }
                                #endregion

                                #region 教師批閱題型
                                _countAnswer = _answer.FindAll(a => a.cqsa_ReadToScoreDate == null && a.cqsa_AutoToScoreDate == null).Count();   // 未批閱的試題
                                if ((_record.cqsa_ReadToScoreDate != null) && (_pool.cqp_Category > 3))
                                {   // 批閱完個別學生後馬上公佈
                                    if (_quiz.cq_CheckDisplayAnswer == 0 && _countAnswer == 0) _scoreData.Success = true;
                                    else if (_quiz.cq_CheckDisplayAnswer == 0) _scoreData.ErrorMessage = String.Format(_msg.Get("msgUndone"), _msg.Get("actScore"));

                                    // 批閱完所有考卷後公佈
                                    if (_quiz.cq_CheckDisplayAnswer == 1 && _countSheet == 0) _scoreData.Success = true;
                                    else if (_quiz.cq_CheckDisplayAnswer == 1) _scoreData.ErrorMessage = String.Format(_msg.Get("msgUndone"), _msg.Get("actScore"));

                                    //  批閱完所有考卷後?天公佈
                                    if (_quiz.cq_CheckDisplayAnswer == 2 && _countSheet == 0 && _scoreToNowSpan.Days > _quiz.cq_CkDispScorePutOffDays) _scoreData.Success = true;
                                    else if (_quiz.cq_CheckDisplayAnswer == 2) _scoreData.ErrorMessage = String.Format(_msg.Get("msgTimeYetCome"), _msg.Get("actPublish"));
                                }
                                #endregion
                            }
                            else _scoreData.ErrorMessage = String.Format(_msg.Get("msgUndone"), _msg.Get("actAnswer"));

                            // Update data
                            if (_scoreData.Success == true)
                            {
                                _record.cqsa_PublishDate = _updateTime;
                                crsQuizSubmitAnswerRepository.Update(_record, false);
                            }

                            _list.Add(_scoreData);
                        }
                        #endregion
                        crsQuizSubmitAnswerRepository.SaveChanges();

                        #region  insert Log
                        foreach(var _rInfo in _list)
                        { 
                            _rLog.QuizId = _submit.cqs_QuizId;
                            _rLog.SubmitId = _submit.cqs_SubmitId;
                            _rLog.PoolId = _rInfo.PoolId;
                            _rLog.AccountId = _submit.cqs_AccountId;

                            _rLog.IP = IP;                  // 使用者來源位址
                            _rLog.UserId = UserId;
                            _rLog.TheTable = "Submit";       // 指定資料表
                            _rLog.BeginDate = _updateTime;  // 開始時間
                            _rLog.EndDate = DateTime.Now;   // 結束時間
                            _rLog.Behavior = 7;             // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6       
                            _rLog.Success = true;           // 執行成功
                            _rLog.ErrorMessage = null;      // 錯誤訊息

                            if (_rInfo.Success == true)
                                _log.ExamLog(_rLog);
                        }
                        #endregion


                        _oResult = _msg.TransformResult(true, _list);
                    }
                    else _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actGet"), _msg.Get("objAnswer")));
                else _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), ""));
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return _oResult;
        }
        #endregion

        #endregion 答案卷


        #region 自動批閱
        #region 答卷
        public ObjResult SheetAutoToScore(Guid UserId, String IP, Guid QuizId, Guid? accountId, Guid? submitId)
        {
            ObjResult _oResult = new ObjResult();
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            try
            {
                // get record
                var _records = crsQuizSubmitRepository.Get(a => a.cqs_QuizId == QuizId && a.cqs_EndDate != null).OrderByDescending(a => a.cqs_EndDate).ToList();

                if (submitId != null)
                    _records = crsQuizSubmitRepository.Get(a => a.cqs_SubmitId == submitId).ToList();
                else if (accountId != null)
                    _records = crsQuizSubmitRepository.Get(a => a.cqs_QuizId == QuizId && a.cqs_AccountId == accountId).ToList();

                foreach (var _obj in _records)
                {
                    _rInfo = new crsQuizDTO();
                    if (_obj.cqs_EndDate == null)
                    {
                        _rInfo.Success = false;
                        _rInfo.SubmitId = _obj.cqs_SubmitId;
                        _rInfo.Comment = String.Format(_msg.Get("msgIncomplete"), "SubmitId : " + _obj.cqs_SubmitId);

                        _list.Add(_rInfo);
                    }
                    else
                    #region 批閱
                    {
                        // 檢查答案
                        ObjResult _rsAutoToScore = AnswerAutoToScore(UserId, IP, _obj.cqs_QuizId, _obj.cqs_SubmitId);

                        // 更新批閱時間,分數
                        if (_rsAutoToScore.Success)
                        {
                            ObjResult _rsAnswer = AnswerMatchRateSum(UserId, IP, _obj.cqs_SubmitId, true, true);
                            if (_rsAnswer.Success)
                            {
                                var _rsData = (crsQuizDTO)_rsAnswer.DataCollection;
                            
                                _rInfo.QuizId = _rsData.QuizId;
                                _rInfo.MatchRate = _rsData.MatchRate;  //	成績
                                _rInfo.ExtraScore = _rsData.ExtraScore;  //	額外調分
                                _rInfo.CompleteScored = _rsData.CompleteScored; // 完成批閱
                            }
                            else _rInfo.ErrorMessage = _rsAnswer.ErrorMessage;

                            _rInfo.Success = _rsAnswer.Success;
                        }
                        else
                        { 
                            _rInfo.Success = false;
                            _rInfo.ErrorMessage = _rsAutoToScore.ErrorMessage;
                        }

                        _rInfo.SubmitId = _obj.cqs_SubmitId;

                        _list.Add(_rInfo);
                    }
                    #endregion
                }

                if (_records.Count>0) _oResult = _msg.TransformResult(true, _rInfo);
                else _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), ""));

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }


            return _oResult;
        }
        #endregion


        #region 檢查答案
        public ObjResult AnswerAutoToScore(Guid UserId, String IP, Guid QuizId, Guid SubmitId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // get score info defaultScore
                decimal _scoreTotal = new decimal(0.0000);
                var _scoreInfo = crsQuizQuestionRepository.GetFirst(a => a.cqq_QuizId == QuizId);
                var _quizInfo = crsQuizRepository.GetFirst(a => a.cq_QuizId == QuizId);
                var _poolList = crsQuestionPoolRepository.GetAll().Take(1).ToList();
                var _optionList = crsQuestionPoolOptionRepository.GetAll().Take(1).ToList();
                var _option = crsQuestionPoolOptionRepository.GetFirst(a => a.cqpo_OptionId != null);
                var _record = crsQuizSubmitAnswerRepository.GetFirst(a => a.cqsa_SubmitId == SubmitId);

                // get record
                var _records = crsQuizSubmitAnswerRepository.Get(a => a.cqsa_SubmitId == SubmitId).OrderByDescending(a => a.cqsa_Serial).ToList();
                foreach (var _obj in _records)
                {
                    // 題型
                    int _gategory = -1;  // 題型
                    _pool = crsQuestionPoolRepository.GetFirst(a => a.cqp_PoolId == _obj.cqsa_PoolId);
                    _gategory=_pool.cqp_Category;


                    #region 題目分數資訊
                    decimal _scorePlus = new decimal(0.0000);
                    decimal _scoreMinus = new decimal(0.0000);

                    _scoreInfo = crsQuizQuestionRepository.GetFirst(a => a.cqq_QuizId == QuizId && a.cqq_PoolId == _obj.cqsa_PoolId);

                    // 試卷已選定的題目資訊
                    if (_scoreInfo != null)
                    {
                        _scorePlus = (_scoreInfo.cqq_ScorePlus==null)?0:(decimal)_scoreInfo.cqq_ScorePlus;
                        _scoreMinus = (_scoreInfo.cqq_ScoreMinus == null) ? 0 : (decimal)_scoreInfo.cqq_ScoreMinus;

                        // 填充,依答案數量平均分配分數
                        if (_gategory == 4) 
                        {
                            _optionList = crsQuestionPoolOptionRepository.Get(a => a.cqpo_PoolId == _obj.cqsa_PoolId).ToList();
                            _scorePlus = decimal.Round(_scorePlus / _optionList.Count, 2, MidpointRounding.AwayFromZero);
                            _scoreMinus = decimal.Round(_scoreMinus / _optionList.Count, 2, MidpointRounding.AwayFromZero);
                        }
                    }
                    // 從題庫隨機選取的題目
                    else    
                    {
                        if (_pool.cqp_OriginalGroupId != null)
                            _poolList = crsQuestionPoolRepository.Get(a => a.cqp_OriginalGroupId == _pool.cqp_OriginalGroupId).ToList();

                        _scoreMinus = 0;

                        // 依題庫(型)題目數量平均分配分數
                        _scorePlus = (_quizInfo.cq_DefaultScore == null) ? 0 : decimal.Round((decimal)_quizInfo.cq_DefaultScore / _poolList.Count, 2, MidpointRounding.AwayFromZero);

                        // 填充,依答案數量平均分配分數
                        if (_gategory == 4)
                        {
                            _optionList = crsQuestionPoolOptionRepository.Get(a => a.cqpo_PoolId == _obj.cqsa_PoolId).ToList();
                            _scorePlus = decimal.Round(_scorePlus / _optionList.Count, 2, MidpointRounding.AwayFromZero);
                        }
                    }
                    #endregion 題目分數資訊


                    #region 檢驗答案
                    string[] _answerList = _obj.cqsa_Answer.Split('|');

                    bool _isCorrect = (_answerList.Length > 0) ? true : false;

                    if (_gategory ==1 || _gategory ==2)     // 是非、選擇
                    {
                        _option = crsQuestionPoolOptionRepository.GetFirst(a => a.cqpo_PoolId == _obj.cqsa_PoolId && a.cqpo_IsAnswer == true);
                        _isCorrect = (_option.cqpo_OptionId.ToString()==_obj.cqsa_Answer.Trim())?true:false;
                    }
                    else if (_gategory == 3)   // 複選題
                    {
                        List<Guid> _ansList = new List<Guid>();
                        foreach (var _ans in _answerList)
                            _ansList.Add(Guid.Parse(_ans));

                        _optionList = crsQuestionPoolOptionRepository.Get(a => a.cqpo_PoolId == _obj.cqsa_PoolId && a.cqpo_IsAnswer).OrderBy(a => a.cqpo_OptionId).ToList();
                        // 比較答案和正解是否完全相同
                        _isCorrect = (_ansList.Count() == _optionList.Count()) && (_ansList.Except(_optionList.Select(a => a.cqpo_OptionId).ToList()).Count() == 0);     
                    }
                    else if (_gategory==4)   // 填充題
                    {
                        int _serial = 0;
                        decimal _scoreSum = new decimal(0.0000);
                        foreach (var _answer in _answerList)
                        {
                            _serial++;
                            _option = crsQuestionPoolOptionRepository.GetFirst(a => a.cqpo_Content == _answer.Trim() && a.cqpo_Serial == _serial);
                            if (_option != null) _scoreSum = _scoreSum + _scorePlus;
                            else _scoreSum = _scoreSum - _scoreMinus;
                        }
                        // 重設分數
                        _scoreMinus = (_scoreSum <= 0) ? 0 - _scoreSum : 0;
                        _scorePlus = (_scoreSum > 0) ? _scoreSum : 0;
                        if (_scorePlus <= 0) _isCorrect = false;
                    }

                    #endregion

                    // 非題組或問答題,才更新自動批閱資訊
                    if (_gategory > 0 && _gategory < 5)
                    {
                        if (_isCorrect == true)
                                _scoreTotal = _scoreTotal + _scorePlus;
                        else    _scoreTotal = _scoreTotal - _scoreMinus;

                        _record = crsQuizSubmitAnswerRepository.GetFirst(a => a.cqsa_SubmitId == SubmitId && a.cqsa_PoolId == _obj.cqsa_PoolId && a.cqsa_Serial == _obj.cqsa_Serial);
                        _record.cqsa_AutoToScoreDate = _updateTime;
                        _record.cqsa_MatchRate = _scoreTotal;
                        _record.cqsa_IsCorrect = _isCorrect;

                        crsQuizSubmitAnswerRepository.Update(_record, true);

                        #region  insert Log
                        _rLog.IP = IP;
                        _rLog.UserId = UserId;
                        _rLog.TheTable = "Submit";         	  // 指定資料表
                        _rLog.BeginDate = _updateTime;        // 開始時間
                        _rLog.EndDate = DateTime.Now;         // 結束時間
                        _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                        _rLog.Success = true;        // 執行成功

                        _rLog.SubmitId = SubmitId;    //	得分ID
                        _rLog.MatchRate = _record.cqsa_MatchRate;   //	成績
                        _rLog.PoolId = _record.cqsa_PoolId;          //	試題ID
                        _rLog.IsCorrect = _record.cqsa_IsCorrect;   //	1:答案正確; 0:錯誤
                        _log.ExamLog(_rLog);
                        #endregion 
                    }
                }

                if (_records.Count > 0) _oResult = _msg.TransformResult(true, _msg.Get("msgSucceed"));
                else _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "SubmitId:" + SubmitId));
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            if (_oResult.Success==false)
            {
                _rLog.IP = IP;
                _rLog.UserId = UserId;
                _rLog.TheTable = "Submit";         	  // 指定資料表
                _rLog.BeginDate = _updateTime;        // 開始時間
                _rLog.EndDate = DateTime.Now;         // 結束時間
                _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                _rLog.Success = _oResult.Success;        // 執行成功
                _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

                if (QuizId == null) _rLog.QuizId = QuizId;    //	得分ID
                if (SubmitId == null) _rLog.SubmitId = SubmitId;    //	得分ID
                _log.ExamLog(_rLog);
            }
            #endregion


            return _oResult;
        }
        #endregion

        #endregion 自動批閱


        #region 手動(教師)批閱
        #region 考題批閱
        /// <summary>
        /// 必要欄位：SubmitId/答卷ID　　PoolId/答題ID　　Score/分數　||　選填欄位：Criticism/評語
        /// </summary>
        public ObjResult SheetReadToScore(crsQuizDTO infoData)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                var _record = crsQuizSubmitAnswerRepository.GetFirst(a => a.cqsa_SubmitId == infoData.SubmitId && a.cqsa_PoolId == infoData.PoolId);    // 答題資訊
                if (_record!=null)
                {
                    _record.cqsa_ReadToScoreDate = _rInfo.ReadToScoreDate = _updateTime;
                    _record.cqsa_MatchRate = _rInfo.Score = infoData.Score;
                    if (infoData.Criticism != null) _record.cqsa_Criticism = infoData.Criticism;    // 評語

                    crsQuizSubmitAnswerRepository.Update(_record, true);
                    _oResult = AnswerMatchRateSum(infoData.UserId, infoData.IP, (Guid)infoData.SubmitId);

                    _rInfo = (crsQuizDTO)_oResult.DataCollection;
                    _rInfo.PoolId = infoData.PoolId;
                    _rInfo.Criticism = infoData.Criticism;
                    _rInfo.Score = infoData.Score;

                    _oResult = _msg.TransformResult(true, _rInfo);

                    // Log info
                    _rLog.SubmitId = _record.cqsa_SubmitId;    //	得分ID
                    _rLog.MatchRate = _record.cqsa_MatchRate;   //	成績
                    _rLog.PoolId = _record.cqsa_PoolId;          //	試題ID
                    _rLog.Criticism = _record.cqsa_Criticism;          //	評語
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), ""));

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = infoData.IP;
            _rLog.UserId = infoData.UserId;
            _rLog.TheTable = "Submit";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;      // 錯誤訊息

            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion


        #region 考卷批閱
        /// <summary>
        /// 必要欄位：SubmitId/答卷ID　　Score/分數　||　選填欄位：Criticism/評語　　ExtraScore/額外調分　　IsMainSheet/為最終成績答案卷
        /// </summary>
        public ObjResult SheetToScore(crsQuizDTO infoData, Boolean PickSeet)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // 成績計算
                if(infoData.ExtraScore != null)
                    AnswerMatchRateSum(infoData.UserId, infoData.IP, (Guid)infoData.SubmitId, PickSeet, false, true, (decimal)infoData.ExtraScore);
                else
                    AnswerMatchRateSum(infoData.UserId, infoData.IP, (Guid)infoData.SubmitId, PickSeet);

                var _sheet = crsQuizSubmitRepository.GetFirst(a => a.cqs_SubmitId == infoData.SubmitId);    // 答卷資訊
                if (_sheet != null)
                {
                    if (infoData.Criticism != null) _sheet.cqs_Criticism = infoData.Criticism;    // 評語
                    if (infoData.ExtraScore != null)_sheet.cqs_ExtraScore = infoData.ExtraScore;    // 額外調分
                    if (infoData.IsMainSheet != null) _sheet.cqs_IsMainSheet = infoData.IsMainSheet;    // 1:主要成績的答案卷; 0:非取用的答案卷

                    crsQuizSubmitRepository.Update(_sheet, true);
                    
                    _rInfo.SubmitId = infoData.SubmitId;
                    _rInfo.QuizId = _sheet.cqs_QuizId;
                    _rInfo.StudentId = _sheet.cqs_AccountId;
                    _rInfo.MatchRate = _sheet.cqs_MatchRate;
                    _rInfo.ExtraScore = _sheet.cqs_ExtraScore;
                    _rInfo.Criticism = _sheet.cqs_Criticism;
                    _rInfo.IsMainSheet = _sheet.cqs_IsMainSheet;
                    _rInfo.CompleteScored = _sheet.cqs_CompleteScored;
                    _rInfo.UpdateTime = _sheet.cqs_ScoreDate;

                    _oResult = _msg.TransformResult(true, _rInfo);

                    // Log info
                    _rLog.SubmitId  = _sheet.cqs_SubmitId;    //	得分ID
                    _rLog.QuizId    = _sheet.cqs_QuizId;          //	試卷ID
                    _rLog.MatchRate = _sheet.cqs_MatchRate;   //	成績
                    _rLog.ExtraScore    = _sheet.cqs_ExtraScore;  //	額外調分
                    _rLog.IsMainSheet   = _sheet.cqs_IsMainSheet; //	1:主要成績的答案卷; 0:非取用的答案卷
                    _rLog.Criticism     = _sheet.cqs_Criticism;          //	評語
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), ""));

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = infoData.IP;
            _rLog.UserId = infoData.UserId;
            _rLog.TheTable = "Submit";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;   // 錯誤訊息

            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion
        #endregion


        #region 答卷成績計算
        public ObjResult AnswerMatchRateSum(Guid UserId, String IP, Guid SubmitId, Boolean PickSeet = true, Boolean autoToScore = false, Boolean addExtra = false, Decimal ExtraScore = 0)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                var _record = crsQuizSubmitRepository.GetFirst(a => a.cqs_SubmitId == SubmitId);    // 答卷資訊
                if(_record!=null)
                { 
                    var _records = crsQuizSubmitAnswerRepository.Get(a => a.cqsa_SubmitId == SubmitId).ToList();    // 答題資訊
                    var _quizInfo = crsQuizRepository.GetFirst(a => a.cq_QuizId == _record.cqs_QuizId); // 試卷資訊
                    var _ScoreSettin = _quizInfo.cq_ScoreSetting.Split('|');    // 評分設定

                    _record.cqs_ScoreDate = _updateTime;
                    _record.cqs_MatchRate = _records.Sum(a=>a.cqsa_MatchRate);
                    if (addExtra == true)
                    {
                        _record.cqs_ExtraScore = ExtraScore;
                        _record.cqs_MatchRate = _record.cqs_MatchRate + ExtraScore;
                    }

                    // 成績進位至整數
                    if (Convert.ToInt32(_ScoreSettin[2]) == 0)
                        _record.cqs_MatchRate = decimal.Round((decimal)_record.cqs_MatchRate, 0, MidpointRounding.AwayFromZero);

                    // 判斷是否所有題目都批閱完成
                    if (_records.FindAll(a => a.cqsa_ReadToScoreDate == null && a.cqsa_AutoToScoreDate == null).Count() == 0)
                    {
                        _record.cqs_CompleteScored = true;
                        if (PickSeet) SheetPick(UserId, IP, _record.cqs_QuizId, _record.cqs_AccountId);   // 檢查並選取考卷為最終成績單
                    }
                    else
                    { 
                        _record.cqs_CompleteScored = false;
                        crsQuizDTO _scoreData = new crsQuizDTO();
                        _scoreData.UserId = UserId;
                        _scoreData.StudentId = _record.cqs_AccountId;
                        _scoreData.QuizId = _record.cqs_QuizId;
                        _scoreData.Score = _record.cqs_MatchRate;
                        _scoreData.Checked = (autoToScore) ? 0 : 1;
                        StudentScore(_scoreData); // 成績單
                    }

                    crsQuizSubmitRepository.Update(_record, true);

                    _rInfo.SubmitId = SubmitId;
                    _rInfo.QuizId = _record.cqs_QuizId;
                    _rInfo.StudentId = _record.cqs_AccountId;
                    _rInfo.MatchRate = _record.cqs_MatchRate;
                    _rInfo.ExtraScore = _record.cqs_ExtraScore;
                    _rInfo.CompleteScored = _record.cqs_CompleteScored;
                    _rInfo.ScoreDate = _record.cqs_ScoreDate;

                    _oResult = _msg.TransformResult(true, _rInfo);

                    // Log info
                    _rLog.SubmitId = SubmitId;    //	得分ID
                    _rLog.QuizId = _record.cqs_QuizId;          //	試卷ID
                    _rLog.MatchRate = _record.cqs_MatchRate;   //	成績
                    _rLog.ExtraScore = _record.cqs_ExtraScore;  //	額外調分
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), SubmitId));
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = IP;
            _rLog.UserId = UserId;
            _rLog.TheTable = "Submit";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;       // 錯誤訊息

            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion


        #region 批閱成績單(針對無試題的試卷可直接給分, ex.課堂筆試)
        /// <summary>
        /// 必要欄位：StudentId/學生ID　　QuizId/試卷ID　　Score/分數　||　選填欄位：GradePoint/學分　　Criticism/評語　　Checked/批閱狀態
        /// </summary>
        public ObjResult StudentScore(crsQuizDTO scoreData)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                // 成績單資訊
                crsQuizScore _record = new crsQuizScore();
                if ((scoreData.ScoreId == null) || ((scoreData.ScoreId.ToString().Substring(0, 8) == "00000000")))
                        _record = crsQuizScoreRepository.GetFirst(a => a.cqs_QuizId == scoreData.QuizId && a.cqs_AccountId == scoreData.StudentId);
                else    _record = crsQuizScoreRepository.GetFirst(a => a.cqs_ScoreId == scoreData.ScoreId);

                if (_record != null)
                #region 修改
                {
                    _record.cqs_UpdateTime = _rInfo.UpdateTime = _updateTime;
                    _record.cqs_EditorId = _rInfo.EditorId = scoreData.UserId;
                    if (scoreData.GradePoint != null) _record.cqs_GradePoint = scoreData.GradePoint;    // 學分
                    if (scoreData.Criticism != null) _record.cqs_Criticism = scoreData.Criticism;    // 評語
                    if (scoreData.Checked != null) _record.cqs_Checked = (int)scoreData.Checked;    // 0:自動批閱, 1:待批閱, 2:已批閱

                    crsQuizScoreRepository.Update(_record, true);
                    
                    // Log info
                    _rLog.ScoreId       = _rInfo.ScoreId    = _record.cqs_ScoreId;   //	得分ID	
                    _rLog.QuizId        = _rInfo.QuizId     = _record.cqs_QuizId;   //	試卷ID	
                    _rLog.Score         = _rInfo.Score      = _record.cqs_Score;   //	分數	
                    _rLog.Checked       = _rInfo.Checked    = _record.cqs_Checked;   //	0:自動批閱, 1:待批閱, 2:已批閱	
                    _rLog.Criticism     = _rInfo.Criticism  = _record.cqs_Criticism;   //	評語	
                    _rLog.GradePoint    = _rInfo.GradePoint = _record.cqs_GradePoint;   //	學分	
                    _rLog.AccountId     = _rInfo.AccountId  = _record.cqs_AccountId;  // 帳號識別碼-考生
                    _rLog.Behavior = 3;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                }
                #endregion 修改
                else
                #region 新增
                {
                    System.Guid _scoreId = Guid.NewGuid();

                    #region 屬性對應
                    _score.cqs_ScoreId = _scoreId;    // 得分ID
                    _score.cqs_SubmitId = (scoreData.SubmitId != null) ? scoreData.SubmitId : scoreData.StudentId;    // 答卷ID, 無題目的試卷(記分用)答卷ID=考生ID
                    _score.cqs_AccountId = scoreData.StudentId;    // 帳號識別碼-考生
                    _score.cqs_CreaterId = scoreData.UserId;    // 建立者ID
                    _score.cqs_CreateTime = _updateTime;    // 建立時間
                    _score.cqs_EditorId = scoreData.UserId;    // 更新者
                    _score.cqs_UpdateTime = _updateTime;    // 最後更新時間

                    _score.cqs_QuizId = scoreData.QuizId;    // 試卷ID
                    _score.cqs_Score = scoreData.Score;    // 分數
                    _score.cqs_GradePoint = scoreData.GradePoint;    // 學分
                    if (scoreData.Criticism != null) _score.cqs_Criticism = scoreData.Criticism;    // 評語
                    _score.cqs_Checked = 2;    // 0:自動批閱, 1:待批閱, 2:已批閱
                    #endregion 屬性對應

                    crsQuizScoreRepository.Create(_score, true);

                    // Log info
                    _rLog.ScoreId   = _rInfo.ScoreId    = _score.cqs_ScoreId;   //	得分ID	
                    _rLog.QuizId    = _rInfo.QuizId     = _score.cqs_QuizId;   //	試卷ID	
                    _rLog.AccountId = _rInfo.AccountId  = _score.cqs_AccountId;   //	考生ID	
                    _rLog.Score     = _rInfo.Score      = _score.cqs_Score;   //	分數	
                    _rLog.Checked   = _rInfo.Checked    = 2;   //	0:自動批閱, 1:待批閱, 2:已批閱	
                    _rLog.Criticism = _rInfo.Criticism  = _score.cqs_Criticism;   //	評語	
                    _rLog.GradePoint    = _rInfo.GradePoint     = _score.cqs_GradePoint;   //	學分	
                    _rLog.Behavior = 2;       // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                }
                #endregion

                _rInfo.Success = true;
                _oResult = _msg.TransformResult(true, _rInfo);
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            #region  insert Log
            _rLog.IP = scoreData.IP;
            _rLog.UserId = scoreData.UserId;
            _rLog.TheTable = "Score";         	  // 指定資料表
            _rLog.BeginDate = _updateTime;        // 開始時間
            _rLog.EndDate = DateTime.Now;         // 結束時間
            // _rLog.IP = CurrentState.ClientIP;     // 使用者來源位址
            _rLog.Success = _oResult.Success;      // 執行成功
            _rLog.ErrorMessage = _oResult.ErrorMessage;      // 錯誤訊息

            _log.ExamLog(_rLog);
            #endregion

            return _oResult;
        }
        #endregion


        #region 公布成績
        /// <summary>
        /// </summary>
        public ObjResult ScorePublish(Guid UserId, String IP, Guid QuizId, Guid? StudentId)
        {
            ObjResult _oResult = new ObjResult();
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            try
            {
                int _countAuto;     // 自動批閱題型計數
                int _countRead;     // 教師批閱題型計數
                int _countAnswer;       // 答案計數

                SheetPick(UserId, IP, QuizId, StudentId);   // 最終取用的成績(選擇答卷)
                var _quiz = crsQuizRepository.GetFirst(a => a.cq_QuizId == QuizId);     // 試卷資訊

                // 判斷權限, 0:不公佈1:個別公佈,學生可查閱自己的成績, 2:公開全部考生成績
                CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)_quiz.cq_CourseId, UserId);
                if (_coursePermissions.ScoreAnnouncementSetting || ((UserId == StudentId) && (_quiz.cq_DisplayScoreType == 1)) || (_quiz.cq_DisplayScoreType == 2))
                { 
                    var _score = crsQuizScoreRepository.Get(a => a.cqs_QuizId == QuizId).OrderByDescending(a=>a.cqs_UpdateTime).ToList();    // 成績單資訊                    
                    if (StudentId != null) _score = _score.FindAll(a => a.cqs_AccountId == StudentId).ToList();    // 特定學生的成績
                    #region 宣告
                    TimeSpan _endToNowSpan;     // 活動結束至今的天數
                    TimeSpan _scoreToNowSpan;   // 完成批閱至今的天數

                    crsQuestionPool _pool = new crsQuestionPool();                                        // 試題內容

                    // 未完成批閱的答卷計數
                    int _countSheet = crsQuizSubmitRepository.Get(a => a.cqs_CompleteScored == false).Count();
                    #region old code
                    //(from s in E4db.crsQuizSubmit
                    //               join a in E4db.crsQuizSubmitAnswer
                    //               on s.cqs_SubmitId equals a.cqsa_SubmitId
                    //               where s.cqs_QuizId == _submit.cqs_QuizId && s.cqs_EndDate != null &&
                    //               a.cqsa_AutoToScoreDate == null && a.cqsa_ReadToScoreDate == null
                    //               select a.cqsa_PoolId).Count();
                    #endregion
                    // 最後批閱時間
                    var _tmpData = crsQuizSubmitRepository.Get(a => a.cqs_EndDate != null && a.cqs_ScoreDate != null).OrderByDescending(a => a.cqs_ScoreDate).Select(a => a.cqs_ScoreDate).First();
                    #region old code
                    //(from s in E4db.crsQuizSubmit
                    //            join a in E4db.crsQuizSubmitAnswer
                    //            on s.cqs_SubmitId equals a.cqsa_SubmitId
                    //            where s.cqs_QuizId == _submit.cqs_QuizId && s.cqs_EndDate != null &&
                    //            (a.cqsa_AutoToScoreDate != null || a.cqsa_ReadToScoreDate != null)
                    //            orderby a.cqsa_ReadToScoreDate descending
                    //            select (a.cqsa_ReadToScoreDate == null) ? a.cqsa_AutoToScoreDate : a.cqsa_ReadToScoreDate).First();
                    #endregion

                    DateTime _lastScoreTime = (_tmpData == null) ? _updateTime : (DateTime)_tmpData; // DateTime.ParseExact(_tmpData.ToString(), "yyyy-MM-dd hh:nn:ss", null);
                    _scoreToNowSpan = _updateTime - _lastScoreTime; // 完成批閱至今的天數
                    _endToNowSpan = _updateTime - (DateTime)_quiz.cq_EndDate;   // 活動結束至今的天數
                    #endregion


                    crsQuizDTO _scoreData = new crsQuizDTO();
                    foreach (var _sheet in _score)
                    {
                        _scoreData = new crsQuizDTO();  // 公佈名單
                        _scoreData.Success = false;     // 預設不公佈
                        _scoreData.StudentId = _sheet.cqs_AccountId;

                        // 最後一次繳交試卷資訊
                        var _submit = crsQuizSubmitRepository.Get(a => a.cqs_QuizId == QuizId && a.cqs_AccountId == _sheet.cqs_AccountId && a.cqs_EndDate!=null).OrderByDescending(a => a.cqs_EndDate).First();      
                        

                        #region 自動批閱題型
                        #region 題型計數
                        if (_submit != null)
                                _countAuto = (from s in E4db.crsQuizSubmit
                                                join a in E4db.crsQuizSubmitAnswer
                                                on s.cqs_SubmitId equals a.cqsa_SubmitId
                                                join p in E4db.crsQuestionPool
                                                on a.cqsa_PoolId equals p.cqp_PoolId
                                                where s.cqs_QuizId == QuizId && s.cqs_AccountId == _sheet.cqs_AccountId && s.cqs_EndDate != null &&
                                                p.cqp_Category > 0 && p.cqp_Category < 4 && s.cqs_SubmitId == _submit.cqs_SubmitId
                                                select a.cqsa_PoolId).Count();
                        else    _countAuto = (from s in E4db.crsQuizSubmit
                                                join a in E4db.crsQuizSubmitAnswer
                                                on s.cqs_SubmitId equals a.cqsa_SubmitId
                                                join p in E4db.crsQuestionPool
                                                on a.cqsa_PoolId equals p.cqp_PoolId
                                                where s.cqs_QuizId == QuizId && s.cqs_AccountId == _sheet.cqs_AccountId && s.cqs_EndDate != null &&
                                                p.cqp_Category > 0 && p.cqp_Category < 4 
                                                select a.cqsa_PoolId).Count();
                        #endregion

                        if ((_countAuto > 0))
                        {
                            if (_quiz.cq_DisplayScore == 0) _scoreData.Success = true;

                            if ((_quiz.cq_DisplayScore == 1 || _quiz.cq_DisplayScore == null) && _quiz.cq_EndDate < _updateTime) _scoreData.Success = true;
                            else if (_quiz.cq_EndDate > _updateTime) _scoreData.ErrorMessage = String.Format(_msg.Get("msgTimeYetCome"), _msg.Get("actPublish"));

                            if (_quiz.cq_DisplayScore == 2 && _endToNowSpan.Days >= _quiz.cq_DispAnsPutOffDays) _scoreData.Success = true;
                            else if (_quiz.cq_DisplayScore == 2) _scoreData.ErrorMessage = String.Format(_msg.Get("msgTimeYetCome"), _msg.Get("actPublish"));
                        }
                        #endregion

                        #region 教師批閱題型
                        #region 計數
                        if (_submit != null)    // 題型計數
                            _countRead = (from s in E4db.crsQuizSubmit
                                            join a in E4db.crsQuizSubmitAnswer
                                            on s.cqs_SubmitId equals a.cqsa_SubmitId
                                            join p in E4db.crsQuestionPool
                                            on a.cqsa_PoolId equals p.cqp_PoolId
                                            where s.cqs_QuizId == QuizId && s.cqs_AccountId == _sheet.cqs_AccountId && s.cqs_EndDate != null &&
                                            p.cqp_Category > 3 && s.cqs_SubmitId == _submit.cqs_SubmitId
                                            select a.cqsa_PoolId).Count();
                        else _countRead = (from s in E4db.crsQuizSubmit
                                            join a in E4db.crsQuizSubmitAnswer
                                            on s.cqs_SubmitId equals a.cqsa_SubmitId
                                            join p in E4db.crsQuestionPool
                                            on a.cqsa_PoolId equals p.cqp_PoolId
                                            where s.cqs_QuizId == QuizId && s.cqs_AccountId == _sheet.cqs_AccountId && s.cqs_EndDate != null &&
                                            p.cqp_Category > 3
                                            select a.cqsa_PoolId).Count();

                        if (_submit != null)    // 未批閱的試題
                            _countAnswer = (from s in E4db.crsQuizSubmit
                                                join a in E4db.crsQuizSubmitAnswer
                                                on s.cqs_SubmitId equals a.cqsa_SubmitId
                                                where s.cqs_QuizId == QuizId && s.cqs_AccountId == _sheet.cqs_AccountId && s.cqs_EndDate != null &&
                                                a.cqsa_ReadToScoreDate == null && a.cqsa_AutoToScoreDate == null && s.cqs_SubmitId == _submit.cqs_SubmitId
                                                select a.cqsa_PoolId).Count();
                        else _countAnswer = (from s in E4db.crsQuizSubmit
                                                join a in E4db.crsQuizSubmitAnswer
                                                on s.cqs_SubmitId equals a.cqsa_SubmitId
                                                where s.cqs_QuizId == QuizId && s.cqs_AccountId == _sheet.cqs_AccountId && s.cqs_EndDate != null &&
                                                a.cqsa_ReadToScoreDate == null && a.cqsa_AutoToScoreDate == null
                                                select a.cqsa_PoolId).Count();
                        #endregion


                        if (_countRead > 0)
                        {
                            if (_quiz.cq_CheckDisplayScore == 0 && _countAnswer ==0) _scoreData.Success = true;
                            else if (_quiz.cq_DisplayAnswer == 0) _scoreData.ErrorMessage = String.Format(_msg.Get("msgUndone"), _msg.Get("actScore"));

                            if ((_quiz.cq_CheckDisplayScore == 1 || _quiz.cq_CheckDisplayScore == null) && _countSheet == 0) _scoreData.Success = true;
                            else if (_quiz.cq_CheckDisplayScore == 1) _scoreData.ErrorMessage = String.Format(_msg.Get("msgUndone"), _msg.Get("actScore"));

                            if (_quiz.cq_CheckDisplayScore == 2 && _countSheet == 0 && _scoreToNowSpan.Days > _quiz.cq_CkDispScorePutOffDays) _scoreData.Success = true;
                            else if (_quiz.cq_CheckDisplayScore == 2) _scoreData.ErrorMessage = String.Format(_msg.Get("msgTimeYetCome"), _msg.Get("actPublish"));
                        }
                        #endregion

                        // Update data
                        if (_scoreData.Success == true)
                        {
                            _scoreData.ScoreId = _sheet.cqs_ScoreId;
                            _scoreData.AccountId = _sheet.cqs_AccountId;
                            _scoreData.SubmitId = _sheet.cqs_SubmitId;
                            _scoreData.PublishDate = _sheet.cqs_PublishDate = _updateTime;
                            crsQuizScoreRepository.Update(_sheet, false);
                        }

                        _list.Add(_scoreData);
                    }
                    crsQuizScoreRepository.SaveChanges();

                    #region  insert Log
                    foreach(var _rInfo in _list)
                    { 
                        _rLog.QuizId = QuizId;
                        _rLog.ScoreId = _rInfo.ScoreId;
                        _rLog.AccountId = _rInfo.AccountId;
                        _rLog.SubmitId = _rInfo.SubmitId;

                        _rLog.IP = IP;                  // 使用者來源位址
                        _rLog.UserId = UserId;
                        _rLog.TheTable = "Score";       // 指定資料表
                        _rLog.BeginDate = _updateTime;  // 開始時間
                        _rLog.EndDate = DateTime.Now;   // 結束時間
                        _rLog.Behavior = 7;             // 執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6       
                        _rLog.Success = true;           // 執行成功
                        _rLog.ErrorMessage = null;      // 錯誤訊息

                        if (_rInfo.Success==true)
                            _log.ExamLog(_rLog);
                    }
                    #endregion


                    _oResult = _msg.TransformResult(true, _list);
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actView"), _msg.Get("objTranscript")));
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return _oResult;
        }
        #endregion


        #region 最終取用的成績(選擇答卷)
        /// <summary>
        /// 必要欄位：QuizId/試卷ID　||　選填欄位：StudentId/學生ID
        /// </summary>
        public ObjResult SheetPick(Guid UserId, String IP, Guid QuizId, Guid? StudentId)
        {
            ObjResult _oResult = new ObjResult();
            List<crsQuizDTO> _list = new List<crsQuizDTO>();
            try
            {
                var _quizInfo = crsQuizRepository.GetFirst(a => a.cq_QuizId == QuizId);    // 試卷資訊
                var _submits = crsQuizSubmitRepository.Get(a => a.cqs_QuizId == QuizId && a.cqs_CompleteScored == true).ToList();    // 答案卷,取已完成批閱的答案卷
                if (StudentId != null) _submits = _submits.FindAll(a => a.cqs_AccountId == StudentId).ToList();    // 特定學生的答案卷

                List<crsQuizSubmit> _sheets = new List<crsQuizSubmit>();
                int _ScoreOption = (int)_quizInfo.cq_ScoreOption;   // 0:最後一次測驗成績; 1:最高分; 2:最低分; 3:平均分數
                #region 取分
                switch (_ScoreOption)
                {
                    case 1: // 1:最高分
                        _sheets = _submits.GroupBy(p => p.cqs_AccountId, (key, group) => group.OrderByDescending(g=>g.cqs_MatchRate).First()).ToList();
                        break;
                    case 2: // 2:最低分
                        _sheets = _submits.GroupBy(p => p.cqs_AccountId, (key, group) => group.OrderBy(g => g.cqs_MatchRate).First()).ToList();
                        break;
                    case 3: // 3:平均分數
                        List<crsQuizSubmit> _students = new List<crsQuizSubmit>();
                        _students = _submits.GroupBy(p => p.cqs_AccountId, (key, group) => group.First()).ToList();
                        foreach (var _obj in _students)
                        {
                            _obj.cqs_SubmitId = _obj.cqs_AccountId; // 因為是取平均分數, 所以以考生帳號作為答卷代號
                            _obj.cqs_MatchRate = (from p in _submits where p.cqs_AccountId == _obj.cqs_AccountId select p.cqs_MatchRate.Value).Average();
                            _sheets.Add(_obj);
                        }
                        break;
                    default: // 0:最後一次測驗成績, 預設值
                        _sheets = _submits.GroupBy(p => p.cqs_AccountId, (key, group) => group.OrderByDescending(g => g.cqs_EndDate).OrderByDescending(g => g.cqs_BeginDate).First()).ToList();
                        break;
                }
                #endregion

                #region 成績
                ObjResult _rs = new ObjResult();
                crsQuizDTO _scoreData = new crsQuizDTO();
                foreach (var _sheetRecord in _sheets)
                {
                    _scoreData = new crsQuizDTO();

                    _scoreData.UserId = UserId;
                    _scoreData.Checked = 2; // 完成批閱
                    _scoreData.QuizId = _sheetRecord.cqs_QuizId;
                    _scoreData.Score = _sheetRecord.cqs_MatchRate;    // Score.cqs_Score <= Submit.cqs_MatchRate
                    _scoreData.StudentId = _sheetRecord.cqs_AccountId;

                    if (_ScoreOption != 3)
                    { // 更新試卷資訊,設定取用的試卷
                        _scoreData.IsMainSheet = true;
                        _scoreData.SubmitId = _sheetRecord.cqs_SubmitId;
                        SheetToScore(_scoreData, false);
                    }

                    _rs = StudentScore(_scoreData);
                    if (_rs.Success) _list.Add((crsQuizDTO)_rs.DataCollection);
                    else
                    {
                        _rInfo = _scoreData;
                        _rInfo.Success = false;
                        _rInfo.ErrorMessage = _rs.ErrorMessage;
                        _list.Add(_rInfo);
                    }
                }
                #endregion

                _oResult = _msg.TransformResult(true, _list);
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }


            return _oResult;
        }
        #endregion


        #region 測驗統計

        #region 應考生(小組)人數統計
        /// <summary>
        /// 應考生(小組)人數統計
        /// </summary>
        /// <param name="QuizId"></param>
        /// <returns></returns>
        public ObjResult ExamineeStatistic(Guid UserId, String IP, Guid QuizId)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                #region 宣告
                statisticQuizDTO _resultData = new statisticQuizDTO();

                var _quizInfo = crsQuizRepository.GetFirst(a => a.cq_QuizId == QuizId);    // 試卷資訊
                var _submits = crsQuizSubmitRepository.Get(a => a.cqs_QuizId == QuizId).OrderByDescending(a => a.cqs_EndDate).ToList();    // 答案卷

                int _invited = (int)_quizInfo.cq_Invited;
                var _courseInfo = CurrentState.CourseInfo((Guid)_quizInfo.cq_CourseId);     // 課程資訊
                var _assignTeamInfo = CurrentState.AssignTeamInfo((Guid)_quizInfo.cq_CourseId);     // 分組List
                #endregion

                #region 應考生
                if (_submits.Count() > 0)
                {
                    // 名單
                    _resultData.AttendantList = _submits.Select(a => a.cqs_AccountId).Distinct().ToList();        // 應考生
                    _resultData.AttendantDoneList = _submits.FindAll(a => a.cqs_EndDate != null).Select(a => a.cqs_AccountId).Distinct().ToList();    // 完成試卷應考生
                    _resultData.AttendantUndoneList = _submits.FindAll(a => a.cqs_EndDate == null).Select(a => a.cqs_AccountId).Distinct().ToList();  // 未完成試卷應考生
                    if (_resultData.AttendantDoneList != null)
                        foreach (var _AccountId in _resultData.AttendantDoneList)   // 避免重複,移除曾經完成繳卷的考生
                        _resultData.AttendantUndoneList.Remove(_AccountId);

                    // 人數
                    _resultData.AttendantCount = _resultData.AttendantList.Count();                // 應考生
                    _resultData.AttendantDoneCount = _resultData.AttendantDoneList.Count();        // 完成試卷應考生
                    _resultData.AttendantUndoneCount = _resultData.AttendantUndoneList.Count();    // 未完成試卷應考生

                    // 應考生繳卷次數
                    _resultData.SubmitCountList = (from _AccountId in _resultData.AttendantList
                                                   select new statisticSubmitDTO
                                                   {
                                                       StudentId = _AccountId,
                                                       DoneTimes = _submits.FindAll(a => a.cqs_AccountId == _AccountId && a.cqs_EndDate != null).Count,
                                                       UndoneTimes = _submits.FindAll(a => a.cqs_AccountId == _AccountId && a.cqs_EndDate == null).Count,
                                                   }).ToList();
                }
                #endregion


                #region 應到考生

                #region 依考生
                if (_invited == 0)     // 修課生
                    _resultData.RequisiteList = (from m in E35db.autRCrsStu where m.CourseId == _quizInfo.cq_CourseId && m.PositionStatus == 0 select m.StudentId).ToList();
                if (_invited == 2)  // 指定小組
                    _resultData.RequisiteList = _assignTeamInfo.FindAll(a => a.TeamId == _quizInfo.cq_GroupId).Select(a => a.AccountId).ToList();

                if (_resultData.RequisiteList != null)
                {
                    // 應到完成試卷考生/小組
                    _resultData.RequisiteDoneList = new List<Guid>();
                    if (_resultData.AttendantDoneList!=null)
                        foreach (var _AccountId in _resultData.AttendantDoneList)
                        if ((_resultData.RequisiteList.IndexOf(_AccountId) > -1) && ((_resultData.RequisiteDoneList == null) ? true : _resultData.RequisiteDoneList.IndexOf(_AccountId) < 0))
                            _resultData.RequisiteDoneList.Add(_AccountId);

                    // 應到未完成試卷考生/小組
                    _resultData.RequisiteUndoneList = new List<Guid>();
                    if (_resultData.AttendantUndoneList != null)
                        foreach (var _AccountId in _resultData.AttendantUndoneList)
                        if ((_resultData.RequisiteList.IndexOf(_AccountId) > -1) && ((_resultData.RequisiteUndoneList == null) ? true : _resultData.RequisiteUndoneList.IndexOf(_AccountId) < 0))
                            _resultData.RequisiteUndoneList.Add(_AccountId);

                    // 缺考生/小組
                    _resultData.AbsenteeList = _resultData.RequisiteList;
                    if (_resultData.AttendantList != null)
                        foreach (var _AccountId in _resultData.AttendantList)
                        if (_resultData.AbsenteeList.IndexOf(_AccountId) > -1)
                            _resultData.AbsenteeList.Remove(_AccountId);
                }
                #endregion

                #region 依分組(每組繳交一份答案卷)
                if (_invited == 1)
                {
                    // 應到考生/小組
                    _resultData.RequisiteList = _assignTeamInfo.Select(a => a.TeamId).Distinct().ToList();

                    // 應到完成試卷考生/小組
                    _resultData.RequisiteDoneList = new List<Guid>();
                    if (_resultData.AttendantDoneList != null)
                        foreach (var _AccountId in _resultData.AttendantDoneList)
                        foreach (var _TeamId in _resultData.RequisiteList)
                            if ((_assignTeamInfo.FindAll(a => a.AccountId == _AccountId && a.TeamId == _TeamId).Count > 0) && (_resultData.RequisiteDoneList.IndexOf(_TeamId) < 0))
                                _resultData.RequisiteDoneList.Add(_TeamId);

                    // 應到未完成試卷考生/小組
                    _resultData.RequisiteUndoneList = new List<Guid>();
                    if (_resultData.AttendantUndoneList != null)
                        foreach (var _AccountId in _resultData.AttendantUndoneList)
                        foreach (var _TeamId in _resultData.RequisiteList)
                            if ((_assignTeamInfo.FindAll(a => a.AccountId == _AccountId && a.TeamId == _TeamId).Count > 0) && (_resultData.RequisiteUndoneList.IndexOf(_TeamId) < 0))
                                _resultData.RequisiteUndoneList.Add(_TeamId);

                    // 缺考生/小組
                    _resultData.AbsenteeList = _resultData.RequisiteList;
                    if (_resultData.AttendantList != null)
                        foreach (var _AccountId in _resultData.AttendantList)
                        foreach (var _TeamId in _resultData.RequisiteList)
                            if ((_assignTeamInfo.FindAll(a => a.AccountId == _AccountId && a.TeamId == _TeamId).Count > 0) && (_resultData.AbsenteeList.IndexOf(_TeamId) > -1))
                                _resultData.AbsenteeList.Remove(_TeamId);

                    #region 各分組繳卷詳細紀錄
                    statisticQuizDTO _teamDetail = new statisticQuizDTO();
                    List<statisticQuizDTO> _teamDetailList = new List<statisticQuizDTO>();
                    foreach (var _TeamId in _resultData.RequisiteList)
                    {
                        _teamDetail = new statisticQuizDTO();
                        _teamDetail.TeamId = _TeamId;
                        #region 應考生
                        // 應到考生/小組
                        _teamDetail.RequisiteList = _assignTeamInfo.FindAll(a => a.TeamId == _TeamId).Select(a => a.AccountId).ToList();

                        // 應到完成試卷考生/小組
                        _teamDetail.RequisiteDoneList = new List<Guid>();
                        if (_resultData.AttendantDoneList != null)
                            foreach (var _AccountId in _resultData.AttendantDoneList)
                            if ((_teamDetail.RequisiteList.IndexOf(_AccountId) > -1) && (_teamDetail.RequisiteDoneList.IndexOf(_AccountId) < 0))
                                _teamDetail.RequisiteDoneList.Add(_AccountId);

                        // 應到未完成試卷考生/小組
                        _teamDetail.RequisiteUndoneList = new List<Guid>();
                        if (_resultData.AttendantUndoneList != null)
                            foreach (var _AccountId in _resultData.AttendantUndoneList)
                            if ((_teamDetail.RequisiteList.IndexOf(_AccountId) > -1) && (_teamDetail.RequisiteUndoneList.IndexOf(_AccountId) < 0))
                                _teamDetail.RequisiteUndoneList.Add(_AccountId);
                        // 缺考生/小組
                        _teamDetail.AbsenteeList = _teamDetail.RequisiteList;
                        if (_resultData.AttendantList != null)
                            foreach (var _AccountId in _resultData.AttendantList)
                            if (_teamDetail.AbsenteeList.IndexOf(_AccountId) > -1)
                                _teamDetail.AbsenteeList.Remove(_AccountId);
                        #endregion 應考生

                        #region 人數
                        _teamDetail.AbsenteeCount = (_teamDetail.AbsenteeList == null) ? 0 : _teamDetail.AbsenteeList.Count();              // 缺考生/小組
                        _teamDetail.RequisiteCount = (_teamDetail.RequisiteList == null) ? 0 : _teamDetail.RequisiteList.Count();            // 應到考生/小組
                        _teamDetail.RequisiteDoneCount = (_teamDetail.RequisiteDoneList == null) ? 0 : _teamDetail.RequisiteDoneList.Count();    // 應到完成試卷考生/小組
                        _teamDetail.RequisiteUndoneCount = (_teamDetail.RequisiteUndoneList == null) ? 0 : _teamDetail.RequisiteUndoneList.Count();// 應到未完成試卷考生/小組
                        #endregion

                        _teamDetailList.Add(_teamDetail);
                    }
                    _resultData.TeamDetail = _teamDetailList;
                    #endregion
                }
                #endregion

                #region 小組/人數
                _resultData.AbsenteeCount = (_resultData.AbsenteeList == null) ? 0 : _resultData.AbsenteeList.Count();              // 缺考生/小組
                _resultData.RequisiteCount = (_resultData.RequisiteList == null) ? 0 : _resultData.RequisiteList.Count();            // 應到考生/小組
                _resultData.RequisiteDoneCount = (_resultData.RequisiteDoneList == null) ? 0 : _resultData.RequisiteDoneList.Count();    // 應到完成試卷考生/小組
                _resultData.RequisiteUndoneCount = (_resultData.RequisiteUndoneList == null) ? 0 : _resultData.RequisiteUndoneList.Count();// 應到未完成試卷考生/小組
                #endregion

                #endregion


                #region 旁聽生
                _resultData.VisitList = (from m in E35db.autRCrsStu where m.CourseId == _quizInfo.cq_CourseId && m.PositionStatus == 1 select m.StudentId).ToList();

                // 名單
                if (_resultData.VisitList != null)
                {
                    // 完成試卷旁聽生
                    _resultData.VisitDoneList = new List<Guid>();
                    if (_resultData.AttendantDoneList != null)
                        foreach (var _AccountId in _resultData.AttendantDoneList)
                            if ((_resultData.VisitList.IndexOf(_AccountId) > -1) && (_resultData.VisitDoneList.IndexOf(_AccountId) < 0))
                                _resultData.VisitDoneList.Add(_AccountId);

                    // 未完成試卷旁聽生
                    _resultData.VisitUndoneList = new List<Guid>();
                    if (_resultData.AttendantUndoneList != null)
                        foreach (var _AccountId in _resultData.AttendantUndoneList)
                            if ((_resultData.VisitList.IndexOf(_AccountId) > -1) && (_resultData.VisitUndoneList.IndexOf(_AccountId) < 0))
                                _resultData.VisitUndoneList.Add(_AccountId);
                }
                // 人數
                _resultData.VisitCount = (_resultData.VisitList == null) ? 0 : _resultData.VisitList.Count();                    // 旁聽生人數	
                _resultData.VisitDoneCount = (_resultData.VisitDoneList == null) ? 0 : _resultData.VisitDoneList.Count();            // 旁聽生完成人數	
                _resultData.VisitUndoneCount = (_resultData.VisitUndoneList == null) ? 0 : _resultData.VisitUndoneList.Count();        // 旁聽生未完成人數	
                #endregion

                _oResult = _msg.TransformResult(true, _resultData);
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }


            return _oResult;
        }
        #endregion

        #region 答題統計
        /// <summary>
        /// 答題統計
        /// </summary>
        /// <param name="quizId"></param>
        /// <returns></returns>
        public ObjResult AnswerStatistic(Guid UserId, String IP, Guid QuizId, Boolean SelectMainSheet, Boolean WithoutUndoneSheet)
        {
            ObjResult _oResult = new ObjResult();
            try
            {
                #region 宣告
                List<Guid> _optionList = new List<Guid>();
                List<crsQuizDTO> _record = new List<crsQuizDTO>();
                statisticSheetDTO _data = new statisticSheetDTO();
                List<statisticSheetDTO> _resultData = new List<statisticSheetDTO>();
                statisticOptionDTO _optionData = new statisticOptionDTO();
                #endregion
                
                var _submits = crsQuizSubmitRepository.Get(a => a.cqs_QuizId == QuizId).OrderByDescending(a => a.cqs_EndDate).ToList();    // 答案卷
                if (SelectMainSheet) _submits = _submits.FindAll(a => a.cqs_IsMainSheet == true).ToList();    // 僅選取作為成績單的主要答案卷
                if (WithoutUndoneSheet) _submits = _submits.FindAll(a => a.cqs_EndDate != null).ToList();     // 僅選取有完成的答案卷

                if (_submits.Count() > 0)
                {
                    #region 答案紀錄
                    _record = (from sub in _submits
                                join ans in E4db.crsQuizSubmitAnswer on sub.cqs_SubmitId equals ans.cqsa_SubmitId
                               join pool in E4db.crsQuestionPoolDraft on ans.cqsa_PoolId equals pool.cqpd_PoolId
                                select new crsQuizDTO
                                {
                                    StudentId = sub.cqs_AccountId,      // 考生Id
                                    SubmitId = ans.cqsa_SubmitId,       // 答卷Id
                                    PoolId = ans.cqsa_PoolId,           // 試題Id
                                    Category = pool.cqpd_Category,       // 試題題型
                                    EndDate = sub.cqs_EndDate,          // 結束答題時間
                                    IsCorrect = ans.cqsa_IsCorrect,     // 答案正確
                                    Answer = ans.cqsa_Answer            // 答案
                                }).ToList();
                    #endregion

                    #region 答案統計
                    var _poolList = _record.Select(a=>a.PoolId).Distinct().ToList();
                    if (_poolList != null)
                    foreach (var _poolid in _poolList)
                    {
                        _data = new statisticSheetDTO();
                        _data.PoolId = _poolid;
                        _data.Category = _record.Find(a => a.PoolId == _poolid).Category;
                        _data.CorrectList = _record.FindAll(a => a.PoolId == _poolid && a.Answer != "" && a.Answer != null && a.IsCorrect == true).Select(a => (Guid)a.SubmitId).ToList();    // 答對者答案卷名單
                        _data.IncorrectList = _record.FindAll(a => a.PoolId == _poolid && a.Answer != "" && a.Answer != null && a.IsCorrect != true).Select(a => (Guid)a.SubmitId).ToList();  // 答錯者答案卷名單
                        _data.EmptyList = _record.FindAll(a => a.PoolId == _poolid && (a.Answer == "" || a.Answer == null)).Select(a => (Guid)a.SubmitId).ToList();  // 未答題答案卷名單
                        _data.CorrectCount = (_data.CorrectList == null) ? 0 : _data.CorrectList.Count();        // 答對答案卷數
                        _data.IncorrectCount = (_data.IncorrectList == null) ? 0 : _data.IncorrectList.Count();    // 答錯答案卷數
                        _data.EmptyCount = (_data.EmptyList == null) ? 0 : _data.EmptyList.Count();            // 未答題答案卷數

                        // 非填充/簡答的題目
                        if(_record.Find(a=>a.PoolId==_poolid).Category<4)
                        {
                            List<statisticOptionDTO> _tmp = new List<statisticOptionDTO>();
                            _optionList = crsQuestionPoolOptionRepository.Get(a => a.cqpo_PoolId==_poolid).Select(a => a.cqpo_OptionId).ToList();
                            if (_optionList!=null)
                            foreach (var _optionid in _optionList)
                            {
                                _optionData = new statisticOptionDTO();
                                _optionData.OptionId = _optionid;
                                _optionData.PickedList = _record.FindAll(a => (a.Answer == null) ? (a.StudentId == null) : a.Answer.IndexOf(_optionid.ToString()) > -1).Select(a => (Guid)a.SubmitId).ToList();    // 答對者答案卷名單
                                _optionData.PickedCount = (_optionData.PickedList == null) ? 0 : _optionData.PickedList.Count();

                                _tmp.Add(_optionData);
                            }
                            _data.Option = _tmp;
                        }

                        _resultData.Add(_data);
                    }
                    #endregion

                    _oResult = _msg.TransformResult(true, _resultData);
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotFound"), "QuizId:" + QuizId));
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }


            return _oResult;
        }
        #endregion

        #endregion


    }
}