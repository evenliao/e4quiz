﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using E4Quiz.Models;
using E4Quiz.Models.Interface;
using E4Quiz.Models.DataAnnotations;
using E4Quiz.Extensions;    // for 語言檔Toi18n();

namespace E4Quiz.Controllers
{
    public class LogManager
    {
        e4ExamEntities E4db = new e4ExamEntities();

        IRepository<logQuiz> logQuizRepository;
        IRepository<logQuizDraft> logQuizDraftRepository;

        IRepository<logQuestionPool> logQuestionPoolRepository;
        IRepository<logQuestionPoolDraft> logQuestionPoolDraftRepository;
        IRepository<logQuestionPoolOption> logQuestionPoolOptionRepository;

        IRepository<logQuizScore> logQuizScoreRepository;
        IRepository<logQuizSubmit> logQuizSubmitRepository;
        IRepository<logPublicUnitPermit> logPublicUnitPermitRepository;
        IRepository<logAttachment> logAttachmentRepository;

        public LogManager()
        {

            logQuizRepository = new E4Quiz.Models.GenericRepository<logQuiz>(E4db);
            logQuizDraftRepository = new E4Quiz.Models.GenericRepository<logQuizDraft>(E4db);

            logQuestionPoolRepository = new E4Quiz.Models.GenericRepository<logQuestionPool>(E4db);
            logQuestionPoolDraftRepository = new E4Quiz.Models.GenericRepository<logQuestionPoolDraft>(E4db);
            logQuestionPoolOptionRepository = new E4Quiz.Models.GenericRepository<logQuestionPoolOption>(E4db);

            logQuizScoreRepository = new E4Quiz.Models.GenericRepository<logQuizScore>(E4db);
            logQuizSubmitRepository = new E4Quiz.Models.GenericRepository<logQuizSubmit>(E4db);
            logPublicUnitPermitRepository = new E4Quiz.Models.GenericRepository<logPublicUnitPermit>(E4db);

            logAttachmentRepository = new E4Quiz.Models.GenericRepository<logAttachment>(E4db);
        }




        // 測驗 新增Log
        public void ExamLog(crsQuizDTO infoData)
        {
            System.Guid _logId = Guid.NewGuid();
            DateTime _beginDate = (infoData.BeginDate == null) ? DateTime.Now : (DateTime)infoData.BeginDate;
            DateTime _endDate = (infoData.EndDate == null) ? _beginDate : (DateTime)infoData.EndDate;

            //System.Guid _userId = infoData.UserId; // CurrentState.accountId;// 使用者IDRecorderId
            string _IP = (infoData.IP == null || infoData.IP == "") ? "0.0.0.0" : infoData.IP;   // CurrentState.ClientIP;     // 使用者來源位址

            switch (infoData.TheTable)
            {
                #region Quiz
                case "lq":
                case "Quiz":
                    logQuiz _quiz = new logQuiz();

                    #region 屬性對應
                    _quiz.lq_LogId = _logId;                     // 紀錄ID
                    _quiz.lq_RecorderId = infoData.UserId;         // 使用者ID
                    _quiz.lq_BeginDate = _beginDate;            // 開始時間
                    _quiz.lq_EndDate = _endDate;                // 結束時間
                    _quiz.lq_IP = _IP;                   // 使用者來源位址
                    _quiz.lq_Behavior = infoData.Behavior;       // 執行的動作, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                    _quiz.lq_CourseId = infoData.CourseId;       // 課程ID
                    _quiz.lq_Subject = infoData.Subject;         // 主題名稱
                    _quiz.lq_Comment = infoData.Comment;         // 說明
                    _quiz.lq_QuizId = infoData.QuizId;           // (新)試卷ID
                    _quiz.lq_OriginQuizId = infoData.OriginQuizId;    // 原始(來源)試卷ID
                    _quiz.lq_IsSucceed = infoData.Success;       // 執行成功
                    _quiz.lq_ErrorMsg = infoData.ErrorMessage;       // 錯誤訊息
                    #endregion 屬性對應

                    // insert data
                    logQuizRepository.Create(_quiz, true);
                    break;
                #endregion Quiz

                #region QuizDraft
                case "lqd":
                case "QuizDraft":
                    logQuizDraft _quizDraft = new logQuizDraft();

                    #region 屬性對應
                    _quizDraft.lqd_LogId = _logId;                     // 紀錄ID
                    _quizDraft.lqd_RecorderId = infoData.UserId;         // 使用者ID
                    _quizDraft.lqd_BeginDate = _beginDate;          // 開始時間
                    _quizDraft.lqd_EndDate = _endDate;                  // 結束時間
                    _quizDraft.lqd_IP = _IP;                   // 使用者來源位址
                    _quizDraft.lqd_Behavior = infoData.Behavior;       // 執行的動作, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                    _quizDraft.lqd_CourseId = infoData.CourseId;       // 課程ID
                    _quizDraft.lqd_Subject = infoData.Subject;         // 主題名稱
                    _quizDraft.lqd_Comment = infoData.Comment;         // 說明
                    _quizDraft.lqd_QuizId = infoData.QuizId;           // (新)試卷ID
                    _quizDraft.lqd_OriginQuizId = infoData.OriginQuizId;    // 原始(來源)試卷ID
                    _quizDraft.lqd_IsSucceed = infoData.Success;       // 執行成功
                    _quizDraft.lqd_ErrorMsg = infoData.ErrorMessage;       // 錯誤訊息
                    #endregion 屬性對應

                    // insert data
                    logQuizDraftRepository.Create(_quizDraft, true);
                    break;
                #endregion QuizDraft

                #region Pool
                case "lqp":
                case "Pool":
                    logQuestionPool _pool = new logQuestionPool();

                    #region 屬性對應
                    _pool.lqp_LogId = _logId;                     // 紀錄ID
                    _pool.lqp_RecorderId = infoData.UserId;         // 使用者ID
                    _pool.lqp_BeginDate = _beginDate;               // 開始時間
                    _pool.lqp_EndDate = _endDate;                  // 結束時間
                    _pool.lqp_IP = _IP;                   // 使用者來源位址
                    _pool.lqp_Behavior = infoData.Behavior;       // 執行的動作, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                    _pool.lqp_CourseId = infoData.CourseId;       // 課程ID
                    _pool.lqp_Subject = infoData.Subject;         // 主題名稱
                    _pool.lqp_Comment = infoData.Comment;         // 說明
                    _pool.lqp_PoolId = infoData.PoolId;	        // 目的(新)題庫ID
                    _pool.lqp_OriginPoolId = infoData.OriginPoolId;	// 原始(來源)題庫ID
                    _pool.lqp_IsSucceed = infoData.Success;       // 執行成功
                    _pool.lqp_ErrorMsg = infoData.ErrorMessage;       // 錯誤訊息
                    #endregion 屬性對應

                    // insert data
                    logQuestionPoolRepository.Create(_pool, true);
                    break;
                #endregion Pool

                #region PoolDraft
                case "lqpd":
                case "PoolDraft":
                    logQuestionPoolDraft _poolDraft = new logQuestionPoolDraft();

                    #region 屬性對應
                    _poolDraft.lqpd_LogId = _logId;                     // 紀錄ID
                    _poolDraft.lqpd_RecorderId = infoData.UserId;        // 使用者ID
                    _poolDraft.lqpd_BeginDate = _beginDate;             // 開始時間
                    _poolDraft.lqpd_EndDate = _endDate;                 // 結束時間
                    _poolDraft.lqpd_IP = _IP;                   // 使用者來源位址
                    _poolDraft.lqpd_Behavior = infoData.Behavior;       // 執行的動作, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                    _poolDraft.lqpd_CourseId = infoData.CourseId;       // 課程ID
                    _poolDraft.lqpd_Subject = infoData.Subject;         // 主題名稱
                    _poolDraft.lqpd_Comment = infoData.Comment;         // 說明
                    _poolDraft.lqpd_PoolId = infoData.PoolId;	        // 目的(新)題庫ID
                    _poolDraft.lqpd_OriginPoolId = infoData.OriginPoolId;	// 原始(來源)題庫ID
                    _poolDraft.lqpd_IsSucceed = infoData.Success;       // 執行成功
                    _poolDraft.lqpd_ErrorMsg = infoData.ErrorMessage;       // 錯誤訊息
                    #endregion 屬性對應

                    // insert data
                    logQuestionPoolDraftRepository.Create(_poolDraft, true);
                    break;
                #endregion PoolDraft

                #region Option
                case "lqpo":
                case "Option":
                    logQuestionPoolOption _option = new logQuestionPoolOption();

                    #region 屬性對應
                    _option.lqpo_LogId = _logId;                     // 紀錄ID
                    _option.lqpo_RecorderId = infoData.UserId;         // 使用者ID
                    _option.lqpo_BeginDate = _beginDate;            // 開始時間
                    _option.lqpo_EndDate = _endDate;                  // 結束時間
                    _option.lqpo_IP = _IP;                   // 使用者來源位址
                    _option.lqpo_Behavior = infoData.Behavior;       // 執行的動作, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                    _option.lqpo_OptionId = infoData.OptionId;       // 答案選項ID
                    _option.lqpo_PoolId = infoData.PoolId;       // 題庫ID
                    _option.lqpo_Content = infoData.Content;       // 選項內容敘述
                    _option.lqpo_IsAnswer = infoData.IsAnswer;       // 0:非答案, 1:正確答案
                    _option.lqpo_Feedback = infoData.Feedback;       // 答案回饋
                    _option.lqpo_IsSucceed = infoData.Success;       // 執行成功
                    _option.lqpo_ErrorMsg = infoData.ErrorMessage;       // 錯誤訊息
                    #endregion 屬性對應

                    // insert data
                    logQuestionPoolOptionRepository.Create(_option, true);
                    break;
                #endregion Option

                #region Score
                case "lqsc":
                case "Score":
                    logQuizScore _score = new logQuizScore();

                    #region 屬性對應
                    _score.lqs_LogId = _logId;                  // 紀錄ID
                    _score.lqs_RecorderId = infoData.UserId;     // 使用者ID
                    _score.lqs_BeginDate = _beginDate;          // 開始時間
                    _score.lqs_EndDate = _endDate;              // 結束時間
                    _score.lqs_IP = _IP;                // 使用者來源位址
                    _score.lqs_Behavior = infoData.Behavior;    // 執行的動作, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                    _score.lqs_ScoreId = infoData.ScoreId;     // 得分ID
                    _score.lqs_QuizId = infoData.QuizId;      // 試卷ID
                    _score.lqs_AccountId = infoData.AccountId;  // 考生ID
                    _score.lqs_Score = infoData.Score;       // 分數
                    _score.lqs_Checked = infoData.Checked;     // 0:自動批閱, 1:待批閱, 2:已批閱
                    _score.lqs_Criticism = infoData.Criticism;       // 評語
                    _score.lqs_GradePoint = infoData.GradePoint;      // 學分
                    _score.lqs_IsSucceed = infoData.Success;       // 執行成功
                    _score.lqs_ErrorMsg = infoData.ErrorMessage;       // 錯誤訊息
                    #endregion 屬性對應

                    // insert data
                    logQuizScoreRepository.Create(_score, true);
                    break;
                #endregion Score

                #region Submit
                case "lqsu":
                case "Submit":
                    logQuizSubmit _submit = new logQuizSubmit();

                    #region 屬性對應
                    _submit.lqs_LogId = _logId;                     // 紀錄ID
                    _submit.lqs_RecorderId = infoData.UserId;        // 使用者ID
                    _submit.lqs_BeginDate = _beginDate;             // 開始時間
                    _submit.lqs_EndDate = _endDate;                 // 結束時間
                    _submit.lqs_IP = _IP;                   // 使用者來源位址
                    _submit.lqs_Behavior = infoData.Behavior;       // 執行的動作, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
                    _submit.lqs_SubmitId = infoData.SubmitId;    //	得分ID
                    _submit.lqs_QuizId = infoData.QuizId;          //	試卷ID
                    _submit.lqs_MatchRate = infoData.MatchRate;   //	成績
                    _submit.lqs_ExtraScore = infoData.ExtraScore;  //	額外調分
                    _submit.lqs_IsMainSheet = infoData.IsMainSheet; //	1:主要成績的答案卷; 0:非取用的答案卷
                    _submit.lqs_PoolId = infoData.PoolId;          //	試題ID
                    _submit.lqs_Answer = infoData.Answer;          //	答案內容
                    _submit.lqs_IsCorrect = infoData.IsCorrect;   //	1:答案正確; 0:錯誤
                    _submit.lqs_IsSucceed = infoData.Success;       // 執行成功
                    _submit.lqs_ErrorMsg = infoData.ErrorMessage;       // 錯誤訊息
                    #endregion 屬性對應

                    // insert data
                    logQuizSubmitRepository.Create(_submit, true);
                    break;
                #endregion Submit

                #region Permit
                case "lpup":
                case "Permit":
                    logPublicUnitPermit _permit = new logPublicUnitPermit();

                    #region 屬性對應
                    _permit.lpup_LogId = _logId;                     // 紀錄ID	
                    _permit.lpup_RecorderId = infoData.UserId;        // 使用者ID	
                    _permit.lpup_BeginDate = _beginDate;             // 開始時間	
                    _permit.lpup_EndDate = _endDate;                 // 結束時間	
                    _permit.lpup_IP = _IP;                   // 使用者來源位址	
                    _permit.lpup_Behavior = infoData.Behavior;       // 執行的動作,清單=0,檢視=1,新增=2,更新=3,刪除=4,鎖定=5,複本=6	
                    _permit.lpup_UnitId = infoData.UnitId;           // 活動ID(題庫ID/試卷ID)	
                    _permit.lpup_KeyId = infoData.KeyId;             // 獲權者ID(個人/課程Id/小組Id)	
                    _permit.lpup_KeyType = infoData.KeyType;         // KyeId類型(0:個人,1:課程,2:小組)	
                    _permit.lpup_Permit = infoData.Permit;           // 檢示|新增|刪除|修改;    0:無權,1:有權
                    _permit.lpup_IsSucceed = infoData.Success;       // 執行成功	
                    _permit.lpup_ErrorMsg = infoData.ErrorMessage;       // 錯誤訊息						
                    #endregion 屬性對應

                    // insert data
                    logPublicUnitPermitRepository.Create(_permit, true);
                    break;
                #endregion Permit

                #region Attachment
                case "la":
                case "Attachment":
                    logAttachment _attachment = new logAttachment();

                    #region 屬性對應
                    _attachment.la_LogId = _logId;                     // 紀錄ID	
                    _attachment.la_RecorderId = infoData.UserId;        // 使用者ID	
                    _attachment.la_BeginDate = _beginDate;             // 開始時間	
                    _attachment.la_EndDate = _endDate;                 // 結束時間	
                    _attachment.la_IP = _IP;                   // 使用者來源位址	
                    _attachment.la_Behavior = infoData.Behavior;       // 執行的動作,清單=0,檢視=1,新增=2,更新=3,刪除=4,鎖定=5,複本=6	

                    _attachment.la_FileId = infoData.FileId;     //  附件ID
                    _attachment.la_PackId = infoData.PackId;     //  同捆ID,上傳檔案後得到的ID
                    _attachment.la_BelongId = infoData.BelongId;   //  來源ID(題目ID/答案ID)
                    _attachment.la_Name = infoData.Name;            //  附加檔案名稱
                    _attachment.la_Location = infoData.Location;                           //  檔案位置
                    _attachment.la_IsSucceed = infoData.Success;       // 執行成功	
                    _attachment.la_ErrorMsg = infoData.ErrorMessage;       // 錯誤訊息						
                    #endregion 屬性對應

                    // insert data
                    logAttachmentRepository.Create(_attachment, true);
                    break;
                #endregion Attachment

            }
        }


    }
}