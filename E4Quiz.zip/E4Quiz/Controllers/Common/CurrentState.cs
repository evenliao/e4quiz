﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using ECampus.Common;
using ECampus.Models;
using E4Quiz.Models.DataAnnotations;

namespace E4Quiz.Controllers
{
    /// <summary>
    /// 儲存目前工作階段資訊
    /// </summary>
    public class CurrentState
    {

        //20140827 - Create by Glen

        #region 取得或設定目前工作階段的使用者識別碼 - accountId 20140827 by Glen
        /// <summary>
        /// 取得或設定目前工作階段的使用者識別碼，00000000-0000-0000-0000-000000000000表示並未設定
        /// </summary>
        public static Guid accountId
        {
            get
            {
                //HttpCookie cookie = this.Request.Cookies[FormsAuthentication.FormsCookieName];
                Guid _accountId = Guid.Empty;
                if (HttpContext.Current.Session["CurrentStatue_AccountId"] != null)
                {
                    _accountId = new Guid(HttpContext.Current.Session["CurrentStatue_AccountId"].ToString());
                }
                else if (HttpContext.Current != null)
                {
                    HttpCookie _cookie = HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName];
                    if (_cookie != null)
                    {
                        FormsAuthenticationTicket oldTicket = FormsAuthentication.Decrypt(_cookie.Value);
                        if (!oldTicket.Expired) _accountId = new Guid(oldTicket.Name);
                    }
                }

                return _accountId;
            }
            set
            {
                HttpContext.Current.Session["CurrentStatue_AccountId"] = value;
            }
        }
        #endregion

        #region 取得或設定目前工作階段的課程識別碼 - courseId 20140827 by Glen
        /// <summary>
        /// 取得或設定目前工作階段的課程識別碼，00000000-0000-0000-0000-000000000000表示並未設定
        /// </summary>
        public static Guid courseId
        {
            get
            {
                //HttpCookie cookie = this.Request.Cookies[FormsAuthentication.FormsCookieName];
                Guid _courseId = Guid.Empty;
                if (HttpContext.Current.Session["CurrentStatue_CourseId"] != null)
                {
                    _courseId = new Guid(HttpContext.Current.Session["CurrentStatue_CourseId"].ToString());
                }
                return _courseId;
            }
            set
            {
                HttpContext.Current.Session["CurrentStatue_CourseId"] = value;
            }
        }
        #endregion


        #region 取得客戶端真實IP Address - GetClientIP 20141111 by Even
        /// <summary>
        /// 取得客戶端真實IP Address
        /// </summary>
        public static string ClientIP
        {
            get
            {
                HttpRequest _httpInfo = HttpContext.Current.Request;
                string _ip;

                //判所client端是否有設定代理伺服器
                if (_httpInfo.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
                    _ip = _httpInfo.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
                else if (_httpInfo.ServerVariables["HTTP_VIA"] != null)
                    _ip = _httpInfo.ServerVariables["HTTP_VIA"].ToString();
                else
                    _ip = _httpInfo.ServerVariables["REMOTE_ADDR"].ToString();

                if (_ip.IndexOf(",") > 0)
                    _ip = _ip.Substring(1, _ip.IndexOf(",") - 1);

                else if (_ip.IndexOf(";") > 0)
                    _ip = _ip.Substring(1, _ip.IndexOf(";") - 1);

                return _ip.Replace(" ", string.Empty);
            }
            set
            {
                HttpContext.Current.Session["CurrentStatue_ClientIP"] = value;
            }
        }
        #endregion



        #region 取得使用者資訊 - UserInfo(Guid userId) 20141111 by Even
        /// <summary>
        /// 取得使用者資訊
        /// </summary>
        public static userInfoDTO UserInfo(Guid userId)
        {
            e3PDB3Entities E35db = new e3PDB3Entities();
            var _info = (from p in E35db.autAccountInfo
                         join dept in E35db.orgDepartment
                        on p.DepartId equals dept.DepartId
                        where p.AccountId == userId
                         select new userInfoDTO
                        {
                            AccountId = p.AccountId,	// 帳號識別碼
                            Account = p.Account,		// 系統登入帳號
                            AccountStatus = p.AccountStatus,	// 狀態(停用:0,啟用:1,審核中:2,確認eMail:3)
                            Name = p.Name,				// 姓名

                            OfficeLab = p.OfficeLab,	// 辦公室/研究室
                            EMail = p.EMail,			// Email
                            Introduce = p.Introduce,	// 自我介紹
                            NickName = p.NickName,		// 暱稱
                            Url = p.Url,		// 個人網頁網址 
                            Tel = p.Tel,		// 電話 
                            Mobile = p.Mobile,	// 手機 

                            Password = p.Password,		// 系統登入密碼
                            CmsSrvId = (Guid)p.CmsSrvId,		// 內容伺服器識別碼

                            Dep_zhTW = dept.zhTWName,	// 部門中文名稱 (繁體)
                            Dep_enUS = dept.enUSName	// 部門英文名稱

                        }).FirstOrDefault();

            return _info;
        }
        #endregion 取得使用者資訊


        #region 取得課程資訊 - CourseInfo(Guid CourseId) 20141111 by Even
        /// <summary>
        /// 取得課程資訊
        /// </summary>
        public static courseInfoDTO CourseInfo(Guid CourseId)
        {
            e3PDB3Entities E35db = new e3PDB3Entities();
            var _info = (from p in E35db.crsCourse
                         where p.CourseId == CourseId
                         select new courseInfoDTO
                         {
                             CourseId = p.CourseId,   // 課程識別碼
                             PmtCrsId = (Guid)p.PmtCrsId,   // 所屬永久課程識別碼
                             CourseNo = p.CourseNo,   // 當期課號(課程代碼)
                             IsPrepare = p.IsPrepare,   // 是否設為臨時課號(是臨時課號:0,不是臨時課號:0)

                             zhTWName = p.zhTWName,   // 中文名稱 (繁體)
                             zhCNName = p.zhCNName,   // 中文名稱 (簡體)
                             enUSName = p.enUSName,   // 英文名稱

                             CrsYear = p.CrsYear,   // 開課學年
                             CrsSemester = p.CrsSemester,   // 開課學期(上學期:1,下學期:2,暑修:9)
                             BeginDate = p.BeginDate,   // 課程開啟時間  [NULL 代表依學年/學期行事曆] [若學年/學期行事曆無資料, 則課程永久有效]
                             EndDate = p.EndDate,   // 課程結束時間 [NULL 代表依學年/學期行事曆] [若學年/學期行事曆無資料, 則課程永久有效]
                             IsForever = p.IsForever,   // 永久課程(1:是永久課程,0:不是永久課程)

                             CrsNumber = (from m in E35db.autRCrsStu where m.CourseId == CourseId && m.PositionStatus == 0 select m.StudentId).Count(), // 修課生人數	
                             VisitNumber = (from m in E35db.autRCrsStu where m.CourseId == CourseId && m.PositionStatus == 1 select m.StudentId).Count(), // 旁聽生人數	
                         }).FirstOrDefault();

            return _info;
        }
        #endregion


        #region 取得小組資訊 - TeamInfo(Guid TeamId) 20141111 by Even
        /// <summary>
        /// 取得分組資訊
        /// </summary>
        public static teamInfoDTO TeamInfo(Guid TeamId)
        {
            e3PDB3Entities E35db = new e3PDB3Entities();
            var _info = (from p in E35db.crsTeam
                         where p.TeamId == TeamId
                         select new teamInfoDTO
                         {
                            TeamId = p.TeamId ,		// 小組識別碼	
                            TeamName = p.TeamName ,		// 小組名稱	
                            OrderIndex = p.OrderIndex ,		// 清單預設排列順序	
                            CourseId = p.CourseId ,		// 課程識別碼	
                            TeamLeader = (Guid)p.TeamLeader ,		// 帳號識別碼--小組長	
                            TreeNodeId = p.TreeNodeId ,		// 課程結構(樹狀結構) 識別碼, 活動代碼	
                            IsTeamSetGroup = p.IsTeamSetGroup ,		// 是否課程分組設定來的	(0)
                            TeamNumber = (from m in E35db.crsTeamMember where m.TeamId == TeamId select m.AccountId).Count() // 實際小組人數	
                         }).FirstOrDefault();

            return _info;
        }
        #endregion


        #region 取得課程分組資訊 - AssignTeamInfo(Guid CourseId) 20141111 by Even
        /// <summary>
        /// 取得分組資訊
        /// </summary>
        public static List<assignTeamDTO> AssignTeamInfo(Guid CourseId)
        {
            e3PDB3Entities E35db = new e3PDB3Entities();
            List<assignTeamDTO> _info = (from p in E35db.crsCourseTree  // 課程活動(樹狀結構)資訊
                                         join t in E35db.crsTeam on p.TreeNodeId equals t.TreeNodeId   // 小組資訊
                                         join tm in E35db.crsTeamMember on t.TeamId equals tm.TeamId     // 小組成員
                                         where p.CourseId == CourseId
                                         select new assignTeamDTO
                                         {
                                             CourseId = p.CourseId,		// 課程識別碼	
                                             AccountId = tm.AccountId,	// 帳號識別碼
                                             TeamId = t.TeamId,		    // 小組識別碼	
                                             TeamName = t.TeamName,	    // 小組名稱	
                                             IsLeader = (t.TeamLeader == tm.AccountId), // 為小組長	
                                         }).ToList();

            return _info;
        }
        #endregion




    }
}