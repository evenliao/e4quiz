﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Runtime.Serialization;
using System.IO;
using System.Drawing;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using E4Quiz.Models;
using E4Quiz.Models.Interface;
using E4Quiz.Models.DataAnnotations;
using ECampus;
using ECampus.Common;
using ECampus.Models;
using E4Quiz.Extensions;    // for 語言檔Toi18n();

namespace E4Quiz.Controllers
{
    public class AttachmentController : Controller
    {
        #region 宣告
        Quiz _quiz;

        ObjResult _oResult = new ObjResult();

        CustomBasicUnit _msg = new CustomBasicUnit();   // 訊息語言檔   
        Guid _userId = new Guid();
        autAccountInfoDTO _userInfo = new autAccountInfoDTO();  // 帳戶資訊

        #endregion 宣告
        
        public AttachmentController()
        {
            _quiz = new Quiz();

            //// 取得使用者資訊
            //_userId = new Guid("31e69c54-a7f8-4f7b-a94c-0003febad828");   // CurrentState.accountId;
            //_userInfo = CurrentState.UserInfo(_userId);
        }


        #region 附加檔案清單
        [HttpPost]
        public JsonResult ListAttachment(Guid UserId, String IP, Guid BelongId, bool? IsDeleted)
        {
            try
            {
                if ((BelongId == null) || (BelongId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "BelongId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _quiz.AttachmentList(BelongId, IsDeleted);

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString())); // Error !\r\n xxxxxx
            }

            return Json(_oResult);
        }
        #endregion 附加檔案清單


        #region 附加檔案資訊
        [HttpPost]
        public JsonResult InfoAttachment(Guid UserId, String IP, Guid BelongId, Guid FileId)
        {
            try
            {
                if ((BelongId == null) || (BelongId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "BelongId")); // xxxxx is null or unsuitable !
                else if ((FileId == null) || (FileId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "FileId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _quiz.AttachmentInfo(FileId, BelongId);

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString())); // Error !\r\n xxxxxx
            }

            return Json(_oResult);
        }
        #endregion 附加檔案資訊


        #region 建立附加檔案資訊
        [HttpPost]
        public JsonResult CreateAttachment(crsQuizDTO material)
        {
            try
            {
                material.UserId = _userId;
                if ((material.BelongId == null) || (material.BelongId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "BelongId")); // xxxxx is null or unsuitable !
                else if ((material.Name == null) || (material.Name.Trim() == ""))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "File Name")); // xxxxx is null or unsuitable !
                else if ((material.Location == null) || (material.Location.Trim() == ""))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "File path")); // xxxxx is null or unsuitable !
                else
                    _oResult = _quiz.AttachmentCreate(material);

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString())); // Error !\r\n xxxxxx
            }

            return Json(_oResult);
        }
        #endregion 建立附加檔案資訊


        #region 修改附加檔案資訊 (刪除:IsDeleted=true)
        [HttpPost]
        public JsonResult UpdateAttachment(crsQuizDTO material)
        {
            try
            {
                material.UserId = _userId;
                if ((material.BelongId == null) || (material.BelongId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "BelongId")); // xxxxx is null or unsuitable !
                else if ((material.FileId == null) || (material.FileId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "FileId")); // xxxxx is null or unsuitable !
                else if (((material.Name == null) || (material.Name.Trim() == "")) &&
                    ((material.Location == null) || (material.Location.Trim() == "")) && (material.IsDeleted == null))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNotChanged"), material.FileId.ToString())); // Nothings have been changed !\r\n xxxxxx
                else
                    _oResult = _quiz.AttachmentUpdate(material);

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString())); // Error !\r\n xxxxxx
            }

            return Json(_oResult);
        }
        #endregion 修改附加檔案資訊



    }
}