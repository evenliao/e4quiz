﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Runtime.Serialization;
using System.IO;
using System.Drawing;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using E4Quiz.Models;
using E4Quiz.Models.Interface;
using E4Quiz.Models.DataAnnotations;
using ECampus;
using ECampus.Common;
using ECampus.Models;
using E4Quiz.Extensions;    // for 語言檔Toi18n();

namespace E4Quiz.Controllers
{
    public class QuestionPoolController : Controller
    {
        #region 宣告
        Quiz _quiz;

        ObjResult _oResult = new ObjResult();

        //Guid _userId = new Guid();
        autAccountInfoDTO _userInfo = new autAccountInfoDTO();  // 帳戶資訊

        //Guid _courseId = new Guid();
        courseInfoDTO _courseInfo = new courseInfoDTO();

        CustomBasicUnit _msg = new CustomBasicUnit();   // 訊息語言檔   
        #endregion 宣告

        public QuestionPoolController()
        {
            _quiz = new Quiz();

            // 取得使用者資訊
            //_userId = new Guid("50229a7a-602e-4a4f-8e2a-25c1a8b1d59f"); // CurrentState.accountId;   // new Guid("31e69c54-a7f8-4f7b-a94c-0003febad828"); 
            //_userInfo = CurrentState.UserInfo(_userId);

            //// 取得課程資訊
            //_courseId = new Guid("84BD76C1-F55E-46C2-95EA-A3E4D08F248E"); // CurrentState.courseId;   // new Guid("84BD76C1-F55E-46C2-95EA-A3E4D08F248E");
            //_courseInfo = CurrentState.CourseInfo(_courseId);
        }


        #region 鎖住資料
        [HttpPost]
        public ObjResult LockRecord(crsQuizDTO Material)
        {
            ObjResult _result = new ObjResult();
            try
            {
                if ((Material.PoolId == null) || (Material.PoolId.ToString().Substring(0, 8) == "00000000"))
                    _result = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId")); // xxxxx is null or unsuitable !
                else if (Material.TheTable == null)
                    _result = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "TheTable"));
                else if (Material.Locked == null)
                    _result = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "Locked"));
                else
                    _result = _quiz.Lock(Material);

            }
            catch (Exception ex)
            {
                _result = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString())); // Error !\r\n xxxxxx
            }

            return _result;
        }
        #endregion


        #region 檢驗是否已鎖住試題
        [HttpPost]
        public ObjResult CheckLocked(Guid UserId, String IP, Guid PoolId, Int32 Behavior = 1)
        {
            ObjResult _result = new ObjResult();
            try
            {
                _result = _quiz.PoolDraftGet(UserId, IP, PoolId, Behavior);

                if (_result.Success)
                {
                    crsQuizDTO _record = (crsQuizDTO)_result.DataCollection;
                    if (_record.Locked == false || _record.LockedUser == UserId)
                        _result = _msg.TransformResult(true, _msg.Get("msgSucceed"));
                    else // 已被其他人鎖定
                        _result = _msg.TransformResult(false, _record.LockedRemark);
                }

            }
            catch (Exception ex)
            {
                if ((PoolId == null) || (PoolId.ToString().Substring(0, 8) == "00000000")) // 試題號碼異常
                    _result = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId")); // xxxxx is null or unsuitable !
                else // 其他異常
                    _result = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return _result;
        }
        #endregion


        #region 試題草稿清單
        [HttpPost]
        public JsonResult ListPoolDraft(crsQuizDTO Material, Boolean IsCourseId = false, Int32 SkipAmount = 0, Int32 GetAmount = 0)
        {
            try
            {
                // isCourseId=true 選擇該課號所有草稿清單, 否則選擇該使用者所有草稿清單
                if ((IsCourseId == true) && ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))) // 課號異常
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _quiz.PoolDraftList(Material.UserId, Material.IP, IsCourseId, Material.CourseId, SkipAmount, GetAmount, true);

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >=0))
                    _oResult = _msg.TransformResult(true, null);

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion 試題草稿清單


        #region 顯示試題草稿內容
        [HttpPost]
        public JsonResult ViewPoolDraft(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.PoolId == null) || (Material.PoolId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId")); // xxxxx is null or unsuitable !
                else // ViewPoolDraft時display = true, 顯示該資料, 但不可修改僅可複製
                    _oResult = _quiz.PoolDraftGet(Material.UserId, Material.IP, Material.PoolId, 1, true);

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                    _oResult = _msg.TransformResult(true, null);

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 取得試題草稿內容,會鎖定草稿
        [HttpPost]
        public JsonResult GetPoolDraft(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.PoolId == null) || (Material.PoolId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _quiz.PoolDraftGet(Material.UserId, Material.IP, Material.PoolId, 1);

                    if (_oResult.Success)
                    {
                        // 鎖定資料
                        _userInfo = CurrentState.UserInfo(Material.UserId).FirstOrDefault();
                        crsQuizDTO _info = new crsQuizDTO();
                        _info.IP = Material.IP;
                        _info.PoolId = Material.PoolId;
                        _info.Locked = true;
                        _info.TheTable = "PoolDraft";
                        _info.LockedUser = Material.UserId;
                        _info.LockedRemark = (String.Format(_msg.Get("msgEditing"), _userInfo.Dep_zhTW + "(" + _userInfo.Dep_enUS + ")" + " " + _userInfo.Name)); ;
                        var _temp = LockRecord(_info);

                        if (_temp.Success == false)
                            _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgLockFailed"), Material.PoolId)); // {0} Lock is failed !
                    }

                    // 空值回傳 true
                    if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                        _oResult = _msg.TransformResult(true, null);
                
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 建立試題草稿
        [HttpPost]
        public JsonResult CreatePoolDraft(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else
                {
                    // 判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);
                    if (_coursePermissions.Quiz)
                    {
                        //material.UserId = _userId;
                        _oResult = _quiz.PoolDraftCreate(Material);

                        if (_oResult.Success)
                        {
                            // 鎖定資料
                            _userInfo = CurrentState.UserInfo(Material.UserId).FirstOrDefault();
                            crsQuizDTO _info = new crsQuizDTO();
                            _info.IP = Material.IP;
                            _info.PoolId = Material.PoolId;
                            _info.Locked = true;
                            _info.TheTable = "PoolDraft";
                            _info.LockedUser = Material.UserId;
                            _info.LockedRemark = (String.Format(_msg.Get("msgEditing"), _userInfo.Dep_zhTW + "(" + _userInfo.Dep_enUS + ")" + " " + _userInfo.Name)); ;
                            LockRecord(_info);  // 鎖住資料
                        }
                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actAdd"), _msg.Get("objQuestion")));
                }

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 引用試題為草稿
        [HttpPost]
        public JsonResult CopyPoolDraft(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else if ((Material.PoolId == null) || (Material.PoolId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId")); // xxxxx is null or unsuitable !
                else
                {
                    // 判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);
                    if (_coursePermissions.Quiz)
                    {
                        _oResult = _quiz.PoolDraftRecreate(Material.UserId, Material.IP, Material.PoolId);

                        if (_oResult.Success)
                        {
                            crsQuizDTO _poolDraft = (crsQuizDTO)((object)_oResult.DataCollection);

                            // 鎖定資料
                            _userInfo = CurrentState.UserInfo(Material.UserId).FirstOrDefault();
                            crsQuizDTO _info = new crsQuizDTO();
                            _info.IP = Material.IP;
                            _info.QuizId = (Guid)_poolDraft.PoolId;
                            _info.Locked = true;
                            _info.TheTable = "PoolDraft";
                            _info.LockedUser = Material.UserId;
                            _info.LockedRemark = (String.Format(_msg.Get("msgEditing"), _userInfo.Dep_zhTW + "(" + _userInfo.Dep_enUS + ")" + " " + _userInfo.Name)); ;
                            LockRecord(_info);  // 鎖住資料
                        }

                        // 空值回傳 true
                        if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                            _oResult = _msg.TransformResult(true, null);
                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actCopy"), _msg.Get("objQuestion")));
                }

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 修改/刪除 試題草稿
        [HttpPost]
        public JsonResult UpdateDelPoolDraft(crsQuizDTO Material, Boolean IsDelete = false)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.PoolId == null) || (Material.PoolId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId")); // xxxxx is null or unsuitable !
                else
                {
                    // 檢查是否已鎖定並可異動資料
                    _oResult = CheckLocked(Material.UserId, Material.IP, Material.PoolId, (IsDelete == true) ? 4 : 3);
                    if (_oResult.Success)
                    {
                        GetPoolDraft(Material);
                        _oResult = (IsDelete == true) ? _quiz.PoolDraftDelete(Material.UserId, Material.IP, Material.PoolId) : _quiz.PoolDraftUpdate(Material); // 刪除或修改
                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), (IsDelete == true) ? _msg.Get("actDel") : _msg.Get("actUpdate"), _msg.Get("objQuestion")));

                    // 空值回傳 true
                    if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                        _oResult = _msg.TransformResult(true, null);
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 試題清單
        [HttpPost]
        public JsonResult ListPool(crsQuizDTO Material, Boolean IsCourseId = false, Boolean IsDeleted = false, Int32 SkipAmount = 0, Int32 GetAmount = 0)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((IsCourseId == true) && ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000")))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else            // 該使用者的試卷
                    _oResult = _quiz.PoolRecords(Material.UserId, Material.IP, IsDeleted, IsCourseId, Material.CourseId, SkipAmount, GetAmount, true);

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                    _oResult = _msg.TransformResult(true, null);

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion 試卷清單


        #region 建立試題
        [HttpPost]
        public JsonResult CreatePool(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    return Json(_msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId"))); // xxxxx is null or unsuitable !
                else if ((Material.PoolId == null) || (Material.PoolId.ToString().Substring(0, 8) == "00000000"))
                    return Json(_msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId"))); // xxxxx is null or unsuitable !
                else
                {
                    _oResult = _quiz.PoolPublish(Material.UserId, Material.IP, Material.PoolId);

                    if (_oResult.Success)
                    {
                        // 鎖定資料
                        crsQuizDTO _info = new crsQuizDTO();
                        _info.IP = Material.IP;
                        _info.PoolId = Material.PoolId;
                        _info.Locked = true;
                        _info.TheTable = "PoolDraft";
                        _info.LockedUser = Material.UserId;
                        _info.LockedRemark = (String.Format(_msg.Get("msgPosted"), "'" + ((crsQuizDTO)_oResult.DataCollection).Subject + "'")); ;
                        var _temp = LockRecord(_info);

                        if (_temp.Success) UpdateDelPoolDraft(Material, true);  // 刪除草稿
                        else _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgLockFailed"), Material.QuizId)); // {0} Lock is failed !
                    }

                    // 空值回傳 true
                    if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                        _oResult = _msg.TransformResult(true, null);

                }

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 修改/刪除 試題
        [HttpPost]
        public JsonResult UpdateDelPool(crsQuizDTO Material, Boolean IsDelete = false)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.PoolId == null) || (Material.PoolId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId")); // xxxxx is null or unsuitable !
                else
                {
                    if (Material.QuizId == null) 
                        Material.QuizId = new Guid("00000000-0000-0000-0000-000000000000");

                    // 檢查是否使用中(考試中)並可異動資料
                    _oResult = _quiz.PoolGetProcess(Material);
                    if (_oResult.Success==false)
                    {
                        _oResult = _quiz.PoolDraftRecreate(Material.UserId, Material.IP, Material.PoolId);  // 引用試題
                        if (_oResult.Success)
                        {
                            crsQuizDTO _newPool = (crsQuizDTO)_oResult.DataCollection;
                            _oResult = _quiz.PoolPublish(Material.UserId, Material.IP, _newPool.PoolId);    // 發布新試題

                            // 試卷替換新試題代號
                            if ((Material.QuestionId != null) && (Material.QuestionId.ToString().Substring(0, 8) != "00000000"))
                                _oResult = _quiz.QuestionReplace(Material, _newPool.PoolId);

                            Material.PoolId = _newPool.PoolId;
                        }
                    }

                    if (_oResult.Success)
                    {
                        if (IsDelete == true) Material.IsDeleted = true; // 刪除或修改
                        _oResult = _quiz.PoolRevise(Material);
                    }

                    // 空值回傳 true
                    if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                        _oResult = _msg.TransformResult(true, null);
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion        


        #region 取得試題內容
        [HttpPost]
        public JsonResult ViewPool(Guid UserId, String IP, Guid PoolId)
        {
            try
            {
                _oResult = _quiz.PoolAcquire(UserId, IP, PoolId);

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                    _oResult = _msg.TransformResult(true, null);

            }
            catch (Exception ex)
            {
                if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((PoolId == null) || (PoolId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 試題答案項清單
        [HttpPost]
        public JsonResult ListOption(crsQuizDTO Material, Boolean IsRandom = false, Int32 SkipAmount = 0, Int32 GetAmount = 0)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId"));
                else if ((Material.PoolId == null) || (Material.PoolId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId"));

                else
                {
                    _oResult = _quiz.OptionList(Material.UserId, Material.IP, Material.PoolId, IsRandom, SkipAmount, GetAmount);

                    // 空值回傳 true
                    if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                        _oResult = _msg.TransformResult(true, null);

                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion 


        #region 新增答案項
        [HttpPost]
        public JsonResult CreateOption(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.PoolId == null) || (Material.PoolId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId")); // xxxxx is null or unsuitable !
                else
                {
                    // 檢查是否已鎖定並可異動資料
                    _oResult = CheckLocked(Material.UserId, Material.IP, Material.PoolId, 3);
                    if (_oResult.Success)
                        _oResult = _quiz.OptionAdd(Material);

                    // 空值回傳 true
                    if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                        _oResult = _msg.TransformResult(true, null);

                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 修改/刪除 試題答案項
        [HttpPost]
        public JsonResult UpdateDelOption(crsQuizDTO Material, Boolean IsDelete = false)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.PoolId == null) || (Material.PoolId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId")); // xxxxx is null or unsuitable !
                else if ((Material.OptionId == null) || (Material.OptionId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "OptionId")); // xxxxx is null or unsuitable !
                else
                {
                    // 檢查是否已鎖定並可異動資料
                    _oResult = CheckLocked(Material.UserId, Material.IP, Material.PoolId, 3);
                    if (_oResult.Success)
                        _oResult = (IsDelete == true) ? _quiz.OptionDel(Material) : _quiz.OptionUpdate(Material); // 刪除或修改
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), (IsDelete == true) ? _msg.Get("actDel") : _msg.Get("actUpdate"), _msg.Get("objQuestion")));

                    // 空值回傳 true
                    if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                        _oResult = _msg.TransformResult(true, null);

                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 搜尋題庫
        [HttpPost]
        public JsonResult SearchPool(crsQuizDTO Material, String Key = null, Int32 SkipAmount = 0, Int32 GetAmount = 0)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Key == null) && (Material.Difficult == null) && (Material.Category == null) && (Material.Difficult == -1) && (Material.Category == -1) && (Material.Topic == null) && (Material.Unit == null))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), _msg.Get("objSearch") + _msg.Get("objCondition")));
                else
                {
                    _oResult = _quiz.PoolSearch(Material, Key, SkipAmount, GetAmount, true);

                    // 空值回傳 true
                    if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                        _oResult = _msg.TransformResult(true, null);

                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 雜項 -- 忽略
        //
        // GET: /QuestionPool/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AddOuestion()
        {
            if (Request.Form.Count > 0)
            {
                string Category = Request["Category"];
                string CourseId = Request["CourseId"];
                string Subject = Request["Subject"];
                string Answer_1 = Request["Answer_1"];
                int Grade_p = Int32.Parse(Request["Grade_p"]);
                int Grade_m = Int32.Parse(Request["Grade_m"]);
                int Difficult = Int32.Parse(Request["Difficult"]);
                string Comment = Request["Comment"];
                string AttFiles = Request["AttFiles"];

            }

            return View();
        }
        public ActionResult SearchQuestionPool()
        {

            return View();
        }
        public ActionResult AttFiles()
        {

            return View();
        }

        #endregion


    }
}