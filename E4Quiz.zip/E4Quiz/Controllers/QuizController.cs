﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Runtime.Serialization;
using System.IO;
using System.Drawing;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using E4Quiz.Models;
using E4Quiz.Models.Interface;
using E4Quiz.Models.DataAnnotations;
using ECampus;
using ECampus.Common;
using ECampus.Models;
using E4Quiz.Extensions;    // for 語言檔Toi18n();


namespace E4Quiz.Controllers
{
    public class QuizV2Controller : Controller
    {
        #region 宣告
        Quiz _quiz;

        //Guid _userId = new Guid();
        PermitController _permit = new PermitController();
        autAccountInfoDTO _userInfo = new autAccountInfoDTO();

        List<crsQuizDTO> _list = new List<crsQuizDTO>();

        //Guid _courseId = new Guid();
        courseInfoDTO _courseInfo = new courseInfoDTO();

        crsQuizDTO _record = new crsQuizDTO();
        CustomBasicUnit _msg = new CustomBasicUnit();   // 訊息語言檔   

        ObjResult _oResult = new ObjResult();

        #endregion 宣告

        public QuizV2Controller()
        {
            _quiz = new Quiz();
            _permit = new PermitController();

            // 取得使用者資訊
            //_userId = new Guid("bbd7dbcd-d325-41a0-8a54-1ffab550ff72"); // CurrentState.accountId;   // new Guid("50229a7a-602e-4a4f-8e2a-25c1a8b1d59f");
            //_userInfo = CurrentState.UserInfo(_userId);

            // 取得課程資訊
            //_courseId = new Guid("7357e3d5-6385-48d8-8aec-f50edbb026c5"); // CurrentState.courseId;   // new Guid("84BD76C1-F55E-46C2-95EA-A3E4D08F248E");
            //_courseInfo = CurrentState.CourseInfo(_courseId);

        }

       
        // GET: Quiz/Create
        public ActionResult QuizCreate()
        {            
            return View();
        }

        public String test(String var, String remark, Boolean forHTML)
        {
            return _msg.cbuGet(var).xName + _msg.cbuGet(var).xValue + _msg.cbuGet(var).xComment;
        }

        public JsonResult testEEE(String info)
        {
            //Guid _CourseId = new Guid("84BD76C1-F55E-46C2-95EA-A3E4D08F248E");  // e3測試課程:7357e3d5-6385-48d8-8aec-f50edbb026c5
            ////Guid _accountId = new Guid("50229a7a-602e-4a4f-8e2a-25c1a8b1d59f"); // e3測試課程-教師:bbd7dbcd-d325-41a0-8a54-1ffab550ff72

            //if (((CurrentState.accountId == null) || (CurrentState.accountId.ToString().Substring(0, 8) == "00000000"))) // 課號異常
            //    CurrentState.accountId = AccountId;
            //else
            //    AccountId = CurrentState.accountId;

            ////courseInfoDTO _Result = CurrentState.CourseInfo(_CourseId);  // 取得課程資訊
            //userInfoDTO _Result = CurrentState.UserInfo(AccountId);  // 取得使用者資訊
            ////teamInfoDTO _Result = CurrentState.TeamInfo(_teamId);  // 取得小組資訊
            ////CoursePermissions _Result = new ECampus.CourseUtility.Course().getCoursePermissions(_CourseId, _accountId);
            
            ////var aaa = string.Join(".//", _Result);
            _oResult = _msg.TransformResult(false, info);

            return Json(_oResult);
        }




        #region 鎖住資料
        [HttpPost]
        public ObjResult LockRecord(crsQuizDTO Material)
        {
            ObjResult _result = new ObjResult();
            try
            {
                if ((Material.LockedUser == null) || (Material.LockedUser.ToString().Substring(0, 8) == "00000000"))
                    _result = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.QuizId == null) || (Material.QuizId.ToString().Substring(0, 8) == "00000000"))
                    _result = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if (Material.TheTable == null)
                    _result = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "TheTable"));
                else if (Material.Locked == null)
                    _result = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "Locked"));
                else
                    _result = _quiz.Lock(Material);

            }
            catch (Exception ex)
            {
                _result = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return _result;
        }
        #endregion


        #region 檢驗是否已鎖住試卷
        [HttpPost]
        public ObjResult CheckLocked(Guid UserId, String IP, Guid QuizId)
        {
            ObjResult _result = new ObjResult();
            try
            {
                _result = _quiz.Get(UserId, IP, QuizId);   // 檢查草稿是否有該試卷
                if (_result.Success == false)
                    _result = _quiz.Acquire(UserId, IP, QuizId);   // 檢查正式試卷是否有該試卷

                if (_result.Success)
                {
                    _record = (crsQuizDTO)_result.DataCollection;
                    if (_record.Locked == false || _record.LockedUser == UserId)
                        _result = _msg.TransformResult(true, _msg.Get("msgSucceed"));
                    else // 已被其他人鎖定
                        _result = _msg.TransformResult(false, _record.LockedRemark);
                }

            }
            catch (Exception ex)
            {
                if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000")) 
                    _result = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((QuizId == null) || (QuizId.ToString().Substring(0, 8) == "00000000")) // 試卷號碼異常
                    _result = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else // 其他異常
                    _result = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return _result;
        }
        #endregion


        #region 試卷草稿清單
        [HttpPost]
        public JsonResult ListDraft(crsQuizDTO Material, Boolean IsCourseId = false, Int32 SkipAmount = 0, Int32 GetAmount = 0)
        {
            try
            {
                if (Material.IP == null)
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "IP")); // xxxxx is null or unsuitable !
                else if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                // isCourseId=true 選擇該課號所有草稿清單, 否則選擇該使用者所有草稿清單
                else if ((IsCourseId == true) && ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))) // 課號異常
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _quiz.List(Material.UserId, Material.IP, IsCourseId, Material.CourseId, SkipAmount, GetAmount, true);

                // 空值回傳 true
                if(_oResult.Success==false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), ""))>=0))
                    _oResult = _msg.TransformResult(true, null);

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion 試卷草稿清單


        #region 顯示試卷草稿內容
        [HttpPost]
        public JsonResult ViewDraft(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.QuizId == null) || (Material.QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else
                {
                    // 判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);

                    if (_coursePermissions.Quiz)
                        _oResult = _quiz.Get(Material.UserId, Material.IP, Material.QuizId);
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actGet").ToLower(), _msg.Get("objQuiz")));

                    // 空值回傳 true
                    if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >=0))
                        _oResult = _msg.TransformResult(true, null);
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 取得試卷草稿內容,會鎖定草稿
        [HttpPost]
        public JsonResult GetDraft(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.QuizId == null) || (Material.QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else
                {
                    // 判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);

                    if (_coursePermissions.Quiz)
                    {
                        // 鎖定資料
                        _userInfo = CurrentState.UserInfo(Material.UserId).FirstOrDefault();
                        crsQuizDTO _info = new crsQuizDTO();
                        _info.QuizId = Material.QuizId;
                        _info.Locked = true;
                        _info.TheTable = "QuizDraft";
                        _info.LockedUser = Material.UserId;
                        _info.LockedRemark = (String.Format(_msg.Get("msgEditing"), _userInfo.Dep_zhTW + "(" + _userInfo.Dep_enUS + ")" + " " + _userInfo.Name)); ;
                        _oResult = _quiz.Lock(_info);

                        // 取得草稿
                        if (_oResult.Success == true)
                            _oResult = _quiz.Get(Material.UserId, Material.IP, Material.QuizId);


                        // 空值回傳 true
                        if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >=0))
                            _oResult = _msg.TransformResult(true, null);
                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actGet"), _msg.Get("objQuiz")));
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 引用試卷設定為草稿(不含題目)
        [HttpPost]
        public JsonResult CopyQuizDraft(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.QuizId == null) || (Material.QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else
                {
                    // 判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);

                    if (_coursePermissions.Quiz)
                    { 
                        //material.UserId = _userId;
                        _oResult = _quiz.Recreate(Material.QuizId, Material.UserId, Material.IP);

                        if (_oResult.Success)
                        {
                            crsQuizDTO _data = (crsQuizDTO)_oResult.DataCollection;
                            // 鎖定資料
                            _userInfo = CurrentState.UserInfo(Material.UserId).FirstOrDefault();
                            crsQuizDTO _info = new crsQuizDTO();
                            _info.IP = Material.IP;
                            _info.CourseId = Material.CourseId;
                            _info.QuizId = _data.QuizId;
                            _info.Locked = true;
                            _info.TheTable = "QuizDraft";
                            _info.LockedUser = Material.UserId;
                            _info.LockedRemark = (String.Format(_msg.Get("msgEditing"), _userInfo.Dep_zhTW + "(" + _userInfo.Dep_enUS + ")" + " " + _userInfo.Name)); ;
                            // 鎖住資料
                            var _temp = LockRecord(_info);

                            if (_temp.Success == false)
                                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgLockFailed"), _data.QuizId)); // {0} Lock is failed !
                        }

                        // 空值回傳 true
                        if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >=0))
                            _oResult = _msg.TransformResult(true, null);
                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actAdd"), _msg.Get("objQuiz")));
                }

            }
            catch (Exception ex)
            {
                return Json(_msg.TransformResult( false, String.Format(_msg.Get("msgError"), ex.ToString())));
            }

            return Json(_oResult);
        }
        #endregion


        #region 建立試卷草稿
        [HttpPost]
        public JsonResult CreateDraft(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else
                {
                    // 判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);

                    if (_coursePermissions.Quiz)
                    { 
                        //material.UserId = _userId;
                        _oResult = _quiz.Create(Material);

                        if (_oResult.Success)
                        {
                            crsQuizDTO _data = (crsQuizDTO)_oResult.DataCollection;
                            // 鎖定資料
                            _userInfo = CurrentState.UserInfo(Material.UserId).FirstOrDefault();
                            crsQuizDTO _info = new crsQuizDTO();
                            _info.IP = Material.IP;
                            _info.CourseId = Material.CourseId;
                            _info.QuizId = _data.QuizId;
                            _info.Locked = true;
                            _info.TheTable = "QuizDraft";
                            _info.LockedUser = Material.UserId;
                            _info.LockedRemark = (String.Format(_msg.Get("msgEditing"), _userInfo.Dep_zhTW + "(" + _userInfo.Dep_enUS + ")" + " " + _userInfo.Name)); ;
                            // 鎖住資料
                            var _temp = LockRecord(_info);

                            if (_temp.Success == false)
                                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgLockFailed"), _data.QuizId)); // {0} Lock is failed !
                        } 
                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actAdd"), _msg.Get("objQuiz")));
                }

            }
            catch (Exception ex)
            {
                return Json(_msg.TransformResult( false, String.Format(_msg.Get("msgError"), ex.ToString())));
            }

            return Json(_oResult);
        }
        #endregion


        #region 更新試卷草稿
        [HttpPost]
        public JsonResult UpdateDraft(crsQuizDTO Material)
        {

            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.QuizId == null) || (Material.QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else
                {
                    //判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);

                    if (_coursePermissions.Quiz)
                    {
                        // 檢查是否已鎖定並可異動資料
                        _oResult = CheckLocked(Material.UserId, Material.IP, Material.QuizId);

                        //material.UserId = _userId;
                        if (_oResult.Success)
                        {
                            // 鎖定資料
                            _userInfo = CurrentState.UserInfo(Material.UserId).FirstOrDefault();
                            crsQuizDTO _info = new crsQuizDTO();
                            _info.IP = Material.IP;
                            _info.CourseId = Material.CourseId;
                            _info.QuizId = Material.QuizId;
                            _info.Locked = true;
                            _info.TheTable = "QuizDraft";
                            _info.LockedUser = Material.UserId;
                            _info.LockedRemark = (String.Format(_msg.Get("msgEditing"), _userInfo.Dep_zhTW + "(" + _userInfo.Dep_enUS + ")" + " " + _userInfo.Name)); ;
                            // 鎖住資料
                            var _temp = LockRecord(_info);

                            if (_temp.Success)
                                _oResult = _quiz.Update(Material);
                            else
                                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgLockFailed"), Material.QuizId)); // {0} Lock is failed !
                        }

                        // 空值回傳 true
                        if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                            _oResult = _msg.TransformResult(true, null);

                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actModify"), _msg.Get("objQuiz")));
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 刪除試卷草稿
        [HttpPost]
        public JsonResult DeleteDraft(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.QuizId == null) || (Material.QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else
                {

                    // 判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);

                    if (_coursePermissions.Quiz)
                    {
                        // 檢查是否已鎖定並可異動資料
                        _oResult = CheckLocked(Material.UserId, Material.IP, Material.QuizId);

                        if (_oResult.Success)
                            _oResult = _quiz.Delete(Material.UserId, Material.IP, Material.QuizId);

                        // 空值回傳 true
                        if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >=0))
                            _oResult = _msg.TransformResult(true, null);
                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actDel"), _msg.Get("objQuiz")));
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 試卷清單
        [HttpPost]
        public JsonResult ListQuiz(crsQuizDTO Material, Boolean IsCourseId = false, Int32 SkipAmount = 0, Int32 GetAmount = 0, Int32 GetType=1)
        {
            try
            {
                // isCourseId=true 選擇該課號所有試卷, 否則選擇該使用者所有試卷
                if ((IsCourseId == true) && ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))) // 課號異常
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else if ((IsCourseId == false) && ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000")))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _quiz.Records(Material.UserId, Material.IP, IsCourseId, Material.CourseId, SkipAmount, GetAmount, GetType);

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >=0))
                    _oResult = _msg.TransformResult(true, null);

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion 試卷清單


        #region 取得試卷狀態
        [HttpPost]
        public JsonResult GetStatusQuiz(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.QuizId == null) || (Material.QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else
                {
                    Material.CreaterId = Material.UserId;
                    _oResult = _quiz.Status(Material.UserId, Material.IP, Material.QuizId);

                }

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 取得試卷內容
        [HttpPost]
        public JsonResult ViewQuiz(Guid UserId, Guid QuizId, String IP="0.0.0.0")
        {
            try
            {
                _oResult = _quiz.Acquire(UserId, IP, QuizId);

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >=0))
                    _oResult = _msg.TransformResult(true, null);

            }
            catch (Exception ex)
            {
                if ((QuizId == null) || (QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 建立試卷
        [HttpPost]
        public JsonResult CreateQuiz(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.QuizId == null) || (Material.QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else
                {
                    // 判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);

                    if (_coursePermissions.Quiz)
                    {
                        _oResult = _quiz.Publish(Material.UserId, Material.IP, Material.QuizId);

                        if (_oResult.Success)
                        {
                            // 鎖定資料
                            crsQuizDTO _info = new crsQuizDTO();
                            _info.IP = Material.IP;
                            _info.CourseId = Material.CourseId;
                            _info.QuizId = Material.QuizId;
                            _info.Locked = true;
                            _info.TheTable = "Quiz";
                            _info.LockedUser = Material.UserId;
                            _info.LockedRemark = (String.Format(_msg.Get("msgPosted"), "'" + ((crsQuizDTO)_oResult.DataCollection).Caption + "'")); ;
                            var _temp = LockRecord(_info);

                            if (_temp.Success)  DeleteDraft(Material);  // 刪除草稿
                            else _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgLockFailed"), Material.QuizId)); // {0} Lock is failed !
                        }

                        // 空值回傳 true
                        if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >=0))
                            _oResult = _msg.TransformResult(true, null);
                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actAdd"), _msg.Get("objQuiz")));                    
                }

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion
        

        #region 修改試卷
        [HttpPost]
        public JsonResult UpdateQuiz(crsQuizDTO Material)
        {   // material.IsDeleted = true  ==> 刪除
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.QuizId == null) || (Material.QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else
                {
                    //判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);

                    if (_coursePermissions.Quiz)
                    {
                        // 檢查是否已鎖定並可異動資料
                        _oResult = CheckLocked(Material.UserId, Material.IP, Material.QuizId);

                        //material.UserId = _userId;
                        if (_oResult.Success)
                        {
                            // 鎖定資料
                            _userInfo = CurrentState.UserInfo(Material.UserId).FirstOrDefault();
                            crsQuizDTO _info = new crsQuizDTO();
                            _info.IP = Material.IP;
                            _info.CourseId = Material.CourseId;
                            _info.QuizId = Material.QuizId;
                            _info.Locked = true;
                            _info.TheTable = "Quiz";
                            _info.LockedUser = Material.UserId;
                            _info.LockedRemark = (String.Format(_msg.Get("msgEditing"), _userInfo.Dep_zhTW + "(" + _userInfo.Dep_enUS + ")" + " " + _userInfo.Name)); ;
                            // 鎖住資料
                            var _temp = LockRecord(_info);

                            if (_temp.Success)
                                _oResult = _quiz.Revise(Material);
                            else
                                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgLockFailed"), Material.QuizId)); // {0} Lock is failed !
                        }

                        // 空值回傳 true
                        if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >=0))
                            _oResult = _msg.TransformResult(true, null);

                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actModify"), _msg.Get("objQuiz")));
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 試卷題目清單
        [HttpPost]
        public JsonResult ListQuestion(crsQuizDTO Material, Boolean IsRandom = false, Int32 SkipAmount = 0, Int32 GetAmount = 0)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.QuizId == null) || (Material.QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _quiz.QuestionList(Material.UserId, Material.IP, Material.QuizId, IsRandom, SkipAmount, GetAmount);

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >=0))
                    _oResult = _msg.TransformResult(true, null);

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion 試卷題目清單


        #region 新增題目
        [HttpPost]
        public JsonResult CreateQuestion(crsQuizDTO Material)
        {
            try
            {
                if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.QuizId == null) || (Material.QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((Material.PoolId == null) || (Material.PoolId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "PoolId")); // xxxxx is null or unsuitable !
                else
                {
                    Material.CreaterId = Material.UserId;
                    _oResult = _quiz.QuestionAdd(Material);

                }

            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 更新試卷題目配分
        [HttpPost]
        public JsonResult SetQuestionScore(crsQuizDTO Material)
        {
            try
            {
                if ((Material.QuestionId == null) || (Material.QuestionId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuestionId")); // xxxxx is null or unsuitable !
                else if ((Material.QuizId == null) || (Material.QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else if ((Material.ScorePlus == null) && (Material.ScoreMinus == null) && (Material.Serial == null))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "Score/Serial")); // xxxxx is null or unsuitable !
                else
                {
                    // 判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);

                    if (_coursePermissions.Quiz)
                    {
                        // 檢查是否已鎖定並可異動資料
                        _oResult = CheckLocked(Material.UserId, Material.IP, Material.QuizId);

                        if (_oResult.Success)
                            _oResult = _quiz.ScoreSet(Material);

                        // 空值回傳 true
                        if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >=0))
                            _oResult = _msg.TransformResult(true, null);

                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actUpdate"), _msg.Get("objQuiz")));
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 替換試卷題目
        [HttpPost]
        public JsonResult ReplaceQuestion(crsQuizDTO Material, Guid NewPoolId)
        {
            try
            {
                if ((Material.QuestionId == null) || (Material.QuestionId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuestionId")); // xxxxx is null or unsuitable !
                else if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else
                {
                    // 判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);

                    if (_coursePermissions.Quiz)
                        _oResult = _quiz.QuestionReplace(Material, NewPoolId);    // 試卷替換新試題代號
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actModify"), _msg.Get("objQuiz")));

                    // 空值回傳 true
                    if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                        _oResult = _msg.TransformResult(true, null);
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 刪除試卷題目
        [HttpPost]
        public JsonResult DelQuestion(crsQuizDTO Material)
        {
            try
            {
                if ((Material.QuestionId == null) || (Material.QuestionId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuestionId")); // xxxxx is null or unsuitable !
                else if ((Material.UserId == null) || (Material.UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((Material.CourseId == null) || (Material.CourseId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "CourseId")); // xxxxx is null or unsuitable !
                else
                {
                    // 判斷權限
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(Material.CourseId, Material.UserId);

                    if (_coursePermissions.Quiz)
                        _oResult = _quiz.QuestionDel(Material);
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actDel"), _msg.Get("objQuiz")));

                    // 空值回傳 true
                    if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                        _oResult = _msg.TransformResult(true, null);
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 取得新試卷題目
        [HttpPost]
        public JsonResult NewQuestionSheet(Guid UserId, String IP, Guid QuizId)
        {
            try
            {
                if ((QuizId == null) || (QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else
                {
                    _oResult = _quiz.QuestionAssign(UserId, IP, QuizId);

                    // 空值回傳 true
                    if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                        _oResult = _msg.TransformResult(true, null);
                }
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 答案卷
        [HttpPost]
        public JsonResult SubmitSheet(Guid UserId, String IP, Guid QuizId, List<crsQuizDTO> Material, Boolean IsDone = false)
        {
            try
            {
                crsQuizDTO _recordA = new crsQuizDTO();
                List<crsQuizDTO> _rlist = new List<crsQuizDTO>();
                //bool isDone;
                string _submitId = null;
                int _serial = 0;
                int _count = 0;
                bool _isDone;
                if (Material != null)
                {
                    _count = Material.Count();
                    foreach (var _obj in Material)
                    {
                        _serial++;
                        _obj.IP = IP;
                        _obj.UserId = UserId;  // 考生ID
                        _obj.QuizId = QuizId;  // 測驗卷ID
                        _recordA.Success = false;

                        _isDone = (_serial == _count && IsDone) ? true : false;    // 最後一題
                        if (_obj.SubmitId == null && _submitId != null) _obj.SubmitId = new Guid(_submitId);

                        _oResult = _quiz.SheetSubmit(_obj, _isDone);
                        if (_oResult.Success)
                            _recordA = (crsQuizDTO)_oResult.DataCollection;

                        _recordA.Success = _oResult.Success;
                        _recordA.ErrorMessage = _oResult.ErrorMessage;

                        if (_submitId == null)
                            _submitId = _recordA.SubmitId.ToString();
                        

                        _rlist.Add(_recordA);
                    }

                    _oResult = _msg.TransformResult(true, _rlist);
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "Material")+ JsonConvert.SerializeObject(Material)); // xxxxx is null or unsuitable !
            }
            catch (Exception ex)
            {
                if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((QuizId == null) || (QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if (Material == null)
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), JsonConvert.SerializeObject(Material))); // xxxxx is null or unsuitable !
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }

        #endregion 答案卷



        #region 取得答案卷清單
        [HttpPost]
        public JsonResult ListSheets(Guid UserId, String IP, Guid QuizId, Guid? StudentId)
        {
            try
            {
                _oResult = _quiz.SheetList(UserId, IP, QuizId, StudentId);

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                    _oResult = _msg.TransformResult(true, null);
            }
            catch (Exception ex)
            {
                if ((QuizId == null) || (QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 取得答案卷內容
        [HttpPost]
        public JsonResult GetSheetContents(Guid UserId, String IP, Guid SubmitId, Guid? PoolId)
        {
            try
            {
                _oResult = _quiz.SheetContentsGet(UserId, IP, SubmitId, PoolId);

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                    _oResult = _msg.TransformResult(true, null);
            }
            catch (Exception ex)
            {
                if ((SubmitId == null) || (SubmitId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "SubmitId")); // xxxxx is null or unsuitable !
                else if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion



        #region 公佈答案
        [HttpPost]
        public JsonResult PublishAnswer(Guid UserId, String IP, Guid SubmitId)
        {
            try
            {
                _oResult = _quiz.AnswerPublish(UserId, IP, SubmitId);

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                    _oResult = _msg.TransformResult(true, null);
            }
            catch (Exception ex)
            {
                if ((SubmitId == null) || (SubmitId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "SubmitId")); // xxxxx is null or unsuitable !
                else if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 手動(教師)批閱

        public JsonResult ScoreSheet(Guid QuizId, String IP, Guid UserId, List<crsQuizDTO> Material)
        {
            try
            {
                // 判斷權限
                _oResult = _quiz.Acquire(UserId, IP, QuizId);
                var _quizInfo = (crsQuizDTO)_oResult.DataCollection;
                CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions(_quizInfo.CourseId, UserId);

                if (_coursePermissions.ScoreAnnouncementSetting)
                {
                    int _serial = 0;
                    DateTime _updateTime = DateTime.Now;
                    crsQuizDTO _mResult = Material.FirstOrDefault();
                    List<crsQuizDTO> _list = new List<crsQuizDTO>();

                    foreach (var _obj in Material)
                    {
                        _obj.IP = IP;
                        _obj.UserId = QuizId;
                        _oResult = null; _record = null; _serial++;

                        if (_obj.PoolId != null)    // 試題批閱
                            _oResult = _quiz.SheetReadToScore(_obj);

                        else if (_obj.SubmitId != null)     // 試卷批閱
                            _oResult = _quiz.SheetToScore(_obj, true);

                        else if ((_obj.StudentId == null) || (_obj.StudentId.ToString().Substring(0, 8) == "00000000"))
                        {   // 沒有學生Id 無法記分
                            _record.Success = false;
                            _record.ErrorMessage = String.Format(_msg.Get("msgNull"), "StudentId");
                        }
                        else    // 純記分的試卷(ex.課堂筆試)
                        {
                            _obj.Checked = 2;
                            _oResult = _quiz.StudentScore(_obj);
                        }


                        if (_oResult != null)
                        {
                            _record = (crsQuizDTO)_oResult.DataCollection;
                            _record.Success = _oResult.Success;
                            _record.ErrorMessage = _oResult.ErrorMessage;
                        }
                        _record.Serial = _serial;
                        _list.Add(_record);
                    }

                    _oResult = _msg.TransformResult(true, _list);
                }
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actScore"), _msg.Get("objSheet")));

            }
            catch (Exception ex)
            {
                if ((QuizId == null) || (QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizIdId")); // xxxxx is null or unsuitable !
                else if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }

        #endregion 教師批閱


        #region 手動(互評/自評)批閱 ---- 缺

        #endregion


        #region 成績單
        [HttpPost]
        public JsonResult Transcript(Guid UserId, String IP, Guid QuizId, Guid? StudentId)
        {
            try
            {
                _oResult = _quiz.Acquire(UserId, IP, QuizId);
                if(_oResult.Success)
                { 
                    // 判斷權限
                    var _quizInfo = (crsQuizDTO)_oResult.DataCollection;
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)_quizInfo.CourseId, UserId);

                    if (_coursePermissions.ScoreAnnouncementSetting)
                        _oResult = _quiz.SheetPick(UserId, IP, QuizId, StudentId);
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actView"), _msg.Get("objTranscript")));
                }

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                    _oResult = _msg.TransformResult(true, null);
            }
            catch (Exception ex)
            {
                if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((QuizId == null) || (QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 公布成績
        [HttpPost]
        public JsonResult PublishScore(Guid UserId, String IP, Guid QuizId, Guid? StudentId)
        {
            try
            {
                if ((QuizId == null) || (QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else
                {
                    _oResult = _quiz.Acquire(UserId, IP, QuizId);
                    if (_oResult.Success)
                        _oResult = _quiz.ScorePublish(UserId, IP, QuizId, StudentId);
                }

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >= 0))
                    _oResult = _msg.TransformResult(true, null);
            }
            catch (Exception ex)
            {
                _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 測驗統計

        #region 應考人數統計
        [HttpPost]
        public JsonResult StatisticExaminee(Guid UserId, String IP, Guid QuizId)
        {
            try
            {
                _oResult = _quiz.ExamineeStatistic(UserId, IP, QuizId);

                // 空值回傳 true
                if (_oResult.Success == false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), "")) >=0))
                    _oResult = _msg.TransformResult(true, null);
            }
            catch (Exception ex)
            {
                if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((QuizId == null) || (QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #region 答題統計
        [HttpPost]
        public JsonResult StatisticAnswer(Guid UserId, String IP, Guid QuizId, Boolean SelectMainSheet = false, Boolean WithoutUndoneSheet = true)
        {
            try
            {
                _oResult = _quiz.Acquire(UserId, IP, QuizId);
                if (_oResult.Success)
                {
                    // 判斷權限
                    var _quizInfo = (crsQuizDTO)_oResult.DataCollection;
                    CoursePermissions _coursePermissions = new ECampus.CourseUtility.Course().getCoursePermissions((Guid)_quizInfo.CourseId, UserId);

                    if (_coursePermissions.Quiz)
                    {
                        _oResult = _quiz.AnswerStatistic(UserId, IP, QuizId, SelectMainSheet, WithoutUndoneSheet);

                        // 空值回傳 true
                        if(_oResult.Success==false && ((_oResult.ErrorMessage).IndexOf(String.Format(_msg.Get("msgNotFound"), ""))>=0))
                            _oResult = _msg.TransformResult(true, null);
                    }
                    else
                        _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNoPermission"), _msg.Get("actView"), _msg.Get("objTranscript")));
                }

            }
            catch (Exception ex)
            {
                if ((UserId == null) || (UserId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "UserId")); // xxxxx is null or unsuitable !
                else if ((QuizId == null) || (QuizId.ToString().Substring(0, 8) == "00000000"))
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgNull"), "QuizId")); // xxxxx is null or unsuitable !
                else
                    _oResult = _msg.TransformResult(false, String.Format(_msg.Get("msgError"), ex.ToString()));
            }

            return Json(_oResult);
        }
        #endregion


        #endregion


    }
}
