﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.IO;
using System.Web;
using System.Dynamic;
using E4Quiz.App_GlobalResources;    // for 語言檔來源

namespace E4Quiz.Extensions
{
    public class CustomBasicUnitDTO
    {
        public bool isExists { get; set; }	// 語言檔-存在
        public string xName { get; set; }	// 語言檔-名稱
        public string xValue { get; set; }	// 語言檔-內容
        public string xComment { get; set; }	// 語言檔-備註

    }

    public class ObjResult
    {

        public bool Success { get; set; }	    // 是否執行成功	
        public string ErrorMessage { get; set; }	// 錯誤訊息
        public Object DataCollection { get; set; } 		// 內容	
    }


    #region 取得自製語言檔
    public class CustomBasicUnit
    {
        // 取得語言檔
        public string Get(String value, Boolean forHTML = true)
        {
            if (forHTML) return value.Toi18n().Replace("\\r\\n", "<br />");
            else return value.Toi18n().Replace("\\r\\n", "\r\n");
        }


        #region 使用 XML 方式取得語言檔內容 
        public CustomBasicUnitDTO cbuGet(String value, Boolean forHTML = true)
        {
            bool isExists = false;
            CustomBasicUnitDTO _mResult = new CustomBasicUnitDTO();

            // 本地語系
            string resxFile = "~/App_GlobalResources/Message.resx";
            string pathFile = HttpContext.Current.Server.MapPath(resxFile);


            _mResult.isExists = false;
            _mResult.xName = "";
            _mResult.xValue = "";
            _mResult.xComment = "";
            if (File.Exists(pathFile))                
            {
                // 通用語系               
                System.Threading.Thread thread = System.Threading.Thread.CurrentThread;
                thread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
                resxFile = "~/App_GlobalResources/Message.resx";
                pathFile = HttpContext.Current.Server.MapPath(resxFile);
            }
            if (File.Exists(pathFile))
            {
                XElement xelement = XElement.Load(pathFile);
                var ckXML = from p in xelement.Elements("data")
                            where (string)p.Attribute("name") == value
                            select p;

                if (ckXML != null && ckXML.Count() > 0)
                    isExists = true;
                else
                {
                    // 通用語系
                    pathFile = HttpContext.Current.Server.MapPath(resxFile);

                    xelement = XElement.Load(pathFile);
                    ckXML = from p in xelement.Elements("data")
                                where (string)p.Attribute("name") == value
                                select p;
                    if (ckXML != null && ckXML.Count() > 0)
                        isExists = true;
                }


                if (isExists == true)
                {
                    var xmlInfo = from p in xelement.Elements("data")
                                  where (string)p.Attribute("name") == value
                                  select p;
                    foreach (XElement xEle in xmlInfo)
                    {
                        _mResult.isExists = true;
                        _mResult.xName = value;
                        _mResult.xValue = xEle.Element("value").Value;
                        _mResult.xComment = xEle.Element("comment").Value;

                        if (forHTML)
                        {
                            _mResult.xValue = _mResult.xValue.Replace("\\r\\n", "<br />").Replace("\r\n", "<br />");
                            _mResult.xComment = _mResult.xComment.Replace("\\r\\n", "<br />").Replace("\r\n", "<br />");
                        }
                        else
                        {
                            _mResult.xValue = _mResult.xValue.Replace("\\r\\n", "\r\n");
                            _mResult.xComment = _mResult.xComment.Replace("\\r\\n", "\r\n");
                        }
                    }
                }
            }

            return _mResult;
        }
        #endregion 


        #region 將結果轉換為物件 ex. ErrorMsg string=>Object
        public ObjResult TransformResult(Boolean isSucceed, Object obj)
        {
            ObjResult _result = new ObjResult();

            _result.Success = isSucceed;
            _result.ErrorMessage = (isSucceed == false) ? obj.ToString() : null;
            _result.DataCollection = (isSucceed == true) ? obj : null;

            if (isSucceed == true && obj == null)
                _result.ErrorMessage = String.Format(Get("msgNotFound"), "");


            return _result;
        }
        #endregion


    }
    #endregion 取得自製語言檔


    
    #region 產生多國語系語系i18n
    public static class StringExtensions
    {

        public static string Toi18n(this string value)
        {
            return Message.ResourceManager.GetString(value);
        }

        public static string CultureName(this string value)
        {
            return System.Threading.Thread.CurrentThread.CurrentUICulture.Name;
        }

        public static string Toi18n(this string nameSpace, string value)
        {
            string resKey = (string.IsNullOrEmpty(nameSpace) ? string.Empty : nameSpace + ".") + value;
            return Message.ResourceManager.GetString(resKey);
        }
    }
    #endregion 產生多國語系語系i18n

    #region 自製仿ViewBag
    // 使用範例: MyBag.NULL = "NULL".Toi18n();
    public class MyBag : DynamicObject
    {
        private readonly Dictionary<string, dynamic> _properties = new Dictionary<string, dynamic>(StringComparer.InvariantCultureIgnoreCase);

        public override bool TryGetMember(GetMemberBinder binder, out dynamic result)
        {
            result = this._properties.ContainsKey(binder.Name) ? this._properties[binder.Name] : null;

            return true;
        }

        public override bool TrySetMember(SetMemberBinder binder, dynamic value)
        {
            if (value == null)
            {
                if (_properties.ContainsKey(binder.Name))
                    _properties.Remove(binder.Name);
            }
            else
                _properties[binder.Name] = value;

            return true;
        }
    }
    #endregion 自製仿ViewBag

}