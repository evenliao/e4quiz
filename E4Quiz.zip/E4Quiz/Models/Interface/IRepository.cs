﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;

namespace E4Quiz.Models.Interface
{
    public interface IRepository<TEntity> : IDisposable
        where TEntity : class
    {
        /// <summary>
        /// 建立資料
        /// </summary>
        /// <param name="instance"></param>
        void Create(TEntity instance, bool saveChange);

        /// <summary>
        /// 更新指定資料
        /// </summary>
        /// <param name="instance"></param>
        void Update(TEntity instance, bool saveChange);

        /// <summary>
        /// 刪除指定資料
        /// </summary>
        /// <param name="instance"></param>
        void Delete(TEntity instance, bool saveChange);

        /// <summary>
        /// 取得符合條件的第一筆資料
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        TEntity GetFirst(Expression<Func<TEntity, bool>> predicate);

        /// <summary>
        /// 取得符合條件的所有資料
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        IQueryable<TEntity> Get(Expression<Func<TEntity, bool>> predicate);

        /// <summary>
        /// 取得全部資料
        /// </summary>
        /// <returns></returns>
        IQueryable<TEntity> GetAll();

        /// <summary>
        /// 儲存變更
        /// </summary>
        void SaveChanges();
    }
}