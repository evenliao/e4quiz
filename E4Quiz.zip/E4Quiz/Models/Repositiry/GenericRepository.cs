﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Linq.Expressions;
using System.Data.Entity;
using System.Data.Objects;
using E4Quiz.Models.Interface;

namespace E4Quiz.Models
{
    /// <summary>
    /// 通用Repository
    /// </summary>
    /// <typeparam name="TEntity">類別</typeparam>
    public class GenericRepository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        private DbContext _context
        {
            get;
            set;
        }

        /// <summary>
        /// 建構子，預設使用e3PDB3Entities
        /// </summary>
        public GenericRepository():this (new e4ExamEntities() ) //預設使用e3PDB3Entities
        {
        }

        /// <summary>
        /// 建構子
        /// </summary>
        /// <param name="context">傳入指定的DbContext</param>
        public GenericRepository(DbContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException("context");
            }
            this._context = context;
        }

        ///// <summary>
        ///// 建構子
        ///// </summary>
        ///// <param name="context">傳入可轉成DbContext的ObjectContext</param>
        //public GenericRepository(ObjectContext context)
        //{
        //    if (context == null)
        //    {
        //        throw new ArgumentNullException("context");
        //    }
        //    this._context = new DbContext(context, true);
        //}

        /// <summary>
        /// 建立一筆資料
        /// </summary>
        /// <param name="instance"></param>
        public void Create(TEntity instance, bool saveChange)
        {
            if (instance == null)
            {
                throw new ArgumentNullException("instance");
            }
            else
            {
                this._context.Set<TEntity>().Add(instance);
                if (saveChange) this.SaveChanges();
            }
        }

        /// <summary>
        /// 更新一筆資料
        /// </summary>
        /// <param name="instance"></param>
        public void Update(TEntity instance, bool saveChange)
        {
            if (instance == null)
            {
                throw new ArgumentNullException("instance");
            }
            else
            {
                this._context.Entry(instance).State = EntityState.Modified;
                if(saveChange) this.SaveChanges();
            }
        }

        /// <summary>
        /// 刪除指定資料
        /// </summary>
        /// <param name="instance"></param>
        public void Delete(TEntity instance, bool saveChange)
        {
            if (instance == null)
            {
                throw new ArgumentNullException("instance");
            }
            else
            {
                this._context.Entry(instance).State = EntityState.Deleted;
                if(saveChange) this.SaveChanges();
            }
        }

        /// <summary>
        /// 取得第一筆指定資料
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public TEntity GetFirst(Expression<Func<TEntity, bool>> predicate)
        {
            return this._context.Set<TEntity>().FirstOrDefault(predicate);
        }

        public IQueryable<TEntity> Get(Expression<Func<TEntity, bool>> predicate)
        {
            return this._context.Set<TEntity>().Where(predicate);
        }

        /// <summary>
        /// 取得全部資料
        /// </summary>
        /// <returns></returns>
        public IQueryable<TEntity> GetAll()
        {
            return this._context.Set<TEntity>().AsQueryable();
        }

        /// <summary>
        /// 儲存變更
        /// </summary>
        public void SaveChanges()
        {
            this._context.SaveChanges();
        }

        /// <summary>
        /// 釋放資源，會執行GC作資源回收
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// 釋放資源
        /// </summary>
        /// <param name="disposing">是否釋放資源</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (this._context != null)
                {
                    this._context.Dispose();
                    this._context = null;
                }
            }
        }
    }
}