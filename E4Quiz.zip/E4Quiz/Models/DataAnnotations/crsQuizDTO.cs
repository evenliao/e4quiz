﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using E4Quiz.Models.Interface;


namespace E4Quiz.Models.DataAnnotations
{
    public class crsQuizDTO:IData
    {
        // 額外參考項目
        public string TheTable { get; set; }	    // 指定資料表
        public System.Guid UserId { get; set; }	// 當前使用者ID
        public bool Permited { get; set; }	    // 允許使用

        #region 試卷
        // 試卷設定
        // "?" = Nullable, string 不可為 Nullable
        public System.Guid QuizId { get; set; }	    //  試卷ID
        public System.Guid CreaterId { get; set; }	//  建立者ID
        public DateTime? CreateTime { get; set; }	//  建立時間
        public System.Guid? EditorId { get; set; }	//  更新者
        public DateTime? UpdateTime { get; set; }	//  最後更新時間
        public System.Guid CourseId { get; set; }	//  課程識別碼
        public int? QuizType { get; set; }	        //  試卷分類, 0:其他; 1:隨堂考; 2:期中考; 3:期末考
        public string Caption { get; set; }	        //  試卷名稱 
        public string Content { get; set; }	        //  內容說明
        public string Comment { get; set; }	        //  備註
        public int? Invited { get; set; }	        //  參與者(0:所有修課生; 1:依組別; 2:指定小組)
        public System.Guid? GroupId { get; set; }	//  指定小組代碼
        public DateTime? BeginDate { get; set; }	//  測驗開始時間
        public DateTime? EndDate { get; set; }	    //  測驗截止時間
        public string Notify { get; set; }	        //  郵件通知: 試卷發布馬上通知|測驗開始發通知|測驗結束前?天發提醒通知
        public System.Guid? NotifyRuleId { get; set; }	//  最後一次郵件通知識別碼
        public bool? IsDisorder { get; set; }	        //  試題 0:依序, 1:隨機排序
        public bool? OptionDisorder { get; set; }	    //  選項 0:依序, 1:隨機排序
        public int? DisplayType { get; set; }	        //  呈現方式, 0:全部顯示; 1:逐題作答
        public string AnswerSetting { get; set; }	    //  逐題作答設定, 每題作答時間|答對才能進行下一題|送出答卷前可回首題重新作答
        public int? TimeLimit { get; set; }	            //  測驗時間, 以分鐘算(最長3Hrs59mins)
        public int? TimeoutProcess { get; set; }	    //  0:期限內都可以開始作答; 1:期限內完成試卷(時間到極強迫交卷)
        public string QuestionSetting { get; set; }	    //  出題數量: 自行出題|自選題目|題庫隨機出題|題庫特定類型取得|題型|難度
        public int? TotalQuestion { get; set; }	        //  出題總數
        public decimal? TotalScore { get; set; }	    //  總分
        public int? DefaultScore { get; set; }	        //  預設每題分數
        public int? DisplayAnswer { get; set; }	        //  自動批閱, 0:考生交卷後馬上公布答案; 1:活動結束馬上公布答案; 2:活動結束後?天公布答案
        public int? DispAnsPutOffDays { get; set; }	    //  自動批閱, 延遲公布答案天數
        public int? CheckDisplayAnswer { get; set; }	//  手動批閱, 0:批閱完個別考生試卷後馬上公布答案; 1:批閱完所有考生試卷後馬上公布答案; 2:批閱完後?天公布答案
        public int? CkDispAnsPutOffDays { get; set; }	//  手動批閱, 延遲公布答案天數
        public string Feedback { get; set; }	        //  顯示, 試卷回饋|試題個別回饋
        public string FeedbackNotes { get; set; }	    //  試卷回饋
        public bool? Anew { get; set; }	                //  0:單次測驗, 1:多次測驗
        public string ScoreSetting { get; set; }	    //  計分設定, 自動批閱成績|教師另外調分|計算到小數第二位
        public int? ScoreOption { get; set; }	        //  多次測驗最後成終選擇, 0:最後一次測驗成績; 1:最高分; 2:最低分; 3:平均分數
        public int? DisplayScoreType { get; set; }	    //  成績公布方式, 0:不公佈成績; 1:分開公布個別考生成績; 2:公開公布所有考生成績
        public int? DisplayScore { get; set; }	        //  自動批閱, 0:考生交卷後馬上公布成績; 1:活動結束馬上公布成績; 2:活動結束後?天公布成績
        public int? DispScorePutOffDays { get; set; }	//  自動批閱, 延遲公布答案天數
        public int? CheckDisplayScore { get; set; }	    //  手動批閱, 0:批閱完個別考生試卷後馬上公布成績; 1:批閱完所有考生試卷後馬上公布成績; 2:批閱完後?天公布成績
        public int? CkDispScorePutOffDays { get; set; }	//  手動批閱, 延遲公布答案天數
        public bool? IsDeleted { get; set; }	        //  1:已刪除, 0:未刪除
        public bool? Locked { get; set; }	            //  1:資料鎖定; 0:資料可使用
        public string LockedRemark { get; set; }	    //  鎖定原因說明
        public DateTime? LockedTime { get; set; }	    //  鎖定起始時間
        public System.Guid? LockedUser { get; set; }	//  鎖定資料者


        public bool? Publish { get; set; }	    // 新增試卷(正式發布)
        public DateTime? PublishDate { get; set; }     // 公佈/發布 日期
        public int? Status { get; set; }	    // 試卷狀態, -1:不存在; 0:編輯草稿中; 1:未開始; 2:進行中; 3:已有考生繳卷; 4:已結束; 5:批閱中; 6:完成批閱; 7:公布成績

        // 試卷題目設定
        public System.Guid QuestionId { get; set; } // 試卷題目ID
        public int? ScorePlus { get; set; }          // 答對得分
        public int? ScoreMinus { get; set; }         // 答錯扣分

        // 答案卷
        public System.Guid? SubmitId { get; set; }   // 答卷ID
        public decimal? MatchRate { get; set; }      // 成績
        public bool? IsMainSheet { get; set; }      // 1:主要成績的答案卷; 0:非取用的答案卷
        public string Answer { get; set; }          // 答案內容
        public bool? IsCorrect { get; set; }        // 1:答案正確; 0:錯誤

        #endregion 試卷


        #region 題庫
        // 題庫題目
        public System.Guid PoolId { get; set; }          // 題庫ID
        public System.Guid? OriginalGroupId { get; set; }// 題組型題目來源題庫ID
        public string Unit { get; set; }                 // 單元
        public string Topic { get; set; }                // 主題
        public bool? AcrossCourse { get; set; }          // 可跨課程, false:不可, true:可
        public int? Category { get; set; }               // 題型 0:題組, 1:是非題, 2:單選題, 3:複選題, 4:填充題, 5:簡答題
        public int? Difficult { get; set; }              // 難易度
        public decimal? Grade { get; set; }               // 參考分數
        public string Subject { get; set; }              // 題目
        public bool? PublicFlag { get; set; }            // 可共同編輯,另設權限

        // 題庫答案
        public System.Guid OptionId { get; set; }        // 答案ID
        public bool? IsAnswer { get; set; }              // 正解
        public int? Serial { get; set; }                 // 序號

        public object OptionList { get; set; }        // 答案列表
        #endregion 題庫

        
        #region 成績
        public System.Guid ScoreId { get; set; }       // 得分ID
        public decimal? Score { get; set; }            // 分數
        public int? Checked { get; set; }              // 0:自動批閱, 1:待批閱, 2:已批閱
        public string Criticism { get; set; }          // 評語
        public int? GradePoint { get; set; }           // 學分
        public decimal? ExtraScore { get; set; }       // 額外調分
        public DateTime? ScoreDate { get; set; }     // 批閱時間
        public DateTime? AutoToScoreDate { get; set; }       // 自動批閱時間
        public DateTime? ReadToScoreDate { get; set; }       // 老師批閱時間
        public System.Guid StudentId { get; set; }      // 得分ID
        public bool? CompleteScored { get; set; }      // 完成批閱

        #endregion 成績


        #region 其他
        // 附加檔案紀錄
        public System.Guid FileId { get; set; }     //  附件ID
        public System.Guid PackId { get; set; }     //  同捆ID,上傳檔案後得到的ID
        public System.Guid BelongId { get; set; }   //  來源ID(題目ID/答案ID)
        public string Name { get; set; }            //  名稱
        public string Location { get; set; }        //  檔案位置

        // 共同編輯權限
        public System.Guid UnitId { get; set; }          // 共同編輯項目ID, ex. 題庫ID/試卷ID
        public System.Guid KeyId { get; set; }           // 獲權者ID(個人/課程/小組 Id)
        public int? KeyType { get; set; }                // KyeId 類型(0:個人, 1:課程, 2:小組)
        public string Account { get; set; }              // 使用者帳號
        public bool? View { get; set; }                  // 功能-顯示
        public bool? Add { get; set; }                   // 功能-新增
        public bool? Delete { get; set; }                // 功能-刪除
        public bool? Edit { get; set; }                  // 功能-修改
        public string Permit { get; set; }               // 功能權限 - 檢視|新增|刪除|修改 ; 0:無權, 1:有權

        // Log 資訊
        public System.Guid LogId { get; set; }      //紀錄ID
        public string IP { get; set; }              //紀錄者來源位址
        public System.Guid RecorderId { get; set; }	    // 紀錄者ID
        public int Behavior { get; set; }           //執行的動作, 清單 = 0, 檢視 = 1, 新增 = 2, 更新 = 3, 刪除 = 4, 鎖定 = 5, 複本 = 6
        public System.Guid? OriginQuizId { get; set; }	    // 來源試卷ID
        public System.Guid? OriginPoolId { get; set; }	    // 來源試題ID
        public System.Guid? AccountId { get; set; }	    // 考生ID

        public bool? Success { get; set; }                  // 執行成功
        public string ErrorMessage { get; set; }            // 錯誤訊息
        public object ExtraData { get; set; }               // 額外資訊

        #endregion 其他

    }


    public class objectGroupDTO : IData
    {
        public object MainData;     // 主要 的資料
        public object ExtraData;    // 其他 的資料
        public object ShareData;    // 分享/共同 的資料
        public object GroupData;    // 小組 的資料
    }

    /// <summary>
    /// 測驗統計
    /// </summary>
    public class statisticQuizDTO : IData
    {
        // 人數
        public int? VisitCount=0;            // 旁聽生
        public int? VisitDoneCount = 0;        // 完成試卷旁聽生
        public int? VisitUndoneCount = 0;      // 未完成試卷旁聽生
        public int? AttendantCount = 0;        // 應考生
        public int? AttendantDoneCount = 0;    // 完成試卷應考生
        public int? AttendantUndoneCount = 0;  // 未完成試卷應考生
        public int? AbsenteeCount = 0;         // 缺考生/小組
        public int? RequisiteCount = 0;        // 應到考生/小組
        public int? RequisiteDoneCount = 0;    // 應到完成試卷考生/小組
        public int? RequisiteUndoneCount = 0;  // 應到未完成試卷考生/小組
        // 名單
        public List<Guid> VisitList;            // 旁聽生
        public List<Guid> VisitDoneList;        // 完成試卷旁聽生
        public List<Guid> VisitUndoneList;      // 未完成試卷旁聽生
        public List<Guid> AttendantList;        // 應考生
        public List<Guid> AttendantDoneList;    // 完成試卷應考生
        public List<Guid> AttendantUndoneList;  // 未完成試卷應考生
        public List<Guid> AbsenteeList;         // 缺考生/小組
        public List<Guid> RequisiteList;        // 應到考生/小組
        public List<Guid> RequisiteDoneList;    // 應到完成試卷考生/小組
        public List<Guid> RequisiteUndoneList;  // 應到未完成試卷考生/小組
        public List<statisticSubmitDTO> SubmitCountList;        // 應考生繳卷次數
        // 小組
        public System.Guid? TeamId;     // 小組ID
        public Object TeamDetail;       // 小組詳細統計
    }

    public class statisticSubmitDTO : IData
    {
        public System.Guid? StudentId;          // 考生Id
        public int? DoneTimes = 0;                  // 完成次數
        public int? UndoneTimes = 0;                // 未完成次數
    }

    public class statisticOptionDTO : IData
    {
        public System.Guid? OptionId;           // 答案Id
        public int? PickedCount = 0;                // 被選總數
        public List<Guid> PickedList;           // 選擇者名單
    }

    public class statisticSheetDTO : IData
    {
        public System.Guid? PoolId;             // 試題Id
        public int? Category;                   // 題型
        public int? CorrectCount = 0;               // 答對人數
        public int? IncorrectCount = 0;             // 答錯人數
        public int? EmptyCount;                 // 未答題人數
        public List<Guid> CorrectList;          // 答對者名單
        public List<Guid> IncorrectList;        // 答錯者名單
        public List<Guid> EmptyList;            // 未答題者名單
        public List<statisticOptionDTO> Option; // 答案分析
    }


}